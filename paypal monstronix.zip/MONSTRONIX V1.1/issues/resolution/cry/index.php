<?php
include('crypt.php');
?>