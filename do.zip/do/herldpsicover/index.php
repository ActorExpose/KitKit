<?php
header('location:https://mail.aol.com')
?>