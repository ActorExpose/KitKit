<?php 
/** 
* HijaIyh App Framework
* @author justalinko
* @version 2.1
**/

error_reporting(0);
@ini_set('display_errors',0);
@session_start();
set_time_limit(0);


// require __DIR__.'/crawlerdetect.php';

$DATAUTAMA = 'https://hijaiyh.net';

	if(!function_exists('curl_init'))
	{
		exit('Error : Host tidak support php-curl !');
	}
	if(!file_exists(__DIR__.'/hiserver.conf'))
	{
	$ch = curl_init();
	$data = [CURLOPT_URL => $DATAUTAMA.'/index.php/main/server',
			 CURLOPT_USERAGENT => 'HijaIyh_App',
			 CURLOPT_RETURNTRANSFER=>true,
			 CURLOPT_SSL_VERIFYPEER=>false,
              CURLOPT_SSL_VERIFYHOST=>false
			];
	curl_setopt_array($ch,$data);
	$x= curl_exec($ch);
	@file_put_contents(__DIR__.'/hiserver.conf',$x);
	}

$API_URL = file_get_contents(__DIR__.'/hiserver.conf');






spl_autoload_register(function($class)
{
	require_once(__DIR__.'/HijaIyh_App/class/'.$class.'.iyh.php');
});
 
$core = new hicore;
$iki = new Iki64;
/** account & api key */
@$kiakun = $iki->decodefile(__DIR__.'/HijaIyh_App/config/.account_key','HijaIyh_App');
@$kiapi = $iki->decodefile(__DIR__.'/HijaIyh_App/config/.api_key','HijaIyh_App');
/** --- */
$api = new hiapi($API_URL,$kiakun,$kiapi);
$locales = new hilocale;
$blocker = new hiblocker;

/** check */
require_once(__DIR__.'/HijaIyh_App/AppCheck.php');
