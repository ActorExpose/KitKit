<?php
include_once(dirname(__FILE__) . '/eppData/metaregInfoDomainOptions.php');
include_once(dirname(__FILE__) . '/eppRequests/metaregInfoDomainRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/metaregEppAuthcodeRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/metaregSudoRequest.php');
include_once(dirname(__FILE__) . '/eppResponses/metaregSudoResponse.php');
include_once(dirname(__FILE__) . '/eppRequests/metaregEppTransferExtendedRequest.php');