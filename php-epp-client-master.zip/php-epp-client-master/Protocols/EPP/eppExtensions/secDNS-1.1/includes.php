<?php
include_once(dirname(__FILE__) . '/eppData/eppSecdns.php');

include_once(dirname(__FILE__) . '/eppRequests/eppDnssecUpdateDomainRequest.php');
