<?php
#
# For use with the HR connection
#
include_once(dirname(__FILE__) . '/eppRequests/hrEppInfoContactRequest.php');
include_once(dirname(__FILE__) . '/eppResponses/hrEppInfoContactResponse.php');
