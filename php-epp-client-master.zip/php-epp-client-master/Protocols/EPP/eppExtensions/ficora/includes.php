<?php

include_once(dirname(__FILE__) . '/eppData/ficoraEppContactPostalInfo.php');
include_once(dirname(__FILE__) . '/eppData/ficoraEppDomain.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppRenewRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppInfoDomainRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppInfoContactRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppUpdateContactRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppCreateContactRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppCheckBalanceRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/ficoraEppUpdateDomainRequest.php');
include_once(dirname(__FILE__) . '/eppResponses/ficoraEppCheckContactResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/ficoraEppCheckBalanceResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/ficoraEppInfoContactResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/ficoraEppInfoDomainResponse.php');