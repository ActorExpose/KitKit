<?php
include_once(dirname(__FILE__) . '/eppRequests/eppLaunchCheckRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/eppLaunchCreateDomainRequest.php');

include_once(dirname(__FILE__) . '/eppResponses/eppLaunchCheckResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/eppLaunchCreateDomainResponse.php');

