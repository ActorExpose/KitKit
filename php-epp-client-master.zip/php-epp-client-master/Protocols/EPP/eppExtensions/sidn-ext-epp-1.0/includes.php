<?php
include_once(dirname(__FILE__) . '/eppRequests/sidnEppCreateContactRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/sidnEppRenewRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/sidnEppPollRequest.php');

include_once(dirname(__FILE__) . '/eppResponses/sidnEppResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/sidnEppCheckResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/sidnEppInfoDomainResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/sidnEppPollResponse.php');