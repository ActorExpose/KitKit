<?php
namespace Metaregistrar\EPP;
class dnsbeEppCreateNsgroupResponse extends eppResponse {
    function __construct() {
        parent::__construct();
    }

}