<?php
namespace Metaregistrar\EPP;
class dnsbeEppCreateResponse extends eppCreateResponse {
    function __construct() {
        parent::__construct();
    }

}
