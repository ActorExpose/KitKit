<?php
namespace Metaregistrar\EPP;
class dnsbeEppDeleteDomainResponse extends eppResponse {
    function __construct() {
        parent::__construct();
    }

}