<?php
namespace Metaregistrar\EPP;

class dnsbeEppUpdateContactResponse extends eppUpdateContactResponse {
    function __construct() {
        parent::__construct();
    }
	
    function __destruct() {
        parent::__destruct();
    }

}

