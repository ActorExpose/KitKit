<?php
namespace Metaregistrar\EPP;
class dnsbeEppCreateDomainResponse extends eppCreateDomainResponse {
    function __construct() {
        parent::__construct();
    }

}