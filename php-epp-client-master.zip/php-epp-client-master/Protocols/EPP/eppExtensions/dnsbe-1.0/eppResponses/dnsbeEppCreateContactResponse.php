<?php
namespace Metaregistrar\EPP;
class dnsbeEppCreateContactResponse extends eppCreateContactResponse {
    function __construct() {
        parent::__construct();
    }

}