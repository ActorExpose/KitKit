<?php
namespace Metaregistrar\EPP;

// See https://www.norid.no/no/registrar/system/dokumentasjon/eksempler/?op=hcre for example request/response

class noridEppCreateHostResponse extends eppCreateHostResponse {
    
    use noridEppResponseTrait;
    
}