<?php
namespace Metaregistrar\EPP;

// See https://www.norid.no/no/registrar/system/dokumentasjon/eksempler/?op=hdel for example request/response

class noridEppDeleteHostResponse extends eppDeleteResponse {
    
    use noridEppResponseTrait;
    
}