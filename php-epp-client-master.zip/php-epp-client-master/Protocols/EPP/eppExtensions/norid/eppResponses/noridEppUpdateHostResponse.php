<?php
namespace Metaregistrar\EPP;

// See https://www.norid.no/no/registrar/system/dokumentasjon/eksempler/?op=hupd for example request/response

class noridEppUpdateHostResponse extends eppUpdateHostResponse {
    
    use noridEppResponseTrait;
    
}