<?php
/**
 * Created by PhpStorm.
 * User: thomasm
 * Date: 17.09.2015
 * Time: 14:47
 */

namespace Metaregistrar\EPP;


class atEppUpdateContactResponse extends eppUpdateContactResponse
{
    use atEppResponseTrait;
}