<?php
/**
 * Created by PhpStorm.
 * User: thomasm
 * Date: 02.10.2015
 * Time: 09:56
 */

namespace Metaregistrar\EPP;


class atEppTransferResponse extends eppTransferResponse
{
    use atEppResponseTrait;
}