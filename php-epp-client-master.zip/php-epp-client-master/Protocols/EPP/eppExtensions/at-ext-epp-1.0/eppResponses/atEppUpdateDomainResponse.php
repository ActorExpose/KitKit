<?php
/**
 * Created by PhpStorm.
 * User: thomasm
 * Date: 17.09.2015
 * Time: 14:48
 */

namespace Metaregistrar\EPP;


class atEppUpdateDomainResponse extends eppUpdateDomainResponse
{
    use atEppResponseTrait;
}