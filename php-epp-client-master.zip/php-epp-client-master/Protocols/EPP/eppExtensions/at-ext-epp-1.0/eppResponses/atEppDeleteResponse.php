<?php
/**
 * Created by PhpStorm.
 * User: thomasm
 * Date: 30.09.2015
 * Time: 12:14
 */

namespace Metaregistrar\EPP;


class atEppDeleteResponse extends eppDeleteResponse
{
    use atEppResponseTrait;
}