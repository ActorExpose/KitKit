<?php

include_once(dirname(__FILE__) . '/eppRequests/atEppCreateContactRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/atEppUpdateContactRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/atEppCreateDomainRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/atEppUpdateDomainRequest.php');
include_once(dirname(__FILE__) . '/eppResponses/atEppCreateResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/atEppUpdateContactResponse.php');
include_once(dirname(__FILE__) . '/eppResponses/atEppUpdateDomainResponse.php');
