<?php
include_once(dirname(__FILE__) . '/eppRequests/iisEppUpdateDomainClientDeleteRequest.php');
include_once(dirname(__FILE__) . '/eppRequests/iisEppCreateContactRequest.php');
include_once(dirname(__FILE__) . '/eppResponses/iisEppInfoDomainResponse.php');

