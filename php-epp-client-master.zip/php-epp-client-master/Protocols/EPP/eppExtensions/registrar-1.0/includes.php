<?php
#
# For use with the EURID connection
#
include_once(dirname(__FILE__) . '/eppRequests/euridEppInfoDomainRequest.php');
include_once(dirname(__FILE__) . '/eppResponses/euridEppInfoDomainResponse.php');
