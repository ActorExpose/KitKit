<?php
namespace Metaregistrar\EPP;

class eppUpdateRequest extends eppRequest {
    function __construct($objectname, $addinfo = null, $removeinfo = null, $updateinfo = null) {
        parent::__construct();
    }

    function __destruct() {
        parent::__destruct();
    }

}