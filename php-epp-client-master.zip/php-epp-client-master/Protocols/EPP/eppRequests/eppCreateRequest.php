<?php
namespace Metaregistrar\EPP;

class eppCreateRequest extends eppRequest {

    function __construct() {
        parent::__construct();
    }

    function __destruct() {
        parent::__destruct();
    }

}

