<?php
namespace Metaregistrar\EPP;

class eppDeleteResponse extends eppResponse {
    function __construct() {
        parent::__construct();
    }

    function __destruct() {
        parent::__destruct();
    }
}