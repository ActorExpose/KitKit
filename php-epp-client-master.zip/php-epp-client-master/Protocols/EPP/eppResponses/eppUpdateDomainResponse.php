<?php
namespace Metaregistrar\EPP;

class eppUpdateDomainResponse extends eppUpdateResponse {
    function __construct() {
        parent::__construct();
    }

    function __destruct() {
        parent::__destruct();
    }


}
