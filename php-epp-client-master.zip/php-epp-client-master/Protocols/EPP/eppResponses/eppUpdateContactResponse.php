<?php
namespace Metaregistrar\EPP;

class eppUpdateContactResponse extends eppUpdateResponse {
    function __construct() {
        parent::__construct();
    }

    function __destruct() {
        parent::__destruct();
    }

}
