<?php
namespace Metaregistrar\EPP;

class eppLogoutResponse extends eppResponse {
    function __construct() {
        parent::__construct();
    }

    function __destruct() {
        parent::__destruct();
    }
}