<?php
  $host = 'localhost';
  $user = 'medisfse_useruser';
  $pass = '1.4User';
  $db = 'medisfse_databaza1';
  // krijo lidhje
  $conn = new mysqli($localhost, $user, $pass, $db);  	
  // kontrollo lidhje	
  if ($conn->connect_error) {      
    die("Failed to connect: " . $conn->connect_error);
  }
  
   
?>