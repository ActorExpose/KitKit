<?

$to = "fudspam.tool@gmail.com";

?>