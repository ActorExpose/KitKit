<?php
	$lg_captcha = [
		"title" => "Security Challenge",
		"head" => "Security Challenge",
		"body" => "Please type the characters you see in the image for security purposes",
		"bt_secure" => "I'm not a robot",
		"code" => "Enter the code shown"
	];
?>