<?php
	$lg_captcha = [
		"title" => "Bezpečnostní výzva",
		"head" => "Bezpečnostní výzva",
		"body" => "Zadejte bezpečnostní znaky, které vidíte na obrázku",
		"bt_secure" => "Nejsem robot",
		"code" => "Zadejte zobrazený kód"
	];
?>