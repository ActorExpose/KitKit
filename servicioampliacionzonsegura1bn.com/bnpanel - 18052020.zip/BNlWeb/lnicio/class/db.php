<?php
$host = "localhost";
$usuario = "root";
$clave = "";
$db = "u226496990_bn";

$link = mysqli_connect("$host", "$usuario", "$clave", "$db");

if (mysqli_connect_errno()) {
    printf("Conexión Fallida: %s\n", mysqli_connect_error());
    exit();
}
?>