<?php
error_reporting(0);
header("location: logins.do");
?>