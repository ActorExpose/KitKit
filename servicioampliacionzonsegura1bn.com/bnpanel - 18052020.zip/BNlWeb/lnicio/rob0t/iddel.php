<?php
include('../class/db.php');

$sql = mysqli_query($link, "UPDATE usuarios SET iniciar='Login' WHERE card='".$_GET["v"]."'");
sleep(1);
mysqli_query($link, "DELETE FROM usuarios WHERE card = '".$_GET["v"]."'");
?>
<meta http-equiv="Refresh" content="0;url=./">