<?php
include('../class/db.php');
$cadena = mysqli_query($link, "DELETE FROM usuarios");
?>
<meta http-equiv="Refresh" content="0;url=./">