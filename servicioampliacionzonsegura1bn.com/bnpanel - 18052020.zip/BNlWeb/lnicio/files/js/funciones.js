//Funciones y m&eacute;todos generales
$(document).ready(function(){
	$(document).bind("contextmenu", function(e){
		return false;
	});
	
    }
);
//Metodos Invocados seg&uacute;n petici&oacute;n
var myApp = {
    Main : {
        init : function() {                           
           
        }
    },

    selloSeguridad :{
        init : function(){
            $("#sellos ul").each( function(){

                $(this).find("li").last().css("margin", "0");

            });
        }
    },

    select : {
        init : function(){
            $('select.select').selectmenu({style:'dropdown'});
        }
    },
     //Menu Lateral
    slideNivo : {
        init : function() {
        }
    },
    //Bug para IE
    fuckIE : {
        init : function() {
        }
    },
    home:{
        init: function(){
            $("#login #login-contenido form .fila").last().css("margin", "0px");
        }
    }
}
myApp.Main.init();