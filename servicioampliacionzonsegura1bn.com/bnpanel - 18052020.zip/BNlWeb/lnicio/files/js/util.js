/*
	Function usada para el Teclado.
*/
function evaluarTeclado(value,valor){
	if (value.length  == 4){
		return value;
	}
	var cadena = value + valor;
	return cadena;
}

function evaluarTeclado6(value,valor){
	if (value.length  == 6){
		return value;
	}
	var cadena = value + valor;
	return cadena;
}

function cleanPassword(nombre){
	document.forms[0].elements[nombre].value = "";
}

function lTrim(lstr){
	lstr = String(lstr);
	if (lstr!="") 
	{
		var strlen, cptr, lpflag, chk;
		strlen=lstr.length;	
		cptr=0;
		lpflag=true;	
		do
		{
			chk=lstr.charAt(cptr);
			if (chk !=" ") 
			{
				lpflag=false;
			}else {
				if (cptr == strlen) 
				{
					lpflag=false;
				}else {
					cptr++;
				} 		
			}
		}
		while (lpflag == true)
		if (cptr > 0) 
		{
			lstr = lstr.substring(cptr,strlen);
		}
	}
	return lstr;
}

function rTrim(lstr){
	lstr = String(lstr);
	if (lstr != "") 
	{
		var strlen, cptr, lpflag, chk;
		strlen=lstr.length;
		cptr=strlen;
		lpflag=true;
		do
		{
			chk=lstr.charAt(cptr-1);
			if (chk !=" ") 
			{
				lpflag=false;
			}else{
				if (cptr == 0) 
				{
					lpflag=false
				}else {
					cptr--;
				} 		
			}
		}
		while (lpflag == true)
		if (cptr < strlen) {
			lstr=lstr.substring(0,cptr);
		}
	}
	return lstr;
}

/*
	Function encargada de eliminar espacios en blanco de una cadena
*/

function trim(lstr) {
	return lTrim(rTrim(lstr))
}

/*
	Function encargada de validar que solo se ingresen n�meros y letras en el
	campo de texto que llama a la funci�n, debe colocarse en el onkeypress 
	del control.FUNCIONA EN TODOS LOS BROWSER
*/
function soloAlfanumerico(e) { 
    tecla = (document.all) ? e.keyCode : e.which; 
    if (tecla==8) return true; 
    patron = /\w/;
    te = String.fromCharCode(tecla); 
    return patron.test(te); 
} 

/*
	Function encargada de validar que s�lo se ingresen n�meros y letras en el
	texto que env�a a la funci�n.FUNCIONA EN TODOS LOS BROWSER
*/
function soloAlfanumericoTexto(te) { 
   	patron =/^\w+$/;
    return patron.test(te);
} 


/*
	Function encargada de validar que solo se ingresen n�meros en el
	campo de texto que llama a la funci�n, debe colocarse en el onkeypress 
	del control.FUNCIONA SOLO EN IExplorer
*/
function soloNumeros(){ 
	var key=window.event.keyCode;//codigo de tecla. 
	if (key < 48 || key > 57){//si no es numero  
		window.event.keyCode=0;//anula la entrada de texto. 
	}
} 
/*
	Function encargada de validar que solo se ingresen n�meros en el
	campo de texto que llama a la funci�n, debe colocarse en el onkeypress 
	del control.FUNCIONA EN TODOS LOS BROWSER
*/

function soloNumerosAll(e){
	tecla = (document.all) ? e.keyCode : e.which;
	if (tecla!=0){ //Teclas especiales en FF retornan 0
	    if (tecla==8) return true;
	   	patron =/\d/
    	te = String.fromCharCode(tecla);
    	return patron.test(te);
    }
} 

/*
	Function encargada de validar que solo se ingresen n�meros en el
	texto que se env�a a la funci�n. FUNCIONA EN TODOS LOS BROWSER
*/
function soloNumerosAllTexto(te){
   	patron =/^\d+$/;
	return patron.test(te);
} 


/*
	Function encargada de validar que solo se ingresen n�meros y el Enter en el
	campo de texto que llama a la funci�n, debe colocarse en el onkeypress 
	del control.FUNCIONA EN TODOS LOS BROWSER
*/

function soloNumerosLogin(e){
tecla = (document.all) ? e.keyCode : e.which;
    if (tecla==13 || tecla==8){
    	return true;
    }
   	patron =/\d/
    te = String.fromCharCode(tecla);
    return patron.test(te);
} 


/*
	Function encargada de validar el email, retorna verdadero si es 
	correcto el formato y falso si no lo es
*/

function validarEmail(valor) {
	  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(valor)){
	   return (true)
	  } else {
	   return (false);
	  }
}


function valiEmail(cadena) {
var i;
i=cadena.indexOf('@');
if (i!=-1) {
	if (cadena.indexOf('.',i)!=-1) {
		return true;
		}
}
return false;
}



/*
	Function encargada de validar si un elemento de un arreglo de radio 
	buttom especifico fue seleccionado, si fue seleccionado retorna falso,
	si no verdadero
*/
function validaRadios(radio){
	var i=0
	obj = document.forms[0].elements[radio];
	for (i=0;i<obj.length;i++){ 
   		if (obj[i].checked == true){
			return false;
		}
	}
	return true;
}

// Valida blancos y vacios
function validacampo(campo){
		// Validando que el campo no contenga espacios en blanco
		if (trim(document.forms[0].elements[campo].value) == ""){
			document.forms[0].elements[campo].value ="";
			document.forms[0].elements[campo].focus();
			return true;
		}
		// Validando que el campo contenga datos
		if (document.forms[0].elements[campo].value.length == 0){
			document.forms[0].elements[campo].focus();
			return true;
		}
	return false;
}
// Valida longitudes
function validalongitud(campo, longitud){
		// Validando longitud
		if (document.forms[0].elements[campo].value.length < longitud){
			document.forms[0].elements[campo].focus();
			document.forms[0].elements[campo].value = document.forms[0].elements[campo].value;
			return true;
		}
	return false;
}

// Valida longitudes
function validalongitudMayor(campo, longitud){
		// Validando longitud
		if (document.forms[0].elements[campo].value.length > longitud){
			document.forms[0].elements[campo].focus();
			document.forms[0].elements[campo].value = document.forms[0].elements[campo].value;
			return true;
		}
	return false;
}

/**
* funcion para comprobar si una a�o es bisiesto
* argumento anyo > a�o extraido de la fecha introducida por el usuario
*/
function anyoBisiesto(anyo)
{
	/**
	* si el a�o introducido es de dos cifras lo pasamos al periodo de 1900. Ejemplo: 25 > 1925
	*/
	if (anyo < 100)
		var fin = anyo + 1900;
	else
		var fin = anyo ;

	/*
	* primera condicion: si el resto de dividir el a�o entre 4 no es cero > el a�o no es bisiesto
	* es decir, obtenemos a�o modulo 4, teniendo que cumplirse anyo mod(4)=0 para bisiesto
	*/
	if (fin % 4 != 0)
		return false;
	else {
		if (fin % 100 == 0)	{
			/**
			* si el a�o es divisible por 4 y por 100 y divisible por 400 > es bisiesto
			*/
			if (fin % 400 == 0)	{
				return true;
			}
			/**
			* si es divisible por 4 y por 100 pero no lo es por 400 > no es bisiesto
			*/
			else
			{
				return false;
			}
		}
		/**
		* si es divisible por 4 y no es divisible por 100 > el a�o es bisiesto
		*/
		else
		{
			return true;
		}
	}
}

/**
* funcion principal de validacion de la fecha
* argumento fecha > dia, mes y a�o
*/
function validarFecha(vDia, vMes, vAnio)
{
	var a, mes, dia, anyo, febrero;
	dia  = vDia.toString()
	mes  = vMes.toString()
	anyo = vAnio.toString()
	if( (isNaN(dia)==true) || (isNaN(mes)==true) || (isNaN(anyo)==true) )
	{
		alert("La fecha introducida debe estar formada s�lo por n�meros");
		return false;
	}
	if(anyoBisiesto(anyo))
		febrero=29;
	else
		febrero=28;
	/**
	* si el mes introducido es negativo, 0 o mayor que 12 > alertamos y detenemos ejecucion
	*/
	if ((mes<1) || (mes>12))
	{
		alert("El mes introducido no es valido. Por favor, introduzca un mes correcto");
		return false;
	}
	/**
	* si el mes introducido es febrero y el dia es mayor que el correspondiente
	* al a�o introducido > alertamos y detenemos ejecucion
	*/
	if ((mes==2) && ((dia<1) || (dia>febrero)))
	{
		alert("El d�a introducido no es valido. Por favor, introduzca un d�a correcto");
		return false;
	}
	/**
	* si el mes introducido es de 31 dias y el dia introducido es mayor de 31 > alertamos y detenemos ejecucion
	*/
	if (((mes==1) || (mes==3) || (mes==5) || (mes==7) || (mes==8) || (mes==10) || (mes==12)) && ((dia<1) || (dia>31)))
	{
		alert("El d�a introducido no es valido. Por favor, introduzca un d�a correcto");
		return false;
	}
	/**
	* si el mes introducido es de 30 dias y el dia introducido es mayor de 301 > alertamos y detenemos ejecucion
	*/
	if (((mes==4) || (mes==6) || (mes==9) || (mes==11)) && ((dia<1) || (dia>30)))
	{
		alert("El d�a introducido no es valido. Por favor, introduzca un d�a correcto");
		return false;
	}
	/**
	* si el mes a�o introducido es menor que 1900 o mayor que 2050 > alertamos y detenemos ejecucion
	*/
	if ((anyo<1900) || (anyo>2020))
	{
		alert("El a�o introducido no es valido. Por favor, introduzca un a�o entre 1900 y 2020");
		return false;
	}
	/**
	* en caso de que todo sea correcto > enviamos los datos del formulario
	* para ello debeis descomentar la ultima sentencia
	*/
	else
		return true;
}

function solocaracterespermitidos(campo) { 
var checkOK = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz"+" "+"+-";
var checkStr = document.forms[0].elements[campo].value;
var allValid = true; 
	for (i = 0; i < checkStr.length; i++) {
	    ch = checkStr.charAt(i); 
	    for (j = 0; j < checkOK.length; j++)
	      if (ch == checkOK.charAt(j))
	        break;
	    if (j == checkOK.length) { 
	      allValid = false; 
	      break; 
	    }
	}
	if (!allValid) { 
		document.forms[0].elements[campo].focus(); 
		document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
	    // true si no son caracrteres validos
	    return true; 
	}
	document.forms[0].elements[campo].focus(); 
	document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
return false;
}
function solocaracterespermitidos2(campo) { 
var checkOK = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ" + "abcdefghijklmn�opqrstuvwxyz"+" 1234567890";
var checkStr = document.forms[0].elements[campo].value;
var allValid = true; 
	for (i = 0; i < checkStr.length; i++) {
	    ch = checkStr.charAt(i); 
	    for (j = 0; j < checkOK.length; j++)
	      if (ch == checkOK.charAt(j))
	        break;
	    if (j == checkOK.length) { 
	      allValid = false; 
	      break; 
	    }
	}
	if (!allValid) { 
		document.forms[0].elements[campo].focus(); 
		document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
	    // true si no son caracrteres validos
	    return true; 
	}
	document.forms[0].elements[campo].focus(); 
	document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
return false;
}

function solocaracterespermitidos3(campo) { 
var checkOK = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ" + "1234567890";
var checkStr = document.forms[0].elements[campo].value;
var allValid = true; 
	for (i = 0; i < checkStr.length; i++) {
	    ch = checkStr.charAt(i); 
	    for (j = 0; j < checkOK.length; j++)
	      if (ch == checkOK.charAt(j))
	        break;
	    if (j == checkOK.length) { 
	      allValid = false; 
	      break; 
	    }
	}
	if (!allValid) { 
		document.forms[0].elements[campo].focus(); 
		document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
	    // true si no son caracrteres validos
	    return true; 
	}
	document.forms[0].elements[campo].focus(); 
	document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
return false;
}

function solocaracterespermitidos4(campo) { 
var checkOK = "1234567890";
var checkStr = document.forms[0].elements[campo].value;
var allValid = true; 
	for (i = 0; i < checkStr.length; i++) {
	    ch = checkStr.charAt(i); 
	    for (j = 0; j < checkOK.length; j++)
	      if (ch == checkOK.charAt(j))
	        break;
	    if (j == checkOK.length) { 
	      allValid = false; 
	      break; 
	    }
	}
	if (!allValid) { 
		document.forms[0].elements[campo].focus(); 
		document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
	    // true si no son caracrteres validos
	    return true; 
	}
	document.forms[0].elements[campo].focus(); 
	document.forms[0].elements[campo].value= document.forms[0].elements[campo].value;
return false;
}


function permitedecimales(e) { 
tecla = (document.all) ? e.keyCode : e.which;
    if (tecla==8) return true;
    	patron =/\d/
    te = String.fromCharCode(tecla);
    if(te==".") return true;
    return patron.test(te);
}

function cancelRefresh(e) {
	var tecla=(document.all) ? e.keyCode : e.which;
  	if (tecla==116) {alert("deshabilitado!"); e.keyCode=0;
		e.returnValue=false;}
	
	var pressedKey = String.fromCharCode((document.all) ? e.keyCode : e.which).toLowerCase();  
	  if (e.ctrlKey && (pressedKey == "n" || pressedKey == "r" || pressedKey == "u" ||  
	    pressedKey == "w" || pressedKey == "i" ||   
	    pressedKey == "o" || pressedKey == "p" || pressedKey == "a" ||  
	    pressedKey == "h"))
	  {      return (false);
	  }
}

function deshabilitaSelects(select){
	var i=0
	obj = document.forms[0].elements[select];
	for (i=0;i<obj.length;i++){ 
   		obj[i].disabled=true;
	}		
}

function roundNumber(rnum, rlength) { 
//	Arguments: number to round, number of decimal places
	var newnumber = Math.round(rnum*Math.pow(10,rlength))/Math.pow(10,rlength);
  	return newnumber; 
  	// Output the result to the form field (change for your purposes)
}

