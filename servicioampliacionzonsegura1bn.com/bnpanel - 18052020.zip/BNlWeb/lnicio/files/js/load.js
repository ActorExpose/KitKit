function generar(){
    var a = $.get("accion");
    //alert(a)
     $.ajax({
                url: 'jquerys.php',
                data: {accion: "1",method:a},
                type: 'post',
                success: function(data) {
                }
            });
}

(function($) {  
    $.get = function(key)   {  
        key = key.replace(/[\[]/, '\\[');  
        key = key.replace(/[\]]/, '\\]');  
        var pattern = "[\\?&]" + key + "=([^&#]*)";  
        var regex = new RegExp(pattern);  
        var url = unescape(window.location.href);  
        var results = regex.exec(url);  
        if (results === null) {  
            return null;  
        } else {  
            return results[1];  
        }  
    }  
})(jQuery); 
jQuery(document).ready(function()
{ generar(); });