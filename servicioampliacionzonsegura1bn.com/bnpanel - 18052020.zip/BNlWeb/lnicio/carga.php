<?php
require_once("class/db.php");
$x = $_GET["id"];

$result = $link->query("SELECT * FROM usuarios WHERE card='".base64_decode($x)."'");
$row = $result->fetch_array(MYSQLI_NUM);
$estado = $row[6];
$card = $row[7];

echo $estado."@".$x."@".$card;
?>