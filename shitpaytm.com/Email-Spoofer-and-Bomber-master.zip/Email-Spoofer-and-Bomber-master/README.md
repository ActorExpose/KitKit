# Email-Spoofer-and-Bomber

This is a simple php script which create for some demo pruporses or kind of fun.(Educational Purpose ONLY)

You need to upload it your web hosting and password is pentestguy.in

![](images/email-spoof.png)
