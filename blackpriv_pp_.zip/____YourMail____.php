<?php
$emailku = 'kalong.night@yandex.com';
?>