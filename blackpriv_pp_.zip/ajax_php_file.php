<?php
$ip = $_SERVER['REMOTE_ADDR'];
if(isset($_FILES["file"]["type"]))
{
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
if ((($_FILES["file"]["type"] == "image/png") || ($_FILES["file"]["type"] == "image/jpg") || ($_FILES["file"]["type"] == "image/jpeg")
) && ($_FILES["file"]["size"] > 100)
&& in_array($file_extension, $validextensions)) {
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br/><br/>";
}
else
{
if (file_exists("upload/From_IP_".$ip."_".md5(microtime())."_". $_FILES["file"]["name"])) {
echo " <span id='invalid'></span> ";
}
else
{
$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "upload/From_IP_".$ip."_".md5(microtime())."_". $_FILES["file"]["name"];
move_uploaded_file($sourcePath,$targetPath) ; 
echo "<span id=success' ></span>";
}
}
}
else
{
echo "<span id='invalid'>Invalid Size or Type<span>";
}
}
?>